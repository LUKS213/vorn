# سند مرجع کامل فرانت‌اند VORN

> این سند برای تحویل به یک مهندس فرانت‌اند یا یک عامل هوش مصنوعی دیگر نوشته شده است. هدف آن این است که عامل بعدی بتواند بدون حدس‌زدن، ساختار، رفتار، ظاهر، قراردادهای موجود و معیارهای پذیرش را بفهمد و توسعه را ادامه دهد.
>
> **اصل حیاتی:** این پروژه یک رابط مدیریت برای Telegram Mini App است. بازطراحی باید ظاهر و تجربهٔ کاربری را ارتقا دهد، نه اینکه منطق فعلی، قرارداد API، فرمت HTML تلگرام، مدل ایموجی‌های سفارشی یا رفتارهای Mini App را حذف کند.

---

## 0. خلاصهٔ محصول و هدف طراحی

VORN یک پنل فرانت‌اند برای مدیریت ایموجی‌های سفارشی تلگرام و ساخت/مدیریت پست‌های تعاملی است. برنامه در Telegram WebView اجرا می‌شود و برای توسعه، حالت مرورگر با پارامتر `?dev=...` نیز دارد.

### هدف تجربه

- ظاهر محصول باید حس یک ابزار حرفه‌ای، سریع، دقیق و مدرن را بدهد؛ نه یک قالب آمادهٔ داشبورد و نه یک صفحهٔ پر از افکت.
- هویت بصری: **Neon Blue / Precision Interface**.
- تم روشن: پس‌زمینهٔ آبی-خاکستری بسیار روشن، سطوح سفید، متن سرمه‌ای، آبی الکتریکی برای اقدام اصلی و فیروزه‌ای فقط برای هایلایت محدود.
- تم تاریک: پس‌زمینهٔ نزدیک به مشکی سرمه‌ای، سطح‌های لایه‌ای، خطوط آبی کم‌رنگ، متن سفید مایل به آبی و نئون آبی/فیروزه‌ای کنترل‌شده.
- نئون باید نقش تأکیدی داشته باشد؛ اگر همه‌چیز glow داشته باشد، سلسله‌مراتب بصری از بین می‌رود.
- حرکت‌ها کوتاه، هدفمند و قابل پیش‌بینی باشند. انیمیشن تزئینی نباید عملکرد یا خوانایی را قربانی کند.
- رابط فارسی باید RTL واقعی داشته باشد؛ انگلیسی باید LTR واقعی باشد. از ترفندهای `row-reverse` برای جبران جهت استفاده نکن.

### تعریف «۲۰۰۰ برابر قوی‌تر» به معیار قابل سنجش

این عبارت به معنی افزودن افکت تصادفی نیست. خروجی حرفه‌ای باید در این محورها پیشرفت کند:

1. **Visual hierarchy:** تیتر، آمار، اقدام اصلی، محتوا و متادیتا در یک نگاه قابل تفکیک باشند.
2. **Consistency:** فاصله‌ها، شعاع‌ها، رنگ‌ها، ارتفاع کنترل‌ها و رفتار hover/focus از توکن‌های مشترک استفاده کنند.
3. **Responsiveness:** از موبایل کوچک Telegram WebView تا دسکتاپ عریض، بدون overflow و شکست layout.
4. **Interaction quality:** loading، disabled، error، empty، success، pressed و focus state طراحی شده باشند.
5. **Accessibility:** صفحه‌کلید، focus واضح، aria، کنتراست، reduced motion و اندازهٔ هدف لمسی رعایت شوند.
6. **Performance:** بدون کتابخانهٔ سنگین غیرضروری؛ انیمیشن عمدتاً با transform/opacity؛ ایموجی سفارشی lazy-load شود.
7. **Functional parity:** تمام قابلیت‌های فعلی باقی بمانند و در سند تحویل صریحاً ردیابی شوند.

---

## 1. ساختار پروژه

```text
/
├── index.html
├── FRONTEND_SPEC_FA.md
├── README_FA.md
├── package.json
├── scripts/
│   └── verify.mjs
├── tests/
│   └── post-model.test.mjs
└── static/
    ├── css/
    │   └── app.css
    ├── fonts/
    │   ├── NotoSansArabic-Regular.ttf
    │   ├── NotoSansArabic-Medium.ttf
    │   ├── NotoSansArabic-SemiBold.ttf
    │   ├── NotoSansArabic-Bold.ttf
    │   ├── OFL-Noto.txt
    │   └── OFL-Noto-Color-Emoji.txt
    ├── img/
    │   └── favicon.svg
    └── js/
        ├── app.js
        ├── i18n.js
        ├── post-model.js
        ├── tg-emoji.js
        └── tma.js
```

### مسئولیت هر فایل

| فایل | مسئولیت | محدودیت تغییر |
|---|---|---|
| `index.html` | shell ثابت، metadata، بارگذاری Telegram SDK، CSS و entry module | شناسه‌های `#top`, `#tabs`, `#main`, `#primary`, `#toasts`, `#sheets` باید حفظ شوند |
| `static/js/app.js` | روتر hash، viewها، رویدادها، API client، sheet، toast، editor و theme | تغییر باید رفتارهای فعلی و payloadهای API را حفظ کند |
| `static/js/post-model.js` | توابع خالص تبدیل متن/HTML، ایموجی رزروشده، sanitize، متغیرها و اعتبارسنجی دکمه‌ها | این فایل بدون DOM است؛ منطق خالص را اینجا نگه دار و تست بنویس |
| `static/js/tg-emoji.js` | Web Component نمایش custom emoji با fallback، تصویر ثابت و حرکت | ساده‌سازی آن به `<img>` ممنوع است؛ ترتیب fallback و محدودیت انیمیشن مهم‌اند |
| `static/js/tma.js` | wrapper برای Telegram WebApp، haptic، BackButton، MainButton و CloudStorage | تمام قابلیت‌ها باید version-gated بمانند |
| `static/js/i18n.js` | زبان، ترجمه و فرمت تاریخ/عدد | کلید جدید باید در هر دو زبان FA/EN تعریف شود |
| `static/css/app.css` | design system، component styling، responsive و motion | از توکن‌ها استفاده کن؛ style inline جدید نساز مگر برای مقدار داده‌ای مثل درصد meter |
| `static/fonts/*` | فونت‌های محلی و مجوزها | فایل فونت را بدون حفظ license حذف یا جایگزین نکن |

### قرارداد DOM ثابت

`app.js` به این نقاط اتصال وابسته است:

- `#top`: هدر و brand bar
- `#tabs`: تب‌های اصلی
- `#main`: محتوای route جاری
- `#primary`: دکمهٔ اقدام اصلی در حالت مرورگر؛ در تلگرام MainButton بومی استفاده می‌شود
- `#toasts`: پیام‌های موقت
- `#sheets`: میزبان bottom sheet / dialog

این IDها را rename نکن. اگر layout جدید لازم است، wrapper و class اضافه کن؛ نقاط اتصال را حفظ کن.

---

## 2. معماری اجرا و جریان راه‌اندازی

1. `index.html` Telegram WebApp SDK را بارگذاری می‌کند.
2. `app.js` به صورت ES module اجرا می‌شود و ماژول‌های TMA، i18n، post model و tg emoji را import می‌کند.
3. theme پیش از render اولیه از `localStorage` با کلید `vorn-theme` خوانده می‌شود؛ مقدارهای معتبر `light` و `dark` هستند.
4. در دستگاه ضعیف، بر اساس `navigator.hardwareConcurrency` و `navigator.deviceMemory`، ویژگی `data-perf="low"` روی `html` قرار می‌گیرد.
5. `bootTMA()` در صورت وجود Telegram WebApp، `ready()` و `expand()` را صدا می‌زند و APIهای جدیدتر را با version check فعال می‌کند.
6. در مرورگر خارج از تلگرام، برنامه تنها در صورت وجود `?dev=...` یا مقدار session ذخیره‌شدهٔ dev اجرا می‌شود.
7. `/api/me` کاربر و ترجیحات او را می‌آورد؛ زبان و timezone از پاسخ کاربر اعمال می‌شوند.
8. hash router route را انتخاب می‌کند و view مربوطه را render می‌کند.

### اصول معماری

- framework جدید اضافه نکن مگر دلیل فنی و برنامهٔ مهاجرت مشخص باشد. ساختار فعلی Vanilla JS ماژولار است.
- renderهای HTML باید با `M.escapeHtml` یا escape مناسب انجام شوند. دادهٔ API را مستقیم در template string تزریق نکن.
- منطق pure در `post-model.js` بماند؛ دسترسی DOM و side effect در `app.js` باشد.
- state فعلی در `state` نگه‌داری می‌شود: `me`, `emojis`, `posts`, `ed`, `pack`.
- `app.js` state manager جداگانه ندارد؛ تغییر معماری state باید اتمیک و همراه با حفظ جریان editor باشد.
- عملیات asynchronous باید state loading و خطای قابل فهم داشته باشند.

---

## 3. نقشهٔ routeها و قابلیت‌ها

روتر hash-based است و routeهای اصلی این‌ها هستند:

| Route | View | شرح |
|---|---|---|
| `#/` | Home | داشبورد، آمار، ظرفیت ایموجی، پست‌های اخیر و CTA |
| `#/emojis` | Emojis | لیست ایموجی رزروشده، جستجو، rename/delete، جستجوی پک و رزرو |
| `#/posts` | Posts | فهرست پست‌ها و ورود به ساخت/ویرایش |
| `#/post/new` | Editor | ساخت پست تازه |
| `#/post/:code` | Editor | دریافت و ویرایش پست موجود |

### 3.1 خانه

باید حفظ شود:

- تعداد پست‌ها (`me.posts`)
- تعداد ایموجی‌های استفاده‌شده و ظرفیت (`me.emoji.used`, `me.emoji.capacity`)
- نوار درصد مصرف ظرفیت
- دو اقدام واضح: ساخت پست و رزرو ایموجی
- حداکثر سه پست اخیر از `/posts?per=3`
- empty state در صورت نبود پست
- error state با retry در صورت شکست درخواست
- MainButton در صفحهٔ خانه برای ساخت پست

پیشنهاد UI:
- Hero فقط برای خوشامدگویی و هویت؛ آن را با چندین کارت تو در تو شلوغ نکن.
- آمار در دو کارت مستقل با عدد بزرگ و label کوچک.
- CTAها باید از کارت‌های محتوا متمایز باشند.
- پست‌های اخیر در یک لیست قابل اسکن با title، snippet، view، click، media و status.

### 3.2 مدیریت ایموجی‌ها

باید حفظ شود:

- بارگیری `/emojis`
- ظرفیت مصرفی و meter
- جستجوی debounce شده با `/emojis?q=...`
- بازگشت به لیست کامل با پاک شدن query
- بازکردن جزئیات هر ایموجی با انتخاب tile
- تغییر نام با `PATCH /emojis/:slot` و body برابر `{ name }`
- حذف با `DELETE /emojis/:slot` پس از confirmation
- لینک پک تلگرام و ارسال آن به `POST /emojis/pack` با body برابر `{ link }`
- نمایش نتیجهٔ pack، عنوان و تعداد آیتم‌ها و ظرفیت آزاد
- انتخاب/عدم انتخاب تکی و انتخاب همه
- رزرو با `POST /emojis/reserve` و body برابر `{ items }`
- نمایش تعداد افزوده، تکراری و پر بودن ظرفیت از پاسخ رزرو
- تازه‌سازی `/me` پس از رزرو موفق

نکات طراحی:
- grid tileها باید در موبایل حداقل سطح لمسی 44px داشته باشند.
- حالت انتخاب‌شده فقط با رنگ مشخص نشود؛ border، check/pressed state یا تفاوت ساختاری هم داشته باشد.
- جستجو باید focus واضح داشته باشد و هنگام تایپ layout نپرد.
- pack preview یک بخش مجزا باشد؛ دکمهٔ «انتخاب همه» وضعیت انتخاب فعلی را منعکس کند.
- خطاهای `not_emoji_pack` و `bad_pack_link` باید متن انسانی و قابل اقدام داشته باشند.

### 3.3 فهرست پست‌ها

باید حفظ شود:

- دریافت `/posts?per=50`
- empty state با اقدام ساخت پست
- کارت پست با عنوان یا snippet، تعداد بازدید، تعداد دکمه‌ها، وجود رسانه، tracking و expired status
- ورود به editor از طریق `#/post/:code`

پیشنهاد UI:
- عنوان و preview در اولویت؛ metadata در ردیف دوم.
- وضعیت expire و tracking با chip متنی نمایش داده شود، نه فقط رنگ.
- روی دسکتاپ دو یا سه ستون فقط وقتی فضای کافی هست؛ روی موبایل یک ستون.

### 3.4 ویرایشگر پست

این بخش از نظر ارزش محصول مهم‌ترین صفحه است. قابلیت‌های فعلی:

- دریافت پست موجود از `/posts/:code` یا ساخت draft جدید
- عنوان
- متن پست
- toolbar برای bold، italic، underline، strike، spoiler، code، quote، link و emoji picker
- نگهداری selection در textarea هنگام کلیک toolbar
- متغیرهای template: `name`, `first_name`, `username`, `id`, `group`, `date`, `time`, `code`, `views`
- شمارش طول متن با قواعد مدل
- پیش‌نمایش زندهٔ حباب پیام تلگرام
- media placeholder/metadata
- ردیف‌های inline keyboard
- هر ردیف ۱ تا ۳ دکمه؛ حداکثر ۸ ردیف
- URL validation
- expiry: حفظ تنظیم فعلی، انتخاب‌های از پیش تعریف‌شده، یا custom hours
- template mode
- click tracking
- save و delete
- dirty state و confirmation هنگام خروج
- MainButton بومی تلگرام یا sticky primary button در مرورگر

#### UX پیشنهادی ویرایشگر

**موبایل:**
- فرم و preview در یک ستون؛ preview بعد از فیلد متن یا در بخش collapsible قرار گیرد.
- toolbar قابل اسکرول افقی با hit target بزرگ.
- دکمهٔ ذخیره در MainButton تلگرام یا sticky bottom action بیرون تلگرام.
- sheetهای link و emoji picker باید فضای صفحه را رعایت کنند.

**دسکتاپ:**
- دو ستون: فرم در ستون اصلی، preview sticky در ستون کناری.
- preview نباید از viewport بیرون بزند.
- بخش‌های تنظیمات پیشرفته می‌توانند گروه‌بندی شوند اما نباید حذف شوند.

**Preview:**
- نمایش حبابی نزدیک به Telegram، با پس‌زمینهٔ ظریف و بدون تزئین سنگین.
- spoiler قابل reveal باشد.
- لینک‌ها در preview واقعی navigate نکنند.
- emojiهای رزروشده و custom emoji در preview حفظ شوند.
- تعداد view و inline keyboard در پیش‌نمایش دیده شود.

**Validation:**
- خطاها پیش از ارسال مشخص باشند.
- متن با رسانه: سقف 1024؛ بدون رسانه: سقف 4096 (طبق منطق فعلی کلاینت).
- پست خالی، دکمهٔ بدون متن، URL نامعتبر، تعداد ردیف نامعتبر و custom expiry خارج بازه باید reject شوند.
- خطا فقط در toast پنهان نشود؛ برای فرم‌های مهم باید کنار فیلد یا بخش مرتبط هم قابل فهم باشد.

---

## 4. قراردادهای API موجود در کلاینت

این جدول فقط endpointها و payloadهایی را ثبت می‌کند که در فرانت‌اند فعلی واقعاً استفاده شده‌اند. این سند جایگزین مستندات بک‌اند نیست و دربارهٔ رفتار سرور چیزی فراتر از کد ادعا نمی‌کند.

| Method | Path | کاربرد / payload مشاهده‌شده |
|---|---|---|
| GET | `/api/me` | اطلاعات کاربر، ترجیحات، موجودی، ظرفیت و mapping |
| PATCH | `/api/me` | ذخیرهٔ زبان با `{ lang }` |
| GET | `/api/posts?per=3` | پست‌های اخیر داشبورد |
| GET | `/api/posts?per=50` | فهرست پست‌ها |
| GET | `/api/posts/:code` | جزئیات پست برای ویرایش |
| POST | `/api/posts` | ساخت پست |
| PUT | `/api/posts/:code` | ذخیرهٔ تغییرات پست |
| DELETE | `/api/posts/:code` | حذف پست |
| GET | `/api/emojis` | ایموجی‌های رزروشده |
| GET | `/api/emojis?q=...` | جستجوی ایموجی |
| PATCH | `/api/emojis/:slot` | rename با `{ name }` |
| DELETE | `/api/emojis/:slot` | حذف ایموجی |
| POST | `/api/emojis/pack` | parse pack با `{ link }` |
| POST | `/api/emojis/reserve` | رزرو با `{ items }` |
| GET | `/api/custom-emoji/:id` | metadata برای نمایش custom emoji؛ توسط `tg-emoji.js` |

### هدر احراز هویت

- در Telegram WebApp: `Authorization: tma <initData>`
- در حالت توسعه: `Authorization: dev <token>`
- Content-Type برای درخواست‌های JSON برابر `application/json` است.
- توکن ربات نباید به مرورگر منتقل شود.

### قرارداد payload ساخت/ویرایش پست

کلاینت فعلی این payload را ارسال می‌کند:

```js
{
  title,
  text,                  // HTML تلگرام ساخته‌شده توسط post-model
  buttons_rows,           // آرایهٔ ردیف‌ها؛ هر دکمه متن و URL/type دارد
  template,
  track_clicks,
  expiry: { mode: 'keep' } // یا mode hours + hours یا یکی از presetهای EXP_MAP
}
```

مقادیر نهایی `EXP_MAP` را از کد فعلی بخوان؛ در بازطراحی آن را حدس نزن یا تغییر نده.

### مدل‌های پاسخ

در کد مصرف‌کننده، حداقل این فیلدها استفاده می‌شوند:

- `me`: `first_name`, `balance`, `posts`, `lang`, `tz`, `id`, `emoji.used`, `emoji.capacity`, `mapping`
- post list item: `code`, `title`, `snippet`, `views`, `buttons`, `media`, `track`, `expires_at`
- emoji item: `slot`, `id`, `char`, `name`, `pack`
- pack result: `title`, `items[]`, `free`; نتیجهٔ reserve: `added`, `duplicates`, `full`
- editor post: ساختار کامل را با نمونهٔ واقعی بک‌اند تطبیق بده؛ فرانت‌اند از فیلدهای title/text/buttons/template/track/expiry/media/views استفاده می‌کند.

**مهم:** نوع دقیق برخی فیلدها، pagination و schema کامل پاسخ سرور از فرانت‌اند به تنهایی قابل اثبات نیست. عامل بعدی باید در صورت نیاز از قرارداد بک‌اند یا fixture واقعی استفاده کند، نه اینکه schema را جعل کند.

---

## 5. مدل متن و HTML تلگرام

`post-model.js` متن و HTML را تبدیل می‌کند. فرمت متن ذخیره‌شده HTML تلگرام است و custom emoji در editor با token قابل خواندن `[emoji-id]` نشان داده می‌شود.

### تگ‌های مجاز و semantics

- `b` / `strong`
- `i` / `em`
- `u`
- `s` / `strike` / `del`
- `code`
- `pre`
- `blockquote` و حالت expandable
- `tg-spoiler`
- `a` فقط با URL مجاز
- `tg-emoji` با `emoji-id` عددی معتبر

### توابع مهم

| تابع | نقش |
|---|---|
| `htmlToEditable` | تبدیل custom emoji به token `[id]` و نگهداری fallback char |
| `editableToHtml` | تبدیل tokenها به `<tg-emoji>` |
| `applyReserved` | تبدیل emojiهای عادی رزروشده به custom emoji در متن، خارج از tag/code/pre |
| `sanitizeHtml` | allowlist تگ‌ها، پاک‌سازی attributeها و بستن تگ‌های باز |
| `visibleLength` | محاسبه طول متن قابل مشاهده |
| `fillVariables` | جایگزینی فقط متغیرهای شناخته‌شده با مقدار escaped |
| `wrapSelection` | wrap کردن selection در textarea |
| `insertAt` | درج متن در موقعیت caret |
| `validateButtons` | اعتبارسنجی تعداد و محتوای دکمه‌ها |

### قواعد امنیتی

- هیچ محتوای user/API را بدون escape در HTML template قرار نده.
- URL لینک باید scheme مجاز داشته باشد. در editor فعلی `http(s)` و `tg://` برای link sheet و `http(s)`, `tg://`, `mailto:` برای inline button دیده می‌شود؛ تفاوت را بدون هماهنگی تغییر نده.
- `sanitizeHtml` را حذف نکن یا با regex ساده جایگزین نکن.
- `fillVariables` باید فقط whitelist متغیرهای تعریف‌شده را جایگزین کند.
- token ایموجی باید ID عددی را حفظ کند؛ ID به متن دلخواه تبدیل نشود.

---

## 6. سیستم طراحی بصری

### 6.1 پالت رنگ

#### Light

| Token | مقدار | کاربرد |
|---|---|---|
| `--bg` | `#f5f8ff` | سطح اصلی |
| `--bg-2` | `#edf3fc` | زمینهٔ پشت کارت‌ها |
| `--section` | `#ffffff` | کارت، sheet، سطح کنترل |
| `--text` | `#101c32` | متن اصلی |
| `--hint` | `#65748d` | متن کمکی |
| `--brand` | `#087cf0` | اقدام اصلی / لینک / focus |
| `--brand-2` | `#42d4ff` | gradient highlight |
| `--danger` | `#d93d62` | خطا و destructive |
| `--ok` | `#138c68` | موفقیت |

#### Dark

| Token | مقدار | کاربرد |
|---|---|---|
| `--bg` | `#070c17` | سطح اصلی |
| `--bg-2` | `#090f1d` | زمینهٔ پشت کارت‌ها |
| `--section` | `#101a2b` | کارت و sheet |
| `--text` | `#eef5ff` | متن اصلی |
| `--hint` | `#91a4c0` | متن ثانویه |
| `--brand` | `#168cff` | آبی نئون |
| `--brand-2` | `#38d9ff` | cyan accent |
| `--danger` | `#ff7892` | خطا |
| `--ok` | `#51d9ae` | موفقیت |

قانون: رنگ‌های state را با رنگ برند اشتباه نگیر. خطا همیشه danger، موفقیت همیشه ok و اقدام اصلی brand باقی بماند.

### 6.2 تایپوگرافی

- فارسی: Noto Sans Arabic محلی، وزن‌های 400/500/600/700.
- انگلیسی: system UI / Inter در صورت نصب؛ fallback به فونت سیستم.
- اعداد آمار از `font-variant-numeric: tabular-nums` استفاده کنند.
- متن بدنه 14–16px؛ متن کمکی 12–14px؛ تیتر صفحه 24–34px بر اساس viewport.
- وزن زیاد را فقط برای heading، عدد و CTA استفاده کن؛ تمام labelها bold نباشند.

### 6.3 فاصله و اندازه

- مبنای spacing مضرب 4px باشد.
- فاصلهٔ بخش‌های اصلی 20–24px.
- padding کارت 16–24px.
- ارتفاع کنترل‌های لمسی حداقل 44px؛ کنترل اصلی 48–58px.
- شعاع کارت 18–22px؛ hero تا 30px؛ pill برای status و segmented.
- عرض محتوای دسکتاپ حداکثر حدود 1180px.

### 6.4 سایه و glow

- light shadow باید نرم و کم‌کنتراست باشد.
- dark shadow بیشتر برای جداسازی لایه‌ها استفاده شود؛ دور همهٔ کارت‌ها glow نده.
- glow فقط برای CTA اصلی، focus، انتخاب tile و برند hero.
- border از سایه مهم‌تر است؛ مرز سطح‌ها باید در هر دو تم قابل تشخیص باشد.

### 6.5 آیکن

- آیکن‌ها باید یک خانوادهٔ خطی با stroke تقریباً 1.8–2px باشند.
- اندازهٔ معمول 18–22px.
- آیکن تزئینی بدون متن جایگزین نیاز ندارد؛ دکمهٔ آیکنی باید `aria-label` داشته باشد.
- از emoji Unicode به‌عنوان جایگزین آیکن UI استفاده نکن؛ emoji برای محتواست، icon برای action.

---

## 7. تم روشن/تاریک

- attribute ریشه: `html[data-theme="light"]` یا `html[data-theme="dark"]`.
- storage key: `vorn-theme`.
- مقدار پیش‌فرض فعلی light است؛ تغییر به system theme فقط با تصمیم محصول انجام شود.
- toggle در هدر حضور دارد و باید در تمام routeها در دسترس باشد.
- تغییر تم باید بدون reload انجام شود.
- `meta[name="theme-color"]` باید با تم sync شود تا نوار مرورگر/موبایل هماهنگ باشد.
- هر دو تم باید تمام componentها را پوشش دهند: cards، form، sheet، toast، preview، skeleton، status، focus و disabled.
- رنگ hardcoded در component جدید ممنوع؛ از CSS custom properties استفاده کن.
- تم تلگرام نباید ناخواسته مقادیر سفارشی VORN را override کند؛ CSS variableهای `--tg-theme-*` را فقط اگر نیاز به fallback مشخص داری استفاده کن.

---

## 8. Motion system

### Motion tokens

- micro interaction: 120–180ms
- component transition: 180–260ms
- sheet: 240–320ms
- hero sheen: حرکت بسیار آهسته و کم‌توجه؛ در صورت distract شدن حذف شود.
- easing اصلی: `cubic-bezier(.2,.75,.25,1)`

### مجاز

- opacity/transform برای ورود و hover
- scale بسیار کم در pressed state
- progress fill برای meter
- shimmer فقط برای skeleton و با شدت پایین
- subtle sheen فقط در hero/CTA، نه روی تمام عناصر

### ممنوع

- انیمیشن دائمی برای هر کارت
- glow تپندهٔ شدید
- حرکت layout با تغییر height/width در hover
- انیمیشن‌هایی که باعث جابه‌جایی متن می‌شوند
- انیمیشن اجباری برای کاربر با `prefers-reduced-motion: reduce`

### Performance mode

وقتی `data-perf="low"` فعال است:
- backdrop-filter خاموش
- انیمیشن‌های تزئینی خاموش
- blurهای بزرگ حذف
- انیمیشن custom emoji همچنان با سقف concurrency خودش کنترل شود

---

## 9. Responsive behavior

### Breakpoints پیشنهادی

| بازه | رفتار |
|---|---|
| تا 420px | موبایل کوچک؛ یک ستون، padding کم، CTA تمام‌عرض |
| 421–719px | موبایل بزرگ؛ یک ستون، grid ایموجی منعطف |
| 720–1023px | تبلت؛ آمار دو ستون، لیست می‌تواند دو ستون شود |
| 1024px به بالا | دسکتاپ؛ editor دو ستون و preview sticky |

Container query فعلی برای `.app` وجود دارد؛ در اولویت با عرض container تصمیم بگیر نه صرفاً viewport.

### الزامات

- هیچ صفحه‌ای نباید horizontal scroll ناخواسته داشته باشد.
- ورودی URL و ID باید `dir="ltr"` داشته باشد.
- متن فارسی و رشته‌های لاتین در یک خط باید با `bdi` یا `unicode-bidi: isolate` از هم جدا شوند.
- safe area تلگرام (`--tg-safe-area-inset-*`) و `env(safe-area-inset-*)` باید رعایت شود.
- sticky bottom action باید با safe area فاصله داشته باشد و محتوای صفحه زیر آن پنهان نشود.
- bottom sheet در موبایل، dialog centered در دسکتاپ می‌تواند مناسب‌تر باشد؛ تغییر باید با keyboard و focus management تست شود.

---

## 10. Telegram Mini App integration

` tma.js` wrapper مرکزی است. اجزای کلیدی:

- `tg`, `inTelegram`, `has(version)`
- `bootTMA()` برای ready/expand و رنگ‌های Telegram UI
- `haptic.tap/tick/ok/warn/error`
- `syncBackButton(depth, goBack)`
- `setPrimary(...)` و `hidePrimary()`
- `setClosingConfirm(on)`
- `nativeConfirm(message)`
- `store.get/set` با CloudStorage یا localStorage fallback

### قواعد

- APIهای Telegram را فقط در صورت وجود و نسخهٔ مناسب صدا بزن.
- در مرورگر عادی crash نکن؛ fallback button و confirm باید کار کند.
- در editor dirty state باید هم confirmation داخلی و هم ClosingConfirmation تلگرام را درست sync کند.
- BackButton بومی باید با route depth هماهنگ باشد.
- MainButton بومی در Telegram، دکمهٔ sticky در مرورگر.
- haptic یک enhancement است؛ نبود آن نباید رفتار اصلی را مختل کند.
- از `initDataUnsafe` برای نمایش نمونهٔ preview می‌توان استفاده کرد؛ اعتبارسنجی هویت فقط سمت سرور انجام می‌شود.

---

## 11. Custom emoji rendering

`tg-emoji.js` نسخهٔ پیشرفتهٔ آپلودشده است و باید حفظ شود. رفتار مورد انتظار:

1. fallback متن یونیکد داخل `<tg-emoji>` در ابتدا حاضر است.
2. metadata از `/api/custom-emoji/:id` خوانده می‌شود.
3. تصویر ثابت واقعی (thumbnail یا webp) تلاش می‌شود.
4. اگر انیمیشن مجاز و ممکن بود، انیمیشن جایگزین تصویر ثابت می‌شود.
5. در خطای انیمیشن، تصویر ثابت باقی می‌ماند؛ در نبود تصویر ثابت، fallback متن حفظ می‌شود.
6. `IntersectionObserver` برای lazy loading استفاده می‌شود.
7. حداکثر 8 انیمیشن هم‌زمان مجاز است.
8. `prefers-reduced-motion` رعایت می‌شود.
9. iOS برای webm محدودیت دارد.
10. tab hidden باعث توقف انیمیشن‌ها می‌شود.
11. برای TGS، Lottie از مسیر local vendor و سپس CDN fallback می‌آید؛ در استقرار باید مسیر local واقعاً موجود باشد یا failure graceful باقی بماند.
12. object/resource باید در hide/disconnect آزاد شود.

### الزام عامل بعدی

- این فایل را با یک پیاده‌سازی ساده‌تر جایگزین نکن.
- اگر لود تصویر یا انیمیشن را اصلاح می‌کنی، تست کن که متن fallback هیچ‌وقت خالی نشود.
- metadata cache بعد از خطا باید قابل retry بماند.
- `IntersectionObserver`, `DecompressionStream`, `matchMedia`, `customElements` و `navigator` را با graceful fallback یا حداقل browser support مشخص کنترل کن.
- مسیر `/static/js/vendor/lottie.light.min.js` در این بسته تضمین نشده است؛ در محیط production باید asset واقعی نصب/کپی شود. فایل نباید با یک placeholder ساختگی پر شود.

---

## 12. Accessibility و کیفیت تعامل

- همهٔ دکمه‌ها و لینک‌ها با keyboard قابل دسترسی باشند.
- `:focus-visible` با کنتراست بالا و بدون حذف outline.
- icon-only button دارای `aria-label`.
- انتخاب pack با `aria-pressed` منعکس شود.
- loading region دارای `aria-busy` یا status قابل خواندن باشد.
- toast برای پیام غیر بحرانی `role="status"`; خطای فوری با `role="alert"` در صورت لزوم.
- sheet هنگام بازشدن focus را به محتوای مناسب ببرد و هنگام بستن focus را برگرداند؛ Escape آن را ببندد.
- hit target حداقل 44×44px.
- رنگ تنها راه انتقال status نباشد.
- متن کمکی در dark mode کنتراست کافی داشته باشد.
- `prefers-reduced-motion` باید به همهٔ motionها اعمال شود.
- ترتیب tab با ترتیب دیداری و معنایی DOM هماهنگ باشد.

---

## 13. Error, loading, empty و success states

هر view باید چهار وضعیت را طراحی کند:

| State | رفتار |
|---|---|
| Loading | skeleton با ابعاد نزدیک به محتوای واقعی؛ از spinner تنها برای عملیات کوتاه استفاده شود |
| Error | پیام قابل فهم + retry واقعی؛ stack trace یا متن خام سرور نمایش داده نشود |
| Empty | توضیح کوتاه و CTA مرتبط؛ فضای خالی بی‌هدف نباشد |
| Success | toast کوتاه + refresh state؛ از پیام موفقیت غیرواقعی پیش از پاسخ سرور پرهیز شود |

### API error mapping

`errText()` در app.js خطای شبکه و error code ترجمه‌شده را تبدیل می‌کند. کلیدهای جدید باید در `i18n.js` برای FA و EN تعریف شوند.

### Retry

- retry باید همان عملیات/route را دوباره اجرا کند.
- درخواست تکراری با query قبلی نباید race condition ایجاد کند.
- جستجو باید debounce و در صورت نیاز request cancellation داشته باشد؛ اگر عامل بعدی AbortController اضافه کرد، رفتار state را با نتایج دیررس محافظت کند.

---

## 14. امنیت و داده

- Telegram initData فقط به API backend ارسال شود.
- bot token و secret هیچ‌وقت در bundle یا HTML قرار نگیرد.
- تمام stringهای برگشتی از API در HTML escape شوند.
- linkها scheme allowlist داشته باشند.
- `sanitizeHtml` allowlist فعلی باید حفظ شود.
- dev token فقط برای محیط توسعه؛ در production نباید در URL عمومی یا log ذخیره شود.
- هیچ analytics/tracking جدیدی بدون اجازهٔ محصول اضافه نشود.
- localStorage فقط برای ترجیحات غیرحساس مثل theme استفاده شود؛ credential یا دادهٔ حساس ذخیره نشود.
- خطاهای API نباید اطلاعات احراز هویت را افشا کنند.

---

## 15. فونت‌ها و مجوزها

- Noto Sans Arabic برای متن فارسی/عربی محلی شده تا به شبکهٔ خارجی وابسته نباشد.
- چهار وزن Regular, Medium, SemiBold, Bold در مسیر `static/fonts/` قرار دارند.
- `Vorn-Emoji.ttf` یک subset کاربردی از Noto Color Emoji است (کدپوینت‌های رایج emoji presentation/modifier/base) تا fallback ایموجی در محیط‌های فاقد فونت emoji مناسب، به سیستم‌فونت خارجی وابسته نباشد؛ این subset جایگزین کامل تمام sequenceهای یونیکد یا Telegram custom emoji نیست.
- فایل‌های `OFL-Noto.txt` و `OFL-Noto-Color-Emoji.txt` مجوزهای فونت را همراه بسته نگه می‌دارند.
- از حذف license هنگام ساخت ZIP خودداری کن.
- برای کاهش حجم در production می‌توان فونت را subset کرد، اما فقط پس از تست پوشش حروف فارسی، عربی، اعداد، نشانه‌ها و لاتین.

---

## 16. قرارداد توسعه و کدنویسی

### JavaScript

- ES modules بماند.
- توابع pure از DOM جدا باشند.
- event listenerها روی root مناسب delegation شوند.
- در HTML template، تمام دادهٔ پویا escape شود.
- نام‌گذاری API payloadها را بی‌دلیل تغییر نده.
- state و DOM در یک تابع async به شکل قابل ردیابی به‌روزرسانی شوند.
- خطاها swallow نشوند مگر واقعاً optional باشند و comment علت را بگوید.
- هر fix امنیتی یا behavior change باید تست داشته باشد.

### CSS

- توکن‌ها در ابتدای فایل یا لایهٔ مستقل تعریف شوند.
- selectorها بر اساس component باشند، نه IDهای پراکنده.
- از `!important` فقط برای reduced motion یا override اضطراری با توضیح استفاده شود.
- از CSS logical properties (`margin-inline`, `padding-block`, `inset-inline`) استفاده کن.
- هر component هر دو تم را پوشش دهد.
- animation با transform/opacity باشد.
- breakpoints و container queries با هم تناقض نداشته باشند.

### HTML

- semantic elementها: header/nav/main/section/form/button.
- form controls label داشته باشند.
- script module در پایان head با defer behavior native.
- metadata theme-color با theme همگام باشد.

---

## 17. راه‌اندازی و اجرای محلی

این فرانت‌اند به backend موجود متصل است و mock backend داخل بسته نیست.

1. فایل‌ها را در مسیر static پروژهٔ سرور قرار بده.
2. `index.html` باید در root قابل دسترسی باشد.
3. مسیرهای absolute `/static/...` باید با routeهای استقرار تطبیق داشته باشند.
4. backend باید endpointهای بخش 4 را فراهم کند.
5. برای اجرای خارج از Telegram از `?dev=<development-token>` استفاده کن؛ dev auth فقط در محیط توسعه فعال باشد.
6. برای اجرای تست‌های مدل: `npm test`.
7. برای بررسی syntax و مسیرهای استاتیک: `npm run verify`.

### نکتهٔ استقرار

در کد emoji، مسیر محلی Lottie این است:

`/static/js/vendor/lottie.light.min.js`

این vendor در این بسته قرار نگرفته، چون فایل معتبر آن در منابع موجود نبود و نباید فایل جعلی یا placeholder به عنوان کتابخانهٔ واقعی تحویل شود. اگر انیمیشن TGS باید کاملاً offline باشد، نسخهٔ رسمی lottie-web light را از منبع معتبر پروژه اضافه و license آن را همراهش نگه دار. fallback CDN فعلی در کد وجود دارد.

---

## 18. تست و معیار پذیرش

### تست‌های smoke

- همهٔ فایل‌های JS parse شوند.
- importهای محلی resolve شوند.
- `index.html` تمام IDهای مورد نیاز app را داشته باشد.
- CSS و فونت‌ها از مسیرهای موجود load شوند.
- `post-model` unit test پاس شود.

### تست عملکردی دستی

#### Telegram
- [ ] app در Telegram WebApp باز شود.
- [ ] `ready()` و `expand()` بدون خطا اجرا شوند.
- [ ] BackButton در routeهای تو در تو نمایش داده شود.
- [ ] MainButton متن/disabled/loading صحیح داشته باشد.
- [ ] dirty editor هنگام خروج confirmation نشان دهد.
- [ ] haptic نبودن API را تحمل کند.

#### Home
- [ ] آمار و recent posts نمایش داده شوند.
- [ ] empty/error/retry کار کند.
- [ ] CTAها به route صحیح بروند.

#### Emojis
- [ ] جستجو و پاک‌کردن query کار کند.
- [ ] rename/delete با تأیید و refresh درست باشد.
- [ ] pack parse، انتخاب تکی/همه و reserve درست کار کند.
- [ ] capacity و نتیجهٔ reserve به‌روز شود.
- [ ] custom emoji ابتدا fallback و سپس تصویر/انیمیشن را نمایش دهد.

#### Posts / Editor
- [ ] فهرست و empty state درست باشد.
- [ ] create/edit/delete کار کند.
- [ ] toolbar selection را حفظ کند.
- [ ] preview بعد از تایپ سریع به‌روز شود.
- [ ] template variables درج شوند.
- [ ] inline keyboard با سقف ۸ ردیف و ۳ دکمه در هر ردیف کنترل شود.
- [ ] validation طول متن و URL کار کند.
- [ ] expiry و tracking در payload حفظ شوند.
- [ ] dirty state و save state صحیح باشند.

#### Visual QA
- [ ] Light و Dark در تمام routeها بررسی شوند.
- [ ] 360px، 390px، 768px، 1024px و 1440px بررسی شوند.
- [ ] RTL و LTR جداگانه بررسی شوند.
- [ ] reduced motion بررسی شود.
- [ ] هیچ horizontal overflow نباشد.
- [ ] focus keyboard قابل مشاهده باشد.
- [ ] modal/sheet روی صفحه‌کلید موبایل نپوشاند.

### تعریف Done

کار فقط وقتی Done است که تمام رفتارهای فعلی حفظ شده، smoke test پاس شده، routeها و حالت‌های خطا تست شده، و ظاهر هر دو تم در موبایل و دسکتاپ بررسی شده باشد. صرفاً تغییر رنگ یا افزودن animation به معنی تکمیل بازطراحی نیست.

---

## 19. راهنمای عامل هوش مصنوعی بعدی

اگر یک AI دیگر این پروژه را دریافت کرد، این ترتیب را دنبال کند:

1. ابتدا کل `FRONTEND_SPEC_FA.md` را بخوان.
2. سپس `index.html`, `app.js`, `post-model.js`, `tma.js`, `tg-emoji.js`, `i18n.js` و `app.css` را کامل بخوان.
3. هیچ قابلیت موجودی را صرفاً به دلیل پیچیدگی حذف نکن.
4. ابتدا نقشهٔ کامپوننت‌ها و routeها را با کد تطبیق بده؛ اگر اختلافی دیدی، کد موجود را مرجع رفتار فعلی و این سند را مرجع هدف طراحی بدان.
5. قبل از تغییر API، قرارداد backend را مطالبه کن؛ schema را حدس نزن.
6. ابتدا design tokens و shell را اصلاح کن، سپس Home، Emojis، Posts و Editor را به ترتیب polish کن.
7. برای هر route loading/error/empty/success را نگه دار.
8. فایل custom emoji را ساده‌سازی نکن.
9. پس از هر مرحله `npm test` و `npm run verify` اجرا کن.
10. در پایان checklist بخش 18 را کامل کن و هر موردی که به دلیل نبود backend قابل تست نیست صریح گزارش کن.

### چیزهایی که نباید انجام دهد

- حذف قابلیت‌های قدیمی برای ساده کردن UI
- بازنویسی APIها با endpoint فرضی
- جایگزینی Telegram Mini App API با mock
- حذف HTML sanitizer یا escape
- ساخت انیمیشن‌های بی‌هدف برای بزرگ کردن bundle
- اضافه کردن dependency سنگین فقط برای افکت
- اضافه کردن فایل‌های حجیم غیرقابل استفاده برای رسیدن صوری به حجم ZIP
- ادعای تست backend بدون اتصال واقعی به backend

---

## 20. تصمیم‌های طراحی اعمال‌شده در این بسته

- پالت Neon Blue با Light/Dark مستقل
- هویت بصری hero با gradient چندلایه و glow محدود
- کارت‌ها با border واضح، shadow نرم و radius یکپارچه
- segmented tabs با indicator و کنتراست بهتر
- آمار با اعداد tabular و سلسله‌مراتب قوی‌تر
- tileهای ایموجی با hit area و selected state بهتر
- فرم‌ها و toolbar با ارتفاع لمس مناسب
- preview با زمینهٔ ظریف و حباب واضح‌تر
- sheet و sticky primary action با شعاع و فاصلهٔ بهتر
- فونت محلی Noto Sans Arabic برای فارسی/عربی
- `meta theme-color` برای هماهنگی نوار مرورگر با تم
- احترام به `prefers-reduced-motion` و `data-perf="low"`

این بسته یک **تحویل فرانت‌اند** است، نه backend و نه تضمین نهایی اتصال production. هر ادعای نهایی دربارهٔ عملکرد API باید با backend واقعی تأیید شود.

## الحاقیه‌ی جهت بصری Floating Glass 3D
نسخه‌ی فعلی باید حس «شیء شیشه‌ای شناور روی نمایشگر» منتقل کند، نه صرفاً کارت تخت با blur. پالت اصلی بنفش الکتریکی، آبی فیروزه‌ای و هایلایت‌های سفید است. هدر Hero با گرادیان چندمنبعی، لبه‌ی روشن، سایه‌ی عمیق و کره/حجم شیشه‌ای تزئینی ساخته شده است. کارت‌ها، آمار، تب‌ها، کاشی‌های ایموجی، پیش‌نمایش و Sheet از سطوح نیمه‌شفاف، backdrop blur، saturation، انعکاس داخلی و سایه‌های چندلایه استفاده می‌کنند. دکمه‌های اصلی برجستگی دارند (سایه‌ی زیرین به‌عنوان ضخامت) و در active به پایین فشرده می‌شوند. در hover دسکتاپ، کارت‌ها با perspective اندکی بالا می‌آیند؛ در موبایل حالت پایه‌ی برجسته حفظ می‌شود. برای prefers-reduced-motion و data-perf=low افکت‌های حرکتی/blur سنگین کاهش می‌یابند. این لایه صرفاً CSS است و قراردادهای API، مدل پست، جریان Telegram Mini App و قابلیت‌های موجود را تغییر نمی‌دهد.
