import test from 'node:test';
import assert from 'node:assert/strict';
import * as M from '../static/js/post-model.js';

test('HTML escaping protects text nodes', () => {
  assert.equal(M.escapeHtml('<script a="b">&'), '&lt;script a=&quot;b&quot;&gt;&amp;');
});

test('premium emoji tokens round-trip through editable text', () => {
  const parsed = M.htmlToEditable('<b>Hello</b><tg-emoji emoji-id="12345678901">⭐</tg-emoji>');
  assert.equal(parsed.text, '<b>Hello</b>[12345678901]');
  assert.equal(parsed.chars['12345678901'], '⭐');
  assert.equal(M.editableToHtml(parsed.text, parsed.chars), '<b>Hello</b><tg-emoji emoji-id="12345678901">⭐</tg-emoji>');
});

test('sanitizer removes unsafe tags and unsafe links', () => {
  const safe = M.sanitizeHtml('<script>alert(1)</script><a href="javascript:alert(1)">bad</a><b>good</b>');
  assert.equal(safe.includes('<script'), false);
  assert.equal(safe.includes('javascript:'), false);
  assert.equal(safe.includes('<b>good</b>'), true);
});

test('visible length ignores formatting tags', () => {
  assert.equal(M.visibleLength('<b>سلام</b> دنیا'), 9);
});

test('template filling replaces only known variables and escapes values', () => {
  assert.equal(M.fillVariables('Hi {name} {unknown}', { name: '<Ali>' }), 'Hi &lt;Ali&gt; {unknown}');
});

test('selection wrapping preserves surrounding content', () => {
  const result = M.wrapSelection('hello world', 6, 11, '<b>', '</b>');
  assert.deepEqual(result, { value: 'hello <b>world</b>', selStart: 9, selEnd: 14 });
});

test('button validation enforces non-empty labels and URL schemes', () => {
  assert.deepEqual(M.validateButtons([[{ text: 'Open', url: 'https://example.com' }]]), []);
  assert.ok(M.validateButtons([[{ text: 'Open', url: 'javascript:alert(1)' }]]).includes('err_btn_url'));
  assert.ok(M.validateButtons([[{ text: '', url: 'https://example.com' }]]).includes('err_btn_text'));
});
