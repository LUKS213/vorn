// app.js — مینی‌اپ مدیریت: خانه · اموجی‌ها (رزرو/اسم/جستجو/رزرو از پک) · پست‌ها (سازنده با پیش‌نمایش زنده)
import { tg, inTelegram, bootTMA, haptic, syncBackButton, setPrimary, hidePrimary, setClosingConfirm, nativeConfirm, store } from './tma.js';
import { t, setLang, getLang, fmtNum, fmtDate, fmtDateOnly, fmtTime, setTimeZone } from './i18n.js';
import * as M from './post-model.js';
import './tg-emoji.js';

const $ = (sel, root = document) => root.querySelector(sel);
const esc = M.escapeHtml;
const main = $('#main');
const state = { me: null, emojis: null, posts: null, ed: null, pack: null };

// تمِ روشن/تاریک مستقل از تمِ سیستمی تلگرام؛ انتخاب کاربر ذخیره می‌شود.
function applyTheme(theme) {
  const next = theme === 'dark' ? 'dark' : 'light';
  document.documentElement.dataset.theme = next;
  const themeMeta = document.querySelector('meta[name="theme-color"]');
  if (themeMeta) themeMeta.content = next === 'dark' ? '#070c17' : '#f5f8ff';
  try { localStorage.setItem('vorn-theme', next); } catch { /* storage ممکن است در WebView بسته باشد */ }
  return next;
}
let activeTheme = 'light';
try { activeTheme = localStorage.getItem('vorn-theme') === 'dark' ? 'dark' : 'light'; } catch { /* default روشن */ }
applyTheme(activeTheme);

if ((navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 2) document.documentElement.dataset.perf = 'low';

// ── آیکن‌ها (SVG خطی، ۲۴×۲۴) ─────────────────────────────────────────────
const P = {
  home: 'M4 11l8-7 8 7v9H4zM10 20v-6h4v6', smile: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM8.5 14.5a4.5 4.5 0 0 0 7 0M9 9.5h.01M15 9.5h.01',
  doc: 'M7 3h7l4 4v14H7zM14 3v4h4M10 12h5M10 16h5', plus: 'M12 5v14M5 12h14', search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-4.3-4.3',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3', link: 'M10 13a5 5 0 0 0 7.1 0l2.8-2.8a5 5 0 0 0-7.1-7.1l-1.6 1.6M14 11a5 5 0 0 0-7.1 0l-2.8 2.8a5 5 0 0 0 7.1 7.1l1.6-1.6',
  chev: 'M9 6l6 6-6 6', check: 'M5 12.5l4.5 4.5L19 7.5', x: 'M6 6l12 12M18 6L6 18', eye: 'M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  coin: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9.5 9.5h4a1.5 1.5 0 0 1 0 3h-3a1.5 1.5 0 0 0 0 3h4M12 7.5v1M12 15.5v1', globe: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18',
  star: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z', image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M9 9.5h.01',
  sun: 'M12 3v2M12 19v2M3 12h2M19 12h2M5.64 5.64l1.42 1.42m9.88 9.88 1.42 1.42m0-12.72-1.42 1.42m-9.88 9.88-1.42 1.42M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z', moon: 'M20.5 14.5A8.5 8.5 0 0 1 9.5 3.5 8.5 8.5 0 1 0 20.5 14.5z',
  clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2', mouse: 'M7 3l10 8-4.5 1 2.5 5.5-2.5 1-2.5-5.5L6 17z',
};
const icon = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="${P[n]}"/></svg>`;

// ── ابزارها ───────────────────────────────────────────────────────────────
function h(html) { const tpl = document.createElement('template'); tpl.innerHTML = html.trim(); return tpl.content.firstElementChild; }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const debounce = (fn, ms) => { let id; return (...a) => { clearTimeout(id); id = setTimeout(() => fn(...a), ms); }; };

const DEV = new URLSearchParams(location.search).get('dev') || sessionStorage.getItem('dev') || '';
if (DEV) sessionStorage.setItem('dev', DEV);

async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (tg?.initData) headers.Authorization = `tma ${tg.initData}`;
  else if (DEV) headers.Authorization = `dev ${DEV}`;
  const r = await fetch(`/api${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  let data = null;
  try { data = await r.json(); } catch { /* بدنه‌ی خالی */ }
  if (!r.ok) throw Object.assign(new Error(data?.message || data?.error || String(r.status)), { status: r.status, code: data?.error, server: data?.message });
  return data;
}
function errText(e) {
  if (e instanceof TypeError) return t('offline');
  if (e?.code && t(e.code) !== e.code) return t(e.code);
  return e?.server || t('server_error');
}

function toast(msg, kind = 'info') {
  const el = h(`<div class="toast toast-${kind}" role="status">${esc(msg)}</div>`);
  $('#toasts').appendChild(el);
  requestAnimationFrame(() => el.classList.add('in'));
  setTimeout(() => { el.classList.remove('in'); setTimeout(() => el.remove(), 250); }, 2600);
}

// ── Sheet (پنجره‌ی پایین‌کشو) ─────────────────────────────────────────────
let lastFocus = null;
function openSheet({ title, body, onMount }) {
  lastFocus = document.activeElement;
  const el = h(`<div class="sheet-wrap"><div class="scrim"></div><section class="sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="grip" aria-hidden="true"></div><header class="sheet-h"><h2>${esc(title)}</h2><button class="icon-btn" data-close aria-label="${esc(t('close'))}">${icon('x')}</button></header>
    <div class="sheet-b"></div></section></div>`);
  $('.sheet-b', el).append(body);
  $('#sheets').appendChild(el);
  const close = () => { el.classList.remove('in'); setTimeout(() => el.remove(), 220); document.removeEventListener('keydown', onKey); lastFocus?.focus?.(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  el.addEventListener('click', (e) => { if (e.target.closest('[data-close]') || e.target.classList.contains('scrim')) close(); });
  requestAnimationFrame(() => { el.classList.add('in'); $('input,button.primary,textarea', el)?.focus({ preventScroll: true }); });
  onMount?.(el, close);
  return { el, close };
}
async function ask(message) {
  const native = await nativeConfirm(message);
  if (native !== null) return native;
  return new Promise((resolve) => {
    const body = h(`<div><p class="sheet-p">${esc(message)}</p><div class="row-actions"><button class="btn ghost" data-no>${esc(t('no'))}</button><button class="btn danger" data-yes>${esc(t('yes'))}</button></div></div>`);
    let answered = false;
    const { close } = openSheet({ title: '', body });
    const fin = (v) => { if (!answered) { answered = true; close(); resolve(v); } };
    body.querySelector('[data-yes]').onclick = () => fin(true);
    body.querySelector('[data-no]').onclick = () => fin(false);
  });
}

// ── رندرِ تکه‌های مشترک ───────────────────────────────────────────────────
const skeleton = (n = 3) => `<div class="skel-list" aria-busy="true" aria-label="${esc(t('loading'))}">${'<div class="skel"></div>'.repeat(n)}</div>`;
const errorBox = (msg) => `<div class="state"><p>${esc(msg)}</p><button class="btn" data-retry>${esc(t('retry'))}</button></div>`;
const illus = `<svg class="illus" viewBox="0 0 96 96" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><path d="M48 8l9 9h13v13l9 9-9 9v13H57l-9 9-9-9H26V57l-9-9 9-9V26h13z" opacity=".35"/><path d="M48 24l5 11 12 1-9 8 3 12-11-6-11 6 3-12-9-8 12-1z"/></g></svg>`;
const emptyState = (title, hint) => `<div class="state empty">${illus}<h3>${esc(title)}</h3><p>${esc(hint)}</p></div>`;

function postCard(p) {
  const expired = p.expires_at && p.expires_at * 1000 <= Date.now();
  const title = p.title || p.snippet || '—';
  const chips = [`${icon('eye')}${fmtNum(p.views)}`, p.buttons ? `${icon('mouse')}${fmtNum(p.buttons)}` : '', p.media ? `${icon('image')}` : '',
    p.track ? `<span class="chip-ok">${esc(t('post_tracked'))}</span>` : '', expired ? `<span class="chip-bad">${esc(t('post_expired'))}</span>` : ''].filter(Boolean);
  return `<a class="card row-card" href="#/post/${p.code}"><div class="row-main"><strong class="clamp1">${esc(title)}</strong>
    <p class="clamp2 muted">${esc(p.title ? p.snippet : '')}</p><div class="chips">${chips.map((c) => `<span class="chip">${c}</span>`).join('')}</div></div>${icon('chev', 'chev')}</a>`;
}

// ── Chrome: هدر و تب‌ها ───────────────────────────────────────────────────
const TABS = [['home', '#/', 'tab_home'], ['emojis', '#/emojis', 'tab_emojis'], ['posts', '#/posts', 'tab_posts']];
function renderChrome(tab, { compactTitle } = {}) {
  const me = state.me;
  const top = $('#top');
  top.className = `top${tab === 'home' ? ' hero' : ''}`;
  const back = compactTitle && !inTelegram ? `<a class="icon-btn glass" href="#/posts" aria-label="${esc(t('close'))}">${icon('chev', 'back-ic')}</a>` : '';
  top.innerHTML = `<div class="top-row"><div class="brand">${back}<span class="logo" aria-hidden="true">${icon('star')}</span><span>${esc(compactTitle || t('app_name'))}</span></div>
    <div class="top-actions">${me ? `<span class="pill" title="${esc(t('coins'))}">${icon('coin')}<b>${fmtNum(me.balance)}</b></span>` : ''}
    <button class="icon-btn glass theme-toggle" id="theme-btn" aria-label="${getLang() === 'fa' ? (activeTheme === 'dark' ? 'روشن کردن تم' : 'تاریک کردن تم') : (activeTheme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme')}" title="${getLang() === 'fa' ? (activeTheme === 'dark' ? 'تم روشن' : 'تم تاریک') : (activeTheme === 'dark' ? 'Light theme' : 'Dark theme')}">${icon(activeTheme === 'dark' ? 'sun' : 'moon')}</button>
    <button class="icon-btn glass" id="lang-btn" aria-label="${esc(t('lang_switch'))}" title="${esc(t('lang_switch'))}">${icon('globe')}</button></div></div>
    ${tab === 'home' && me ? `<div class="hero-copy"><h1>${esc(t('hello', { name: me.first_name || '' }))}</h1><p>${esc(t('hello_sub'))}</p></div>` : ''}`;
  const tabs = $('#tabs');
  tabs.hidden = !tab;
  if (tab) {
    const i = TABS.findIndex((x) => x[0] === tab);
    tabs.style.setProperty('--i', i);
    tabs.innerHTML = `<span class="ind" aria-hidden="true"></span>${TABS.map(([k, href, key]) =>
      `<a role="tab" href="${href}" aria-selected="${k === tab}" class="tab${k === tab ? ' on' : ''}">${esc(t(key))}</a>`).join('')}`;
  }
  $('#theme-btn').onclick = () => {
    activeTheme = applyTheme(activeTheme === 'dark' ? 'light' : 'dark');
    haptic.tick();
    const btn = $('#theme-btn');
    btn.innerHTML = icon(activeTheme === 'dark' ? 'sun' : 'moon');
    const fa = getLang() === 'fa';
    btn.setAttribute('aria-label', fa ? (activeTheme === 'dark' ? 'روشن کردن تم' : 'تاریک کردن تم') : (activeTheme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'));
    btn.title = fa ? (activeTheme === 'dark' ? 'تم روشن' : 'تم تاریک') : (activeTheme === 'dark' ? 'Light theme' : 'Dark theme');
  };
  $('#lang-btn').onclick = async () => {
    const next = getLang() === 'fa' ? 'en' : 'fa';
    haptic.tick();
    setLang(next);
    try { await api('/me', { method: 'PATCH', body: { lang: next } }); } catch { /* فقط ترجیحِ ذخیره‌شده‌ست */ }
    route(true);
  };
}

// ── روتر ─────────────────────────────────────────────────────────────────
const parseRoute = () => {
  const h2 = location.hash.replace(/^#\/?/, '');
  const [a, b] = h2.split('/');
  if (!a) return { name: 'home' };
  if (a === 'emojis') return { name: 'emojis' };
  if (a === 'posts') return { name: 'posts' };
  if (a === 'post' && b) return { name: 'editor', code: b };
  return { name: 'home' };
};
function go(hash) { if (location.hash === hash) route(true); else location.hash = hash; }

async function guardLeave() {
  if (state.ed?.dirty) {
    const ok = await ask(t('ed_discard'));
    if (!ok) return false;
    state.ed.dirty = false;
    setClosingConfirm(false);
  }
  return true;
}
let current = '';
window.addEventListener('hashchange', async () => {
  if (state.ed?.dirty && !location.hash.startsWith('#/post/')) {
    const target = location.hash;
    history.replaceState(null, '', current || '#/posts');
    if (!(await guardLeave())) return;
    location.hash = target;
    return;
  }
  route();
});

async function route(force = false) {
  const r = parseRoute();
  const key = JSON.stringify(r);
  if (!force && key === current) return;
  current = location.hash || '#/';
  hidePrimary();
  state.ed = r.name === 'editor' ? state.ed : null;
  window.scrollTo(0, 0);
  syncBackButton(r.name === 'editor' ? 1 : 0, async () => { if (await guardLeave()) go('#/posts'); });
  if (!state.me) { renderChrome(null); main.innerHTML = skeleton(); return; }
  if (r.name === 'home') return viewHome();
  if (r.name === 'emojis') return viewEmojis();
  if (r.name === 'posts') return viewPosts();
  return viewEditor(r.code);
}

async function loadMe() {
  state.me = await api('/me');
  setLang(state.me.lang);
  setTimeZone(state.me.tz);
}
const bindRetry = (fn) => main.querySelector('[data-retry]')?.addEventListener('click', fn);

// ── خانه ─────────────────────────────────────────────────────────────────
async function viewHome() {
  renderChrome('home');
  main.innerHTML = skeleton(3);
  try {
    const [me, posts] = await Promise.all([api('/me'), api('/posts?per=3')]);
    state.me = me;
    renderChrome('home');
    const e = me.emoji, pct = e.capacity ? Math.min(100, Math.round((e.used / e.capacity) * 100)) : 0;
    main.innerHTML = `<div class="stats" data-region="content">
        <div class="stat"><span class="stat-ic">${icon('doc')}</span><b>${fmtNum(me.posts)}</b><span>${esc(t('stat_posts'))}</span></div>
        <div class="stat"><span class="stat-ic">${icon('smile')}</span><b>${fmtNum(e.used)}<small>/${fmtNum(e.capacity)}</small></b><span>${esc(t('stat_emoji'))}</span>
          <div class="meter" style="--p:${pct}%"><i></i></div></div></div>
      <div class="actions"><a class="act" href="#/post/new">${icon('plus')}<span>${esc(t('act_new_post'))}</span></a>
        <a class="act alt" href="#/emojis">${icon('smile')}<span>${esc(t('act_reserve'))}</span></a></div>
      <div class="sec-h"><h2>${esc(t('recent_posts'))}</h2><a href="#/posts">${esc(t('see_all'))}</a></div>
      <div class="list">${posts.items.length ? posts.items.map(postCard).join('') : emptyState(t('posts_empty'), t('posts_empty_hint'))}</div>`;
    setPrimary({ text: t('act_new_post'), onClick: () => { haptic.tap(); go('#/post/new'); } });
  } catch (e) {
    main.innerHTML = errorBox(errText(e));
    bindRetry(() => route(true));
  }
}

// ── اموجی‌ها ─────────────────────────────────────────────────────────────
const emojiTile = (e) => `<button class="tile" data-slot="${e.slot}" aria-label="${esc(e.name || e.char)}"><span class="tile-e"><tg-emoji emoji-id="${esc(e.id)}">${esc(e.char)}</tg-emoji></span><span class="tile-n clamp2">${esc(e.name || t('emo_unnamed'))}</span></button>`;

async function viewEmojis() {
  renderChrome('emojis');
  main.innerHTML = skeleton(2);
  try {
    state.emojis = await api('/emojis');
  } catch (e) { main.innerHTML = errorBox(errText(e)); bindRetry(() => route(true)); return; }
  const d = state.emojis;
  const pct = d.capacity ? Math.min(100, Math.round((d.used / d.capacity) * 100)) : 0;
  main.innerHTML = `<section class="card" data-region="content"><div class="cap"><span>${esc(t('emo_used', { used: fmtNum(d.used), cap: fmtNum(d.capacity) }))}</span>
      <div class="meter" style="--p:${pct}%"><i></i></div></div>
      <label class="search">${icon('search')}<input id="q" type="search" inputmode="search" enterkeyhint="search" autocomplete="off" placeholder="${esc(t('emo_search'))}" aria-label="${esc(t('emo_search'))}"></label>
      <div id="grid" class="grid"></div></section>
    <section class="card pack" id="pack-card"><h2>${esc(t('pack_title'))}</h2><p class="muted">${esc(t('pack_hint'))}</p>
      <form id="pack-form" class="inline-form"><input id="pack-in" dir="ltr" inputmode="url" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="${esc(t('pack_placeholder'))}" aria-label="${esc(t('pack_title'))}">
      <button class="btn" type="submit">${esc(t('pack_find'))}</button></form><div id="pack-out"></div></section>`;
  const grid = $('#grid');
  const paint = (items) => {
    grid.innerHTML = items.length ? items.map(emojiTile).join('') : `<div class="state empty span-all">${illus}<h3>${esc(t(state.emojis.items.length ? 'emo_none_found' : 'emo_empty'))}</h3>${state.emojis.items.length ? '' : `<p>${esc(t('emo_empty_hint'))}</p>`}</div>`;
  };
  paint(d.items);
  const search = debounce(async (q) => {
    try { const r = await api(`/emojis?q=${encodeURIComponent(q)}`); paint(r.items); } catch (e) { toast(errText(e), 'error'); }
  }, 250);
  $('#q').addEventListener('input', (e) => (e.target.value.trim() ? search(e.target.value.trim()) : paint(state.emojis.items)));
  grid.addEventListener('click', (e) => { const b = e.target.closest('.tile'); if (b) { haptic.tap(); openEmojiSheet(b.dataset.slot); } });
  $('#pack-form').addEventListener('submit', (e) => { e.preventDefault(); findPack($('#pack-in').value.trim()); });
  if (state.pack) renderPack();
}

function openEmojiSheet(slot) {
  const e = state.emojis.items.find((x) => x.slot === slot);
  if (!e) return;
  const body = h(`<div class="emo-sheet"><div class="big-e"><tg-emoji emoji-id="${esc(e.id)}">${esc(e.char)}</tg-emoji></div>
    <label class="field"><span>${esc(t('emo_rename'))}</span><input id="rn" maxlength="40" value="${esc(e.name || '')}" placeholder="${esc(t('emo_unnamed'))}"></label>
    <dl class="kv"><dt>${esc(t('emo_id'))}</dt><dd dir="ltr">${esc(e.id)}</dd>${e.pack ? `<dt>${esc(t('emo_pack'))}</dt><dd dir="ltr">${esc(e.pack)}</dd>` : ''}</dl>
    <div class="row-actions"><button class="btn danger ghost" data-del>${icon('trash')}${esc(t('emo_delete'))}</button><button class="btn primary" data-save>${esc(t('emo_save'))}</button></div></div>`);
  const { close } = openSheet({ title: `${e.char} ${e.name || ''}`.trim(), body });
  body.querySelector('[data-save]').onclick = async () => {
    try { await api(`/emojis/${slot}`, { method: 'PATCH', body: { name: $('#rn', body).value } }); haptic.ok(); toast(t('emo_renamed'), 'ok'); close(); route(true); }
    catch (er) { haptic.error(); toast(errText(er), 'error'); }
  };
  body.querySelector('[data-del]').onclick = async () => {
    if (!(await ask(t('emo_delete_confirm')))) return;
    try { await api(`/emojis/${slot}`, { method: 'DELETE' }); haptic.ok(); toast(t('emo_deleted'), 'ok'); close(); route(true); }
    catch (er) { haptic.error(); toast(errText(er), 'error'); }
  };
}

async function findPack(link) {
  const out = $('#pack-out');
  if (!link) return;
  out.innerHTML = skeleton(1);
  try {
    const r = await api('/emojis/pack', { method: 'POST', body: { link } });
    state.pack = { ...r, sel: new Set(r.items.map((i) => i.id)) };
    renderPack();
  } catch (e) {
    state.pack = null;
    out.innerHTML = `<p class="err">${esc(e.code === 'not_emoji_pack' ? t('pack_not_emoji') : e.code === 'bad_pack_link' ? t('pack_bad') : errText(e))}</p>`;
    haptic.error();
  }
}
function renderPack() {
  const p = state.pack, out = $('#pack-out');
  if (!out || !p) return;
  out.innerHTML = `<div class="pack-h"><strong>${esc(p.title)}</strong><span class="muted">${esc(t('pack_found', { n: fmtNum(p.items.length), free: fmtNum(p.free) }))}</span>
    <button class="btn ghost sm" data-all>${esc(t('pack_select_all'))}</button></div>
    <div class="grid pack-grid">${p.items.map((i) => `<button class="tile mini${p.sel.has(i.id) ? ' on' : ''}" data-id="${esc(i.id)}" aria-pressed="${p.sel.has(i.id)}"><span class="tile-e"><tg-emoji emoji-id="${esc(i.id)}">${esc(i.char)}</tg-emoji></span></button>`).join('')}</div>`;
  const update = () => {
    const n = p.sel.size;
    setPrimary({ text: t('pack_reserve', { n: fmtNum(n) }), disabled: n === 0, onClick: reservePack });
  };
  out.querySelector('.pack-grid').onclick = (e) => {
    const b = e.target.closest('.tile'); if (!b) return;
    const id = b.dataset.id; p.sel.has(id) ? p.sel.delete(id) : p.sel.add(id);
    b.classList.toggle('on', p.sel.has(id)); b.setAttribute('aria-pressed', p.sel.has(id)); haptic.tick(); update();
  };
  out.querySelector('[data-all]').onclick = () => { p.sel = p.sel.size === p.items.length ? new Set() : new Set(p.items.map((i) => i.id)); renderPack(); };
  update();
}
async function reservePack() {
  const p = state.pack;
  if (!p?.sel.size) return;
  setPrimary({ text: t('pack_reserve', { n: fmtNum(p.sel.size) }), loading: true, onClick: () => {} });
  try {
    const items = p.items.filter((i) => p.sel.has(i.id)).map((i) => ({ ...i, pack: p.title, name: `${i.char} ${p.title}`.slice(0, 40) }));
    const r = await api('/emojis/reserve', { method: 'POST', body: { items } });
    haptic.ok();
    toast(t('pack_result', { added: fmtNum(r.added), dup: fmtNum(r.duplicates), full: fmtNum(r.full) }), 'ok');
    state.pack = null;
    state.me = await api('/me');
    route(true);
  } catch (e) { haptic.error(); toast(errText(e), 'error'); renderPack(); }
}

// ── پست‌ها ───────────────────────────────────────────────────────────────
async function viewPosts() {
  renderChrome('posts');
  main.innerHTML = skeleton(3);
  try {
    const r = await api('/posts?per=50');
    state.posts = r;
    main.innerHTML = `<div class="list" data-region="content">${r.items.length ? r.items.map(postCard).join('') : emptyState(t('posts_empty'), t('posts_empty_hint'))}</div>`;
    setPrimary({ text: t('act_new_post'), onClick: () => { haptic.tap(); go('#/post/new'); } });
  } catch (e) { main.innerHTML = errorBox(errText(e)); bindRetry(() => route(true)); }
}

// ── ویرایشگرِ پست + پیش‌نمایش زنده ────────────────────────────────────────
const EXP_MAP = { never: { mode: 'never' }, '1h': { mode: 'hours', hours: 1 }, '1d': { mode: 'hours', hours: 24 }, '7d': { mode: 'hours', hours: 168 }, '30d': { mode: 'hours', hours: 720 } };
const snap = (ed) => JSON.stringify([ed.title, ed.text, ed.buttons, ed.template, ed.track, ed.exp, ed.hours]);

async function viewEditor(code) {
  renderChrome(null, { compactTitle: t(code === 'new' ? 'ed_new' : 'ed_edit') });
  main.innerHTML = skeleton(3);
  let post = null;
  if (code !== 'new') {
    try { post = await api(`/posts/${code}`); } catch (e) { main.innerHTML = errorBox(errText(e)); bindRetry(() => route(true)); return; }
  }
  const { text, chars } = M.htmlToEditable(post?.text || '');
  const ed = state.ed = {
    code: post?.code || null, title: post?.title || '', text, chars, buttons: structuredClone(post?.buttons_rows || []),
    template: Boolean(post?.template), track: Boolean(post?.track), media: post?.media_info || null,
    exp: post ? 'keep' : 'never', hours: 24, expires_at: post?.expires_at || null, views: post?.views || 0, saving: false, dirty: false,
  };
  ed.base = snap(ed);
  renderEditor();
}

function renderEditor() {
  const ed = state.ed, me = state.me;
  const limit = ed.media ? 1024 : 4096;
  const tbtn = (act, label, inner) => `<button type="button" class="tb" data-act="${act}" title="${esc(t(label))}" aria-label="${esc(t(label))}">${inner}</button>`;
  main.innerHTML = `<div class="editor">
    <section class="card" data-region="content">
      <label class="field"><span>${esc(t('ed_title'))}</span><input id="f-title" maxlength="60" value="${esc(ed.title)}" placeholder="${esc(t('ed_title_ph'))}"></label>
      <div class="field"><label for="f-text">${esc(t('ed_text'))}</label>
        <div class="toolbar" role="toolbar" aria-label="${esc(t('ed_text'))}">
          ${tbtn('b', 'tb_bold', '<b>B</b>')}${tbtn('i', 'tb_italic', '<i>I</i>')}${tbtn('u', 'tb_underline', '<u>U</u>')}${tbtn('s', 'tb_strike', '<s>S</s>')}
          ${tbtn('spoiler', 'tb_spoiler', '<span class="spo">▒</span>')}${tbtn('code', 'tb_code', '<code>&lt;/&gt;</code>')}${tbtn('quote', 'tb_quote', '❝')}
          ${tbtn('link', 'tb_link', icon('link'))}${tbtn('emoji', 'tb_emoji', icon('smile'))}</div>
        <textarea id="f-text" rows="7" dir="auto" placeholder="${esc(t('ed_text_ph'))}">${esc(ed.text)}</textarea>
        <div class="meta"><span id="counter"></span></div>
        ${ed.template ? `<div class="vars" id="vars"><span class="muted">${esc(t('ed_template_hint'))}</span>${M.VARIABLES.map((v) => `<button type="button" class="var" data-var="${v}" dir="ltr">{${v}}</button>`).join('')}</div>` : ''}
      </div></section>
    <section class="preview" aria-labelledby="pv-h"><div class="pv-head"><h2 id="pv-h">${esc(t('ed_preview'))}</h2><span class="muted">${esc(t('ed_preview_note'))}</span></div>
      <div class="chat"><div class="bubble" id="bubble"></div></div></section>
    <section class="card"><div class="sec-h flat"><h2>${esc(t('ed_buttons'))}</h2></div><div id="btns"></div></section>
    <section class="card"><div class="sec-h flat"><h2>${esc(t('ed_options'))}</h2></div>
      <label class="field"><span>${esc(t('ed_expiry'))}</span><select id="f-exp">${ed.code ? `<option value="keep">${esc(t('exp_keep'))}${ed.expires_at ? ` — ${esc(t('exp_current', { when: fmtDate(ed.expires_at) }))}` : ''}</option>` : ''}
        ${['never', '1h', '1d', '7d', '30d', 'custom'].map((k) => `<option value="${k}">${esc(t(k === 'custom' ? 'exp_custom' : `exp_${k}`))}</option>`).join('')}</select></label>
      <label class="field" id="hours-f" hidden><span>${esc(t('exp_hours'))}</span><input id="f-hours" type="number" inputmode="numeric" min="1" max="8760" value="${ed.hours}"></label>
      <label class="switch"><span>${esc(t('ed_template'))}</span><input id="f-tpl" type="checkbox" role="switch" ${ed.template ? 'checked' : ''}><i aria-hidden="true"></i></label>
      <label class="switch${me.track_available ? '' : ' off'}"><span>${esc(t('ed_track'))}${me.track_available ? '' : `<small>${esc(t('ed_track_off'))}</small>`}</span><input id="f-trk" type="checkbox" role="switch" ${ed.track ? 'checked' : ''} ${me.track_available ? '' : 'disabled'}><i aria-hidden="true"></i></label>
      ${ed.media ? `<p class="note">${icon('image')}${esc(t('ed_media_note'))}</p>` : ''}</section>
    ${ed.code ? `<button class="btn danger ghost wide" id="del">${icon('trash')}${esc(t('ed_delete'))}</button>` : ''}</div>`;

  $('#f-exp').value = ed.exp;
  $('#hours-f').hidden = ed.exp !== 'custom';
  const ta = $('#f-text');
  const autosize = () => { ta.style.height = 'auto'; ta.style.height = `${Math.min(ta.scrollHeight + 2, 520)}px`; };
  const refresh = () => { updatePreview(); updateCounter(limit); markDirty(); autosize(); };
  autosize(); updatePreview(); updateCounter(limit);

  $('#f-title').addEventListener('input', (e) => { ed.title = e.target.value; markDirty(); });
  ta.addEventListener('input', () => { ed.text = ta.value; refresh(); });
  $('#f-exp').addEventListener('change', (e) => { ed.exp = e.target.value; $('#hours-f').hidden = ed.exp !== 'custom'; markDirty(); });
  $('#f-hours').addEventListener('input', (e) => { ed.hours = e.target.value; markDirty(); });
  $('#f-tpl').addEventListener('change', (e) => { ed.template = e.target.checked; haptic.tick(); const keep = ed.dirty; renderEditor(); ed.dirty = keep; markDirty(); });
  $('#f-trk').addEventListener('change', (e) => { ed.track = e.target.checked; haptic.tick(); markDirty(); });
  $('#del')?.addEventListener('click', deletePost);

  const apply = (r) => { ta.value = ed.text = r.value; ta.focus(); ta.setSelectionRange(r.selStart, r.selEnd); refresh(); };
  const wrap = (open, close, ph) => apply(M.wrapSelection(ta.value, ta.selectionStart, ta.selectionEnd, open, close, ph));
  main.querySelector('.toolbar').addEventListener('mousedown', (e) => e.preventDefault());       // انتخابِ textarea از دست نره
  main.querySelector('.toolbar').addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    haptic.tick();
    const a = b.dataset.act;
    if (a === 'b') wrap('<b>', '</b>', 'متن'); else if (a === 'i') wrap('<i>', '</i>', 'متن'); else if (a === 'u') wrap('<u>', '</u>', 'متن');
    else if (a === 's') wrap('<s>', '</s>', 'متن'); else if (a === 'spoiler') wrap('<tg-spoiler>', '</tg-spoiler>', 'متن');
    else if (a === 'code') wrap('<code>', '</code>', 'code'); else if (a === 'quote') wrap('<blockquote>', '</blockquote>', 'متن');
    else if (a === 'link') linkSheet(ta, apply); else if (a === 'emoji') emojiPicker(ta, apply);
  });
  $('#vars')?.addEventListener('click', (e) => {
    const b = e.target.closest('[data-var]'); if (!b) return;
    haptic.tick(); apply(M.insertAt(ta.value, ta.selectionEnd, ta.selectionEnd, `{${b.dataset.var}}`));
  });
  renderButtons();
  updatePrimary();
  setClosingConfirm(ed.dirty);
}

function linkSheet(ta, apply) {
  const s = ta.selectionStart, e = ta.selectionEnd;
  const body = h(`<form class="stack"><label class="field"><span>${esc(t('link_url'))}</span><input id="lk" dir="ltr" inputmode="url" autocapitalize="off" spellcheck="false" placeholder="https://…" required></label><p class="err" id="lk-err" hidden>${esc(t('link_bad'))}</p>
    <div class="row-actions"><button class="btn primary" type="submit">${esc(t('link_apply'))}</button></div></form>`);
  const { close } = openSheet({ title: t('tb_link'), body });
  body.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const url = $('#lk', body).value.trim();
    if (!/^(https?:\/\/|tg:\/\/)[^\s"'<>]+$/i.test(url)) { $('#lk-err', body).hidden = false; haptic.error(); return; }
    close();
    apply(M.wrapSelection(ta.value, s, e, `<a href="${esc(url)}">`, '</a>', 'لینک'));
  });
}

function emojiPicker(ta, apply) {
  const s = ta.selectionStart, e = ta.selectionEnd;
  const map = state.me.mapping, ids = Object.entries(map);
  const body = h(`<div>${ids.length ? `<div class="grid pack-grid">${ids.map(([c, id]) => `<button class="tile mini" data-id="${esc(id)}" data-c="${esc(c)}" aria-label="${esc(c)}"><span class="tile-e"><tg-emoji emoji-id="${esc(id)}">${esc(c)}</tg-emoji></span></button>`).join('')}</div>`
    : `<div class="state"><p>${esc(t('emoji_pick_none'))}</p><a class="btn" href="#/emojis" data-close>${esc(t('tab_emojis'))}</a></div>`}</div>`);
  const { close } = openSheet({ title: t('emoji_pick'), body });
  body.addEventListener('click', (ev) => {
    const b = ev.target.closest('.tile'); if (!b) return;
    state.ed.chars[b.dataset.id] = b.dataset.c;
    close(); haptic.tap();
    apply(M.insertAt(ta.value, e, e, `[${b.dataset.id}]`));
  });
}

function sampleVars() {
  const now = Date.now() / 1000, u = tg?.initDataUnsafe?.user || {};
  const first = u.first_name || state.me.first_name || 'Ali';
  return { name: [first, u.last_name].filter(Boolean).join(' '), first_name: first, username: u.username ? `@${u.username}` : '@username', id: String(state.me.id),
    group: t('ed_sample_group'), date: fmtDateOnly(now), time: fmtTime(now), code: 'AbC123XyZ9', views: String(state.ed.views || 0) };
}
function previewHtml() {
  const ed = state.ed, me = state.me;
  let html = M.editableToHtml(ed.text, ed.chars, me.mapping);
  html = M.sanitizeHtml(M.applyReserved(html, me.mapping));
  return ed.template ? M.fillVariables(html, sampleVars()) : html;
}
let pvFrame = 0;
function updatePreview() {
  cancelAnimationFrame(pvFrame);
  pvFrame = requestAnimationFrame(() => {
    const ed = state.ed, bubble = $('#bubble');
    if (!ed || !bubble) return;
    const html = previewHtml();
    const media = ed.media ? `<div class="pv-media">${icon('image')}<span>${esc(Array.isArray(ed.media) ? `${ed.media.length} ×` : ed.media.type || '')}</span></div>` : '';
    const rows = ed.buttons.map((row) => `<div class="pv-row">${row.map((b) => `<span class="pv-btn">${esc(b.text || '…')}</span>`).join('')}</div>`).join('');
    bubble.innerHTML = `${media}${html.trim() ? `<div class="pv-text">${html.replace(/<tg-spoiler>/g, '<span class="spoiler" tabindex="0">').replace(/<\/tg-spoiler>/g, '</span>')}</div>` : `<div class="pv-text muted">${esc(t('ed_empty'))}</div>`}<div class="pv-meta">${icon('eye')}${fmtNum(ed.views || 0)}</div>${rows ? `<div class="pv-kb">${rows}</div>` : ''}`;
    bubble.querySelectorAll('a').forEach((a) => a.addEventListener('click', (e) => e.preventDefault()));
    bubble.querySelectorAll('.spoiler').forEach((s) => s.addEventListener('click', () => s.classList.add('shown')));
  });
}
function updateCounter(limit) {
  const el = $('#counter'), ed = state.ed;
  if (!el) return;
  const n = M.visibleLength(M.sanitizeHtml(M.editableToHtml(ed.text, ed.chars, state.me.mapping)));
  el.textContent = t('ed_counter', { n: fmtNum(n), max: fmtNum(limit) });
  el.classList.toggle('over', n > limit);
}

function markDirty() {
  const ed = state.ed;
  if (!ed) return;
  const was = ed.dirty;
  ed.dirty = snap(ed) !== ed.base;
  if (was !== ed.dirty) setClosingConfirm(ed.dirty);
  updatePrimary();
}

// ویرایشگرِ دکمه‌ها: ردیف‌ها ۱–۳ دکمه، حداکثر ۸ ردیف
function renderButtons() {
  const ed = state.ed, box = $('#btns');
  if (!box) return;
  box.innerHTML = `${ed.buttons.map((row, r) => `<div class="brow" data-r="${r}">${row.map((b, c) => {
    const isUrl = (b.type || 'url') === 'url';
    return `<div class="bcell" data-c="${c}"><input class="b-text" maxlength="64" placeholder="${esc(t('btn_text'))}" aria-label="${esc(t('btn_text'))}" value="${esc(b.text || '')}">
      ${isUrl ? `<input class="b-url" dir="ltr" inputmode="url" autocapitalize="off" spellcheck="false" placeholder="${esc(t('btn_url'))}" aria-label="URL" value="${esc(b.url || '')}">` : `<p class="muted small">${esc(t('btn_other', { type: b.type }))}</p>`}
      <button type="button" class="icon-btn sm" data-rm aria-label="${esc(t('ed_remove'))}">${icon('x')}</button></div>`;
  }).join('')}${row.length < 3 ? `<button type="button" class="btn ghost sm" data-add-in>${icon('plus')}${esc(t('ed_add_btn'))}</button>` : ''}</div>`).join('')}
    ${ed.buttons.length < 8 ? `<button type="button" class="btn ghost" data-add-row>${icon('plus')}${esc(t('ed_add_row'))}</button>` : ''}`;
  box.onclick = (e) => {
    const rowEl = e.target.closest('.brow'), r = rowEl ? Number(rowEl.dataset.r) : -1;
    if (e.target.closest('[data-add-row]')) { ed.buttons.push([{ text: '', url: '' }]); haptic.tap(); }
    else if (e.target.closest('[data-add-in]')) { ed.buttons[r].push({ text: '', url: '' }); haptic.tap(); }
    else if (e.target.closest('[data-rm]')) {
      const c = Number(e.target.closest('.bcell').dataset.c);
      ed.buttons[r].splice(c, 1);
      if (!ed.buttons[r].length) ed.buttons.splice(r, 1);
      haptic.tick();
    } else return;
    renderButtons(); updatePreview(); markDirty();
  };
  box.oninput = (e) => {
    const cell = e.target.closest('.bcell'); if (!cell) return;
    const b = ed.buttons[Number(cell.closest('.brow').dataset.r)][Number(cell.dataset.c)];
    if (e.target.classList.contains('b-text')) b.text = e.target.value; else if (e.target.classList.contains('b-url')) b.url = e.target.value.trim();
    updatePreview(); markDirty();
  };
}

function validate() {
  const ed = state.ed, limit = ed.media ? 1024 : 4096;
  const errs = M.validateButtons(ed.buttons);
  const html = M.sanitizeHtml(M.editableToHtml(ed.text, ed.chars, state.me.mapping));
  if (M.visibleLength(html) > limit) errs.push('text_too_long');
  if (!html.trim() && !ed.buttons.length && !ed.media) errs.push('empty_post');
  if (ed.exp === 'custom' && !(Number(ed.hours) > 0 && Number(ed.hours) <= 8760)) errs.push('err_row_size');
  return errs;
}
function updatePrimary() {
  const ed = state.ed;
  if (!ed) return;
  setPrimary({ text: t('ed_save'), loading: ed.saving, disabled: ed.saving || (ed.code && !ed.dirty), onClick: savePost });
}

async function savePost() {
  const ed = state.ed;
  const errs = validate();
  if (errs.length) { haptic.error(); toast(t(errs[0]), 'error'); return; }
  ed.saving = true; updatePrimary();
  const payload = {
    title: ed.title, text: M.editableToHtml(ed.text, ed.chars, state.me.mapping), buttons_rows: ed.buttons,
    template: ed.template, track_clicks: ed.track, expiry: ed.exp === 'keep' ? { mode: 'keep' } : ed.exp === 'custom' ? { mode: 'hours', hours: Number(ed.hours) } : EXP_MAP[ed.exp],
  };
  try {
    await api(ed.code ? `/posts/${ed.code}` : '/posts', { method: ed.code ? 'PUT' : 'POST', body: payload });
    haptic.ok(); toast(t('ed_saved'), 'ok');
    ed.dirty = false; setClosingConfirm(false);
    state.me = await api('/me');
    go('#/posts');
  } catch (e) {
    ed.saving = false; updatePrimary(); haptic.error(); toast(errText(e), 'error');
  }
}
async function deletePost() {
  const ed = state.ed;
  if (!(await ask(t('ed_delete_confirm')))) return;
  try { await api(`/posts/${ed.code}`, { method: 'DELETE' }); haptic.ok(); toast(t('ed_deleted'), 'ok'); ed.dirty = false; setClosingConfirm(false); state.me = await api('/me'); go('#/posts'); }
  catch (e) { haptic.error(); toast(errText(e), 'error'); }
}

// ── شروع ─────────────────────────────────────────────────────────────────
async function boot() {
  setLang(getLang());
  renderChrome(null);
  main.innerHTML = skeleton();
  bootTMA();
  if (!inTelegram && !DEV) {
    main.innerHTML = `<div class="state empty">${illus}<p>${esc(t('open_in_telegram'))}</p></div>`;
    return;
  }
  try { await loadMe(); } catch (e) { main.innerHTML = errorBox(errText(e)); bindRetry(() => location.reload()); return; }
  document.documentElement.classList.add('ready');
  route(true);
}
document.addEventListener('click', (e) => { const a = e.target.closest('a[href^="#/"]'); if (a) haptic.tick(); });
boot();
