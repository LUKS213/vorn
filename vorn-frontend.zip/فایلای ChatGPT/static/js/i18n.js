// i18n.js — متن‌های مینی‌اپ (فارسی/انگلیسی) + قالب‌بندیِ عدد و تاریخ با locale و منطقه‌ی زمانیِ صریح.
const FA = {
  app_name: 'مدیریت', tab_home: 'خانه', tab_emojis: 'اموجی‌ها', tab_posts: 'پست‌ها',
  hello: 'سلام {name} 👋', hello_sub: 'اینجا رزروها و پست‌هات رو مدیریت کن.',
  coins: 'کوین', stat_posts: 'پست', stat_emoji: 'اموجی رزروشده', stat_capacity: 'ظرفیت',
  act_new_post: 'پست جدید', act_reserve: 'رزرو اموجی', recent_posts: 'آخرین پست‌ها', see_all: 'همه',
  emo_search: 'جستجوی اسم، اموجی یا پک…', emo_used: '{used} از {cap} رزرو', emo_empty: 'هنوز اموجی‌ای رزرو نکردی.',
  emo_empty_hint: 'لینک یه پک اموجی رو پایین بذار تا همه‌ی اموجی‌هاش یک‌جا رزرو بشن.', emo_none_found: 'چیزی پیدا نشد.',
  emo_unnamed: 'بدون اسم', emo_rename: 'اسم', emo_save: 'ذخیره', emo_delete: 'حذف رزرو', emo_pack: 'پک', emo_id: 'آیدی',
  emo_delete_confirm: 'این رزرو حذف بشه؟', emo_deleted: 'حذف شد', emo_renamed: 'اسم ذخیره شد',
  pack_title: 'رزرو از روی پک', pack_hint: 'لینک پک (t.me/addemoji/…) رو بذار. یا تو چتِ ربات یه پیام با اموجی پرمیوم بفرست.',
  pack_placeholder: 'https://t.me/addemoji/…', pack_find: 'پیدا کن', pack_found: '{n} اموجی • جای خالی: {free}',
  pack_select_all: 'انتخاب همه', pack_reserve: 'رزرو ({n})', pack_none: 'هیچ‌کدوم انتخاب نشده',
  pack_result: '{added} رزرو شد • {dup} تکراری • {full} جا نبود', pack_not_emoji: 'این پک، اموجی سفارشی نیست.', pack_bad: 'لینک پک معتبر نیست.',
  posts_empty: 'هنوز پستی نساختی.', posts_empty_hint: 'اولین پستت رو بساز و با پیش‌نمایش زنده ببین چطور می‌شه.',
  post_expired: 'منقضی', post_views: 'بازدید', post_buttons: 'دکمه', post_tracked: 'آمار کلیک', post_media: 'رسانه‌دار',
  ed_new: 'پست جدید', ed_edit: 'ویرایش پست', ed_title: 'عنوان (فقط برای خودت)', ed_title_ph: 'مثلاً «تخفیف آخر هفته»',
  ed_text: 'متن پست', ed_text_ph: 'متنت رو بنویس…', ed_counter: '{n} / {max}',
  tb_bold: 'درشت', tb_italic: 'کج', tb_underline: 'زیرخط', tb_strike: 'خط‌خورده', tb_spoiler: 'اسپویلر', tb_code: 'کد', tb_quote: 'نقل‌قول',
  tb_link: 'لینک', tb_emoji: 'اموجی پرمیوم', link_url: 'آدرس لینک', link_apply: 'اعمال', link_bad: 'لینک باید با http یا https شروع بشه',
  emoji_pick: 'اموجیِ رزروشده رو انتخاب کن', emoji_pick_none: 'اول از تبِ «اموجی‌ها» چندتا رزرو کن.',
  ed_buttons: 'دکمه‌ها', ed_add_btn: 'دکمه', ed_add_row: 'ردیف جدید', btn_text: 'متن دکمه', btn_url: 'https://…', btn_other: 'نوعِ «{type}» (فقط متنش قابل ویرایشه)',
  ed_remove: 'حذف', ed_options: 'تنظیمات', ed_expiry: 'انقضا', exp_keep: 'بدون تغییر', exp_never: 'بدون انقضا', exp_1h: '۱ ساعت', exp_1d: '۱ روز',
  exp_7d: '۷ روز', exp_30d: '۳۰ روز', exp_custom: 'ساعت دلخواه', exp_hours: 'تعداد ساعت', exp_current: 'فعلاً: {when}',
  ed_template: 'قالب و متغیر', ed_template_hint: 'متغیرها موقع ارسال پر می‌شن:', ed_track: 'شمارش کلیک دکمه‌ها',
  ed_track_off: 'برای شمارش کلیک، آدرس عمومی مینی‌اپ باید تنظیم شده باشه.', ed_media_note: 'این پست رسانه داره؛ رسانه رو از داخل ربات عوض کن.',
  ed_preview: 'پیش‌نمایش زنده', ed_preview_note: 'تقریباً همونطور که تو تلگرام دیده می‌شه', ed_save: 'ذخیره‌ی پست', ed_saved: 'پست ذخیره شد ✓',
  ed_delete: 'حذف پست', ed_delete_confirm: 'این پست برای همیشه حذف بشه؟', ed_deleted: 'پست حذف شد', ed_discard: 'تغییرات ذخیره‌نشده از بین می‌رن. خارج بشی؟',
  ed_empty: 'پست خالیه', ed_sample_group: 'گروه نمونه', ed_copy_code: 'کپی کد',
  err_rows: 'حداکثر ۸ ردیف دکمه', err_row_size: 'هر ردیف ۱ تا ۳ دکمه', err_btn_text: 'متن دکمه خالیه', err_btn_url: 'لینک دکمه معتبر نیست',
  text_too_long: 'متن بیش‌ازحد طولانیه', empty_post: 'پست خالیه', too_many_posts: 'به سقف تعداد پست رسیدی', rate_limited: 'خیلی سریع! کمی صبر کن.',
  unauthorized: 'ورود نامعتبر؛ مینی‌اپ رو از داخل ربات باز کن.', stale: 'نشستت قدیمی شده؛ مینی‌اپ رو دوباره باز کن.', server_error: 'خطای سرور؛ دوباره امتحان کن.',
  offline: 'اتصال برقرار نیست.', retry: 'تلاش دوباره', loading: 'در حال بارگذاری…', cancel: 'انصراف', yes: 'بله', no: 'خیر', close: 'بستن', done: 'تمام',
  lang_switch: 'English', open_in_telegram: 'برای ورود، مینی‌اپ رو از داخل ربات باز کن.',
};
const EN = {
  app_name: 'Manage', tab_home: 'Home', tab_emojis: 'Emoji', tab_posts: 'Posts',
  hello: 'Hi {name} 👋', hello_sub: 'Manage your reservations and posts here.',
  coins: 'coins', stat_posts: 'posts', stat_emoji: 'emoji reserved', stat_capacity: 'capacity',
  act_new_post: 'New post', act_reserve: 'Reserve emoji', recent_posts: 'Recent posts', see_all: 'All',
  emo_search: 'Search name, emoji or pack…', emo_used: '{used} of {cap} reserved', emo_empty: "You haven't reserved any emoji yet.",
  emo_empty_hint: 'Paste an emoji pack link below to reserve all its emoji at once.', emo_none_found: 'Nothing found.',
  emo_unnamed: 'Unnamed', emo_rename: 'Name', emo_save: 'Save', emo_delete: 'Delete reservation', emo_pack: 'Pack', emo_id: 'ID',
  emo_delete_confirm: 'Delete this reservation?', emo_deleted: 'Deleted', emo_renamed: 'Name saved',
  pack_title: 'Reserve from a pack', pack_hint: 'Paste a pack link (t.me/addemoji/…). Or send a message with premium emoji in the bot chat.',
  pack_placeholder: 'https://t.me/addemoji/…', pack_find: 'Find', pack_found: '{n} emoji • free slots: {free}',
  pack_select_all: 'Select all', pack_reserve: 'Reserve ({n})', pack_none: 'Nothing selected',
  pack_result: '{added} reserved • {dup} duplicates • {full} no room', pack_not_emoji: "This isn't a custom emoji pack.", pack_bad: 'Invalid pack link.',
  posts_empty: "You haven't created any posts yet.", posts_empty_hint: 'Create your first post and watch it take shape in the live preview.',
  post_expired: 'expired', post_views: 'views', post_buttons: 'buttons', post_tracked: 'click stats', post_media: 'has media',
  ed_new: 'New post', ed_edit: 'Edit post', ed_title: 'Title (just for you)', ed_title_ph: 'e.g. “Weekend sale”',
  ed_text: 'Post text', ed_text_ph: 'Write your text…', ed_counter: '{n} / {max}',
  tb_bold: 'Bold', tb_italic: 'Italic', tb_underline: 'Underline', tb_strike: 'Strikethrough', tb_spoiler: 'Spoiler', tb_code: 'Code', tb_quote: 'Quote',
  tb_link: 'Link', tb_emoji: 'Premium emoji', link_url: 'Link address', link_apply: 'Apply', link_bad: 'The link must start with http or https',
  emoji_pick: 'Pick a reserved emoji', emoji_pick_none: 'Reserve a few from the Emoji tab first.',
  ed_buttons: 'Buttons', ed_add_btn: 'Button', ed_add_row: 'New row', btn_text: 'Button text', btn_url: 'https://…', btn_other: '“{type}” button (only its text is editable)',
  ed_remove: 'Remove', ed_options: 'Options', ed_expiry: 'Expiry', exp_keep: 'Keep as is', exp_never: 'Never', exp_1h: '1 hour', exp_1d: '1 day',
  exp_7d: '7 days', exp_30d: '30 days', exp_custom: 'Custom hours', exp_hours: 'Hours', exp_current: 'Now: {when}',
  ed_template: 'Template & variables', ed_template_hint: 'Variables are filled in when sending:', ed_track: 'Count button clicks',
  ed_track_off: 'Click counting needs the mini app public URL to be configured.', ed_media_note: 'This post has media; change the media from inside the bot.',
  ed_preview: 'Live preview', ed_preview_note: 'Close to how it looks in Telegram', ed_save: 'Save post', ed_saved: 'Post saved ✓',
  ed_delete: 'Delete post', ed_delete_confirm: 'Delete this post forever?', ed_deleted: 'Post deleted', ed_discard: 'Unsaved changes will be lost. Leave?',
  ed_empty: 'The post is empty', ed_sample_group: 'Sample group', ed_copy_code: 'Copy code',
  err_rows: 'At most 8 button rows', err_row_size: 'Each row needs 1–3 buttons', err_btn_text: 'A button has no text', err_btn_url: 'A button link is invalid',
  text_too_long: 'The text is too long', empty_post: 'The post is empty', too_many_posts: "You've reached the post limit", rate_limited: 'Too fast! Wait a moment.',
  unauthorized: 'Invalid sign-in; open the mini app from inside the bot.', stale: 'Your session is stale; reopen the mini app.', server_error: 'Server error; try again.',
  offline: "You're offline.", retry: 'Retry', loading: 'Loading…', cancel: 'Cancel', yes: 'Yes', no: 'No', close: 'Close', done: 'Done',
  lang_switch: 'فارسی', open_in_telegram: 'To sign in, open the mini app from inside the bot.',
};
const DICT = { fa: FA, en: EN };
let lang = 'fa';

export const getLang = () => lang;
export const dirOf = (l = lang) => (l === 'fa' ? 'rtl' : 'ltr');
export function setLang(l) {
  lang = DICT[l] ? l : 'fa';
  document.documentElement.lang = lang;
  document.documentElement.dir = dirOf(lang);
}
export const t = (key, vars = {}) => (DICT[lang][key] ?? DICT.fa[key] ?? key).replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? '');
export const has = (key) => key in DICT[lang];

const locale = () => (lang === 'fa' ? 'fa-IR' : 'en-GB');
export const fmtNum = (n) => new Intl.NumberFormat(locale()).format(Number(n) || 0);
let TZ = 'Asia/Tehran';
export const setTimeZone = (tz) => { TZ = tz || TZ; };
export function fmtDate(ts) {
  if (!ts) return '—';
  const opts = { dateStyle: 'medium', timeStyle: 'short', timeZone: TZ };
  const loc = lang === 'fa' ? 'fa-IR-u-ca-persian' : 'en-GB';
  return new Intl.DateTimeFormat(loc, opts).format(new Date(ts * 1000));
}
export function fmtDateOnly(ts) {
  return new Intl.DateTimeFormat(lang === 'fa' ? 'fa-IR-u-ca-persian' : 'en-GB', { dateStyle: 'medium', timeZone: TZ }).format(new Date(ts * 1000));
}
export const fmtTime = (ts) => new Intl.DateTimeFormat(locale(), { timeStyle: 'short', timeZone: TZ }).format(new Date(ts * 1000));
