// tma.js — لایه‌ی امن روی Telegram.WebApp. بیرون از تلگرام (مرورگر معمولی) هم کار می‌کنه و
// هر APIِ تازه‌تر رو با نسخه چک می‌کنه.
export const tg = window.Telegram?.WebApp ?? null;
export const inTelegram = Boolean(tg?.initData);
export const has = (v) => Boolean(tg) && typeof tg.isVersionAtLeast === 'function' && tg.isVersionAtLeast(v);

export function bootTMA() {
  if (!tg) return;
  try {
    tg.ready();                                           // بعد از اولین رندرِ اسکلت صدا زده می‌شه
    tg.expand();
    if (has('7.7')) tg.disableVerticalSwipes();           // ویرایشگر و اسکرولِ طولانی: جلوگیریِ از minimize اتفاقی
    if (has('6.1')) { tg.setHeaderColor('secondary_bg_color'); tg.setBackgroundColor('bg_color'); }
    if (has('7.10')) tg.setBottomBarColor('bottom_bar_bg_color');
  } catch { /* نسخه‌های قدیمی */ }
}

export const haptic = {
  tap: () => has('6.1') && tg.HapticFeedback.impactOccurred('light'),
  tick: () => has('6.1') && tg.HapticFeedback.selectionChanged(),
  ok: () => has('6.1') && tg.HapticFeedback.notificationOccurred('success'),
  warn: () => has('6.1') && tg.HapticFeedback.notificationOccurred('warning'),
  error: () => has('6.1') && tg.HapticFeedback.notificationOccurred('error'),
};

// BackButton آینه‌ی روتره: رو صفحه‌ی اصلی مخفی، رو صفحه‌های تو در تو پیدا
let backHandler = null;
export function syncBackButton(depth, goBack) {
  if (!has('6.1')) return;
  if (backHandler) tg.BackButton.offClick(backHandler);
  backHandler = goBack;
  tg.BackButton.onClick(goBack);
  depth > 0 ? tg.BackButton.show() : tg.BackButton.hide();
}

// دکمه‌ی اصلیِ پایین: تو تلگرام همون MainButton؛ بیرون از تلگرام یه دکمه‌ی چسبیده تو صفحه
let primaryHandler = null;
const fallback = () => document.getElementById('primary');
export function setPrimary({ text, onClick, loading = false, disabled = false }) {
  if (tg && inTelegram) {
    const b = tg.MainButton;
    if (primaryHandler) b.offClick(primaryHandler);
    primaryHandler = onClick;
    b.onClick(onClick);
    b.setParams({ text, is_visible: true, is_active: !disabled, ...(has('7.10') ? { has_shine_effect: !disabled } : {}) });
    loading ? b.showProgress(false) : b.hideProgress();
    return;
  }
  const el = fallback();
  if (!el) return;
  el.hidden = false;
  el.textContent = text;
  el.disabled = disabled || loading;
  el.classList.toggle('is-loading', loading);
  el.onclick = onClick;
  document.documentElement.classList.add('has-primary');
}
export function hidePrimary() {
  if (tg && inTelegram) {
    if (primaryHandler) tg.MainButton.offClick(primaryHandler);
    primaryHandler = null;
    tg.MainButton.hide();
    return;
  }
  const el = fallback();
  if (el) { el.hidden = true; el.onclick = null; }
  document.documentElement.classList.remove('has-primary');
}

export function setClosingConfirm(on) {
  if (!has('6.2')) return;
  on ? tg.enableClosingConfirmation() : tg.disableClosingConfirmation();
}

// تأییدِ بومیِ تلگرام؛ بیرون از تلگرام روی یه dialog داخلی (app.js) برمی‌گرده
export const nativeConfirm = (message) => new Promise((resolve) => {
  if (has('6.2')) tg.showConfirm(message, (ok) => resolve(Boolean(ok)));
  else resolve(null);
});

// ذخیره‌ی ترجیحات: CloudStorage (بین دستگاه‌ها همگام) یا localStorage
export const store = {
  get(key) {
    return new Promise((resolve) => {
      if (has('6.9')) tg.CloudStorage.getItem(key, (err, v) => resolve(err ? null : v || null));
      else { try { resolve(localStorage.getItem(key)); } catch { resolve(null); } }
    });
  },
  set(key, value) {
    if (has('6.9')) tg.CloudStorage.setItem(key, value, () => {});
    else { try { localStorage.setItem(key, value); } catch { /* حالت خصوصی */ } }
  },
};
