// tg-emoji.js — <tg-emoji emoji-id="…">😀</tg-emoji> برای وب (همون تگِ HTML تلگرام).
// ترتیب نمایش (هیچ‌وقت سوراخ نمی‌مونه):
//   ۱) اموجیِ یونیکدِ داخل تگ (fallback)  →  ۲) تصویرِ ثابتِ واقعیِ اموجی (thumbnail/webp)  →  ۳) انیمیشن (.tgs/.webm) اگه بشه.
// فایل‌ها از /api/custom-emoji/:id میان؛ توکن ربات هیچ‌وقت به مرورگر نمی‌رسه.
const metaCache = new Map();
const getMeta = (id) => {
  if (!metaCache.has(id)) {
    const p = fetch(`/api/custom-emoji/${encodeURIComponent(id)}`)
      .then((r) => (r.ok ? r.json() : r.json().catch(() => ({})).then((j) => Promise.reject(new Error(`${r.status} ${j.message || j.error || ''}`.trim())))));
    p.catch(() => metaCache.delete(id));                    // خطای موقت (شبکه/۵۰۲) برای همیشه کش نمی‌شه
    metaCache.set(id, p);
  }
  return metaCache.get(id);
};
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');
const MAX_LIVE = 8;                       // انیمیشنِ هم‌زمان (گوشی‌های ضعیف)
let live = 0;
const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent);

// lottie-web (فقط برای .tgs): اول نسخه‌ی خودِ سرور (static/js/vendor/…، بدون وابستگی به CDN که تو بعضی شبکه‌ها فیلتره)، بعد cdnjs.
// نکته: نسخه‌ی «light» فقط رندررِ SVG داره، پس همیشه renderer:'svg' استفاده می‌شه.
const LOTTIE_SOURCES = ['/static/js/vendor/lottie.light.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/lottie-web/5.12.2/lottie.light.min.js'];
let lottiePromise = null;
const loadScript = (src) => new Promise((res, rej) => {
  const s = document.createElement('script');
  s.src = src; s.onload = res; s.onerror = () => { s.remove(); rej(new Error(`lottie: ${src}`)); };
  document.head.appendChild(s);
});
const ensureLottie = () => {
  if (window.lottie) return Promise.resolve();
  lottiePromise ??= (async () => {
    for (const src of LOTTIE_SOURCES) { try { await loadScript(src); if (window.lottie) return; } catch { /* منبعِ بعدی */ } }
    throw new Error('lottie unavailable');
  })().catch((e) => { lottiePromise = null; throw e; });
  return lottiePromise;
};

const loadImg = (src, alt, fit) => new Promise((res, rej) => {
  const img = new Image();
  img.alt = alt; img.decoding = 'async'; img.style.cssText = fit;
  img.onload = () => res(img); img.onerror = () => rej(new Error('img'));
  img.src = src;
});
const FIT = 'width:100%;height:100%;object-fit:contain';

class TgEmoji extends HTMLElement {
  connectedCallback() {
    this.fallback = this.fallback ?? this.textContent;
    this.classList.add('tge');
    this.io = new IntersectionObserver(([e]) => { this.visible = e.isIntersecting; this.visible ? this.show() : this.hide(); }, { rootMargin: '120px' });
    this.io.observe(this);
  }
  disconnectedCallback() { this.io?.disconnect(); this.hide(); }

  setNode(node) { this.replaceChildren(node); this.node = node; }

  async show() {
    if (this.node || this.busy) return;
    this.busy = true;
    const id = this.getAttribute('emoji-id');
    this.dataset.state = 'loading';
    try {
      const m = await getMeta(id);
      if (!this.isConnected || !this.visible) { delete this.dataset.state; return; }
      // ۲) تصویرِ ثابتِ واقعی؛ تو همه‌ی دستگاه‌ها و فرمت‌ها کار می‌کنه
      const still = m.format === 'webp' ? m.url : m.thumb;
      if (still) {
        const img = await loadImg(still, this.fallback, FIT);
        if (!this.isConnected || !this.visible) { delete this.dataset.state; return; }
        this.setNode(img);
        this.dataset.state = 'still';
      }
      if (m.format === 'webp') { this.dataset.state = 'ok'; return; }
      // ۳) ارتقا به انیمیشن؛ شکستش مهم نیست (تصویرِ ثابت می‌مونه)
      const motionOk = !reduceMotion.matches && live < MAX_LIVE && !(m.format === 'webm' && isIOS);
      if (!motionOk) { if (!still) throw new Error('no still image'); return; }
      live++; this.counted = true;
      try {
        const anim = await this.motion(m);
        if (anim && this.isConnected && this.visible) { this.setNode(anim); this.dataset.state = 'ok'; } else this.release();
      } catch (e) {
        this.release();
        console.warn('tg-emoji: animation failed, keeping still image', id, e.message);
        if (!this.node) throw e;
      }
    } catch (e) {
      this.dataset.state = 'error';
      console.warn('tg-emoji: failed', id, e.message);                // ← تو کنسول/لاگ ببین چرا لود نشد
    } finally { this.busy = false; }
  }

  release() {
    if (this.counted) { live--; this.counted = false; }
    this.anim?.destroy?.(); this.anim = null;
  }
  hide() {
    this.release();
    if (this.node) { this.node = null; this.textContent = this.fallback; }
    delete this.dataset.state;
  }

  async motion(m) {
    if (m.format === 'webm') {
      const v = document.createElement('video');
      Object.assign(v, { src: m.url, muted: true, loop: true, autoplay: true, playsInline: true });
      v.style.cssText = FIT;
      await new Promise((res, rej) => { v.onloadeddata = res; v.onerror = () => rej(new Error('video')); setTimeout(() => rej(new Error('video timeout')), 5000); });
      v.play?.().catch(() => {});
      return v;
    }
    await ensureLottie();
    const buf = await (await fetch(m.url)).arrayBuffer();
    const json = await new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).json();
    const box = document.createElement('span');
    box.style.cssText = 'display:block;width:100%;height:100%';
    if (m.repaint) box.dataset.repaint = '';
    this.anim = window.lottie.loadAnimation({ container: box, renderer: 'svg', loop: true, autoplay: true, animationData: json });
    await new Promise((res, rej) => { this.anim.addEventListener('DOMLoaded', res); this.anim.addEventListener('data_failed', () => rej(new Error('lottie data'))); setTimeout(res, 1500); });
    return box;
  }
}
if (!customElements.get('tg-emoji')) customElements.define('tg-emoji', TgEmoji);
document.addEventListener('visibilitychange', () => {   // تب مخفی → انیمیشن‌ها متوقف
  document.querySelectorAll('tg-emoji').forEach((el) => { if (document.hidden) el.hide?.(); else if (el.visible) el.show?.(); });
});
