// post-model.js — منطقِ خالصِ ویرایشگر (بدون DOM؛ تو node هم تست می‌شه).
// متنِ پست تو دیتابیس «HTML تلگرام» ـه؛ تو ویرایشگر اموجی‌های پرمیوم به شکل [آیدی] نمایش داده می‌شن
// (همون سینتکسِ خودِ ربات) تا متن خوانا بمونه.

export const ID_TOKEN = /\[(\d{10,25})\]/g;
const VS16 = '\ufe0f';

export const escapeHtml = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const splitTags = (html) => String(html).split(/(<[^>]+>)/);
const isTag = (p) => p.startsWith('<') && p.endsWith('>');

/** HTML ذخیره‌شده → متنِ قابل‌ویرایش. اموجی‌های پرمیوم می‌شن [id]؛ کاراکترِ جایگزین تو chars نگه‌داری می‌شه. */
export function htmlToEditable(html) {
  const chars = {};
  const text = String(html || '').replace(/<tg-emoji\s+emoji-id="(\d+)">([\s\S]*?)<\/tg-emoji>/g, (_, id, ch) => {
    chars[id] = ch;
    return `[${id}]`;
  });
  return { text, chars };
}

export const invertMapping = (mapping) => Object.fromEntries(Object.entries(mapping || {}).map(([c, id]) => [id, c]));

/** [id] → <tg-emoji>. کاراکترِ جایگزین: از chars، بعد از رزروهای کاربر، وگرنه ⭐ (مثل ربات). */
export function editableToHtml(text, chars = {}, mapping = {}) {
  const inv = invertMapping(mapping);
  return splitTags(text).map((p) => (isTag(p) ? p : p.replace(ID_TOKEN, (_, id) =>
    `<tg-emoji emoji-id="${id}">${chars[id] || inv[id] || '⭐'}</tg-emoji>`))).join('');
}

/** اموجی‌های معمولیِ رزروشده → پرمیوم (همان رفتارِ سرور؛ بیرون از تگ‌ها و داخل tg-emoji/code/pre نه). */
export function applyReserved(html, mapping) {
  const keys = Object.keys(mapping || {});
  if (!keys.length) return html;
  const norm = Object.fromEntries(keys.map((c) => [c.replaceAll(VS16, ''), mapping[c]]));
  const bases = Object.keys(norm).sort((a, b) => b.length - a.length);
  const re = new RegExp(bases.map((c) => c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + VS16 + '?').join('|'), 'gu');
  let skip = 0;
  return splitTags(html).map((p) => {
    if (isTag(p)) {
      const m = /^<(\/?)([a-zA-Z-]+)/.exec(p);
      if (m && ['tg-emoji', 'code', 'pre'].includes(m[2].toLowerCase())) skip = Math.max(0, skip + (m[1] ? -1 : 1));
      return p;
    }
    return skip ? p : p.replace(re, (mm) => `<tg-emoji emoji-id="${norm[mm.replaceAll(VS16, '')]}">${mm}</tg-emoji>`);
  }).join('');
}

// ── whitelistِ تگ‌های تلگرام (برای پیش‌نمایش؛ سرور دوباره و سخت‌گیرانه‌تر پاک‌سازی می‌کنه) ──
const ALIASES = { strong: 'b', em: 'i', ins: 'u', strike: 's', del: 's' };
const ALLOWED = new Set(['b', 'i', 'u', 's', 'code', 'pre', 'a', 'blockquote', 'tg-spoiler', 'tg-emoji', 'span']);
const URL_OK = /^(https?:\/\/|tg:\/\/|mailto:)[^\s"'<>]+$/i;
const ENTITY_OK = /&(?:amp|lt|gt|quot|#\d{1,7}|#x[0-9a-fA-F]{1,6});/g;
const rawEscape = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function escapeText(s) {
  let out = '', pos = 0;
  for (const m of s.matchAll(ENTITY_OK)) { out += rawEscape(s.slice(pos, m.index)) + m[0]; pos = m.index + m[0].length; }
  return out + rawEscape(s.slice(pos));
}
const attr = (attrs, name) => {
  const m = new RegExp(`\\b${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)')`, 'i').exec(attrs || '');
  return m ? (m[1] ?? m[2]) : null;
};

export function sanitizeHtml(text) {
  const src = String(text || '').replace(/\r\n/g, '\n');
  const out = [], stack = [];
  let pos = 0, spanSkipped = 0;
  const closeTo = (name) => {
    while (stack.length && stack[stack.length - 1] !== name) out.push(`</${stack.pop()}>`);
    if (stack.length) out.push(`</${stack.pop()}>`);
  };
  for (const m of src.matchAll(/<(\/?)([a-zA-Z][a-zA-Z0-9-]*)((?:\s+[^<>]*)?)>/g)) {
    out.push(escapeText(src.slice(pos, m.index)));
    pos = m.index + m[0].length;
    const closing = m[1] === '/';
    let name = m[2].toLowerCase();
    name = ALIASES[name] || name;
    if (!ALLOWED.has(name)) continue;
    if (name === 'span') {
      if (closing) name = stack.includes('tg-spoiler') ? 'tg-spoiler' : name;      // </span> بستنِ spoiler رو می‌بنده
      else if ((attr(m[3], 'class') || '') !== 'tg-spoiler') { spanSkipped++; continue; }
      else name = 'tg-spoiler';
    }
    if (closing) {
      if (m[2].toLowerCase() === 'span' && spanSkipped > 0 && name === 'span') { spanSkipped--; continue; }
      if (stack.includes(name)) closeTo(name);
      continue;
    }
    let tag;
    if (name === 'a') {
      const href = attr(m[3], 'href');
      if (!href || !URL_OK.test(href.replaceAll('&amp;', '&'))) continue;
      tag = `<a href="${href.replaceAll('"', '&quot;')}">`;
    } else if (name === 'tg-emoji') {
      const id = attr(m[3], 'emoji-id');
      if (!id || !/^\d{5,25}$/.test(id)) continue;
      tag = `<tg-emoji emoji-id="${id}">`;
    } else if (name === 'blockquote') tag = /\bexpandable\b/i.test(m[3] || '') ? '<blockquote expandable>' : '<blockquote>';
    else tag = `<${name}>`;
    stack.push(name);
    out.push(tag);
  }
  out.push(escapeText(src.slice(pos)));
  while (stack.length) out.push(`</${stack.pop()}>`);
  return out.join('');
}

export function visibleLength(html) {
  return String(html || '').replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&').length;
}

/** متغیرهای قالب ({name} {date} ...) — فقط متغیرهای شناخته‌شده؛ مقدارها escape می‌شن. */
export const VARIABLES = ['name', 'first_name', 'username', 'id', 'group', 'date', 'time', 'code', 'views'];
export function fillVariables(html, vars) {
  return String(html).replace(/\{(name|first_name|username|id|group|date|time|code|views)\}/g, (_, k) => escapeHtml(vars[k] ?? ''));
}

/** دورِ انتخابِ textarea تگ می‌ذاره. اگه چیزی انتخاب نشده باشه placeholder رو انتخاب‌شده درج می‌کنه. */
export function wrapSelection(value, start, end, open, close, placeholder = '') {
  const sel = value.slice(start, end) || placeholder;
  const next = value.slice(0, start) + open + sel + close + value.slice(end);
  return { value: next, selStart: start + open.length, selEnd: start + open.length + sel.length };
}

export function insertAt(value, start, end, text) {
  return { value: value.slice(0, start) + text + value.slice(end), selStart: start + text.length, selEnd: start + text.length };
}

/** اعتبارسنجیِ سمت کلاینتِ دکمه‌ها؛ لیستِ خطاها (کلیدِ i18n) برمی‌گردونه. */
export function validateButtons(rows) {
  const errs = [];
  if (rows.length > 8) errs.push('err_rows');
  rows.forEach((row) => {
    if (row.length < 1 || row.length > 3) errs.push('err_row_size');
    row.forEach((b) => {
      if (!String(b.text || '').trim()) errs.push('err_btn_text');
      if ((b.type || 'url') === 'url' && !/^(https?:\/\/|tg:\/\/|mailto:)[^\s"'<>]+$/i.test(String(b.url || '').trim())) errs.push('err_btn_url');
    });
  });
  return [...new Set(errs)];
}
