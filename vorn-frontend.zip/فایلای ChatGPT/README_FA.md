# VORN — Neon Blue Frontend

فرانت‌اند بازطراحی‌شدهٔ VORN با تم روشن/تاریک آبی نئونی، فونت فارسی محلی و حفظ قابلیت‌های موجود.

## محتویات

- `index.html` — shell اصلی
- `static/js/` — منطق برنامه، مدل پست، Telegram Mini App، ترجمه و custom emoji
- `static/css/app.css` — design system و UI
- `static/fonts/` — فونت‌های محلی Noto Sans Arabic، subset رنگی emoji و مجوزها
- `FRONTEND_SPEC_FA.md` — سند مرجع کامل برای توسعه‌دهنده یا AI بعدی
- `tests/` و `scripts/` — تست‌های unit و smoke check

## اجرا

این پروژه به backend اصلی VORN نیاز دارد. فایل‌ها را در مسیر استاتیک همان backend قرار بده و مطمئن شو `/api/*` به سرویس اصلی وصل است.

برای حالت توسعهٔ مرورگر:

`/?dev=YOUR_DEV_TOKEN`

برای تست:

```bash
npm test
npm run verify
```

## نکات مهم

- فایل جدید `tg-emoji.js` حفظ شده است.
- هیچ backend یا API mock به بسته اضافه نشده است.
- vendor محلی Lottie در این بسته نیست؛ `tg-emoji.js` مسیر محلی و fallback CDN را دارد. برای اجرای کاملاً offline انیمیشن TGS، نسخهٔ معتبر lottie-web را در `static/js/vendor/` قرار بده.
- قراردادها، routeها، payloadها و معیارهای پذیرش در `FRONTEND_SPEC_FA.md` توضیح داده شده‌اند.
