import { readFile, access } from 'node:fs/promises';
import { constants } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = [
  'static/js/app.js', 'static/js/i18n.js', 'static/js/post-model.js',
  'static/js/tg-emoji.js', 'static/js/tma.js'
];
for (const file of files) {
  const source = await readFile(path.join(root, file), 'utf8');
  // Parse ES module syntax without executing browser-dependent modules.
  const check = spawnSync(process.execPath, ['--check', path.join(root, file)], { encoding: 'utf8' });
  if (check.status !== 0) throw new Error(`${file}: ${check.stderr || check.stdout}`);
  console.log(`OK syntax: ${file}`);
}
const html = await readFile(path.join(root, 'index.html'), 'utf8');
for (const id of ['top', 'tabs', 'main', 'primary', 'toasts', 'sheets']) {
  if (!html.includes(`id="${id}"`)) throw new Error(`Missing required shell node #${id}`);
}
console.log('OK shell: required mount points present');
for (const asset of [
  'static/css/app.css', 'static/fonts/NotoSansArabic-Regular.ttf',
  'static/fonts/NotoSansArabic-Medium.ttf', 'static/fonts/NotoSansArabic-SemiBold.ttf',
  'static/fonts/NotoSansArabic-Bold.ttf', 'static/fonts/Vorn-Emoji.ttf', 'static/img/favicon.svg'
]) {
  await access(path.join(root, asset), constants.R_OK);
  console.log(`OK asset: ${asset}`);
}
const css = await readFile(path.join(root, 'static/css/app.css'), 'utf8');
if (!css.includes('data-theme="dark"') || !css.includes('prefers-reduced-motion')) {
  throw new Error('Theme or reduced-motion rules are missing');
}
console.log('OK CSS: dark theme and reduced-motion rules present');
