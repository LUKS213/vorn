"""bot.py — ربات تلگرام (telebot): همه‌ی هندلرها، کیبوردها، حالت اینلاین و منطق ربات.

سلف و Telethon تو self.py هستن؛ لایه‌ی داده تو strong.py؛ تنظیمات تو config.py.
اجرا از main.py انجام می‌شه.
"""
import re
import json
import math
import os
import html
import asyncio
import threading
import time as time_module
import uuid
import copy
import functools
import zlib
import random
import string
import requests
import telebot
from telebot.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    InputMediaPhoto, InputMediaVideo, InputMediaDocument, InputMediaAudio,
    InlineQueryResultArticle, InputTextMessageContent,
    InlineQueryResultCachedPhoto, InlineQueryResultCachedVideo,
    InlineQueryResultCachedDocument, InlineQueryResultCachedMpeg4Gif,
)
from telebot.types import WebAppInfo, LoginUrl
import config
import strong
import i18n
from i18n import t as tr
from config import *  # noqa: F401,F403  (توکن، کلیدها و ثابت‌ها حالا تو config.py هستن)
from strong import load_json, save_json, load_json_readonly  # noqa: F401
try:
    from telebot.types import CopyTextButton
except ImportError:  # نسخه‌ی قدیمیِ تله‌بات
    CopyTextButton = None
try:
    from telebot.types import SwitchInlineQueryChosenChat
except ImportError:
    SwitchInlineQueryChosenChat = None
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(SELF_DATA_DIR, exist_ok=True)
strong.init()

# فرآیندهای نیمه‌کاره: بعد از ری‌استارت برمی‌گردن (ذخیره‌ی خودکار هر ~۲ ثانیه)
user_states = strong.PersistentStates()
user_states.load()
user_states.start_autosave()
import atexit
atexit.register(user_states.flush)

# --- لایه‌ی کوین: همه‌چیز اتمیک تو SQLite (strong.py) ---
_get_coin_balance = strong.get_balance
_get_or_create_wallet_address = strong.ensure_wallet
_adjust_coin_balance = strong.adjust_balance


def _charge_coins(user_id, amount, reason="inline_send"):
    ok = strong.charge(user_id, amount, reason)
    if ok:
        _maybe_low_balance_alert(user_id)
    return ok


def _refund_coins(user_id, amount):
    return strong.refund(user_id, amount, "refund")


from self import (  # noqa: E402
    SELF_RELAY_PREFIX,
    SessionPasswordNeededError,
    _TELETHON_AVAILABLE,
    _self_relay_cache,
    _userbot_login_state,
    _userbot_request_code,
    _userbot_sign_in_code,
    _userbot_sign_in_password,
    finalize_login_session,
    is_valid_post_code,
    register_self_relay,
    run_userbot_coro,
    sanitize_html_for_telegram,
    start_autostart,
)



# لاگِ زمانیِ مرحله‌های اعمالِ اموجی پرمیوم (برای پیدا کردنِ دقیقِ جای کندی).
# بعد از اینکه کارت تموم شد False کن.
_timing_marks = {}


def _t_mark(user_id, query):
    if DEBUG_TIMING:
        _timing_marks[(user_id, (query or "").strip())] = time_module.time()
        if len(_timing_marks) > 200:
            for k in list(_timing_marks)[:100]:
                _timing_marks.pop(k, None)


def _t_since(user_id, query):
    if not DEBUG_TIMING:
        return None
    t0 = _timing_marks.get((user_id, (query or "").strip()))
    return None if t0 is None else time_module.time() - t0

# ==========================================================================
# یوزربات شخصی (برای همه‌ی کاربرها): چون Bot API هیچ‌وقت نمی‌تونه از طرف
# یه کاربر عادی اقدام کنه، اینجا از MTProto (کتابخونه‌ی Telethon) با اکانت
# شخصیِ خودِ هر کاربر استفاده می‌شه تا بشه نتیجه‌ی اینلاین رو «به‌جای خودِ کاربر»
# انتخاب/ارسال کرد — دقیقاً همون کاری که MTProto اجازه‌ش رو می‌ده و Bot API نه.
#
# قبل از استفاده باید این دو مقدار رو با اطلاعات خودت پر کنی:
#   API_ID / API_HASH → از https://my.telegram.org برای اکانت خودت بگیر
# ==========================================================================

# ==========================================================================
# دیتای «سلف» (یوزربات): هر اکانتِ لاگین‌شده با فایل سشنِ خودش شناخته می‌شه
# (اسمِ فایل = آیدیِ عددیِ همون اکانت، که خودِ تلگرام موقع لاگین بهمون می‌ده،
# نه یه ثابتِ توی سورس) — پس چندتا اکانت هم‌زمان می‌تونن سلف داشته باشن و
# دیتاشون هیچ‌وقت با هم قاطی نمی‌شه. همه‌ی فایل‌های مربوط به سلف همین
# پوشه‌ست (data/self)؛ خودِ کد فقط موقعِ لاگین از پنل ربات یه سشن می‌سازه،
# هر فایلِ *.session دیگه‌ای که دستی اینجا گذاشته بشه هم خودکار اجرا می‌شه.
# ==========================================================================

# تعداد ترد کارگرهای telebot (پیش‌فرض فقط ۲ بود): رلهٔ سلف برای هر پیام یه
# inline_query و یه callback_query به همین ربات می‌زنه؛ با ۲ ترد، یه هندلر
# کندِ دیگه (مثلاً ارسال به گروه) کلِ صفِ سلف رو عقب می‌انداخت.
bot = telebot.TeleBot(BOT_TOKEN, num_threads=BOT_WORKER_THREADS)


# ══════════════════════════════════════════════════════════════════════════
#  ترجمه‌ی خودکارِ فلوهای قدیمی برای کاربرانِ انگلیسی‌زبان + فونت ᴇᴍᴏᴊɪ
#  (متن/دکمه‌ها همون‌جا که فرستاده می‌شن ترجمه می‌شن؛ کدِ قدیمی دست‌نخورده می‌مونه.
#   جدول ترجمه: i18n_legacy.py — متنِ پست‌های کاربر هیچ‌وقت ترجمه نمی‌شه، raw_text رو ببین)
# ══════════════════════════════════════════════════════════════════════════
_ui_tl = threading.local()


class raw_text:
    """داخلِ این بلاک متن‌ها دست‌نخورده می‌رن (مثلاً ارسال پستِ خودِ کاربر)."""

    def __enter__(self):
        _ui_tl.raw = getattr(_ui_tl, "raw", 0) + 1

    def __exit__(self, *exc):
        _ui_tl.raw -= 1


def _ui_is_english(chat_id):
    if getattr(_ui_tl, "raw", 0):
        return False
    try:
        cid = int(chat_id)
    except (TypeError, ValueError):
        return False
    return cid > 0 and i18n.get_lang(cid) == "en"


def _localize_markup(markup):
    try:
        if not getattr(markup, "keyboard", None):
            return markup
        m = copy.deepcopy(markup)
        for row in m.keyboard:
            for b in row:
                if getattr(b, "text", None):
                    b.text = i18n.localize_text(b.text)
        return m
    except Exception:
        return markup


def _install_ui_localization(b):
    orig_send, orig_edit, orig_answer = b.send_message, b.edit_message_text, b.answer_callback_query
    orig_cqh = b.callback_query_handler

    def send_message(chat_id, text, *a, **k):
        if text and _ui_is_english(chat_id):
            text = i18n.localize_text(text)
            if k.get("reply_markup") is not None:
                k["reply_markup"] = _localize_markup(k["reply_markup"])
        return orig_send(chat_id, text, *a, **k)

    def edit_message_text(text, chat_id=None, message_id=None, *a, **k):
        if text and _ui_is_english(chat_id):
            text = i18n.localize_text(text)
            if k.get("reply_markup") is not None:
                k["reply_markup"] = _localize_markup(k["reply_markup"])
        return orig_edit(text, chat_id, message_id, *a, **k)

    def answer_callback_query(callback_query_id, text=None, *a, **k):
        cid = getattr(_ui_tl, "chat_id", None)
        if text and cid and _ui_is_english(cid):
            text = i18n.localize_text(text)
        return orig_answer(callback_query_id, text, *a, **k)

    def callback_query_handler(*da, **dk):
        deco = orig_cqh(*da, **dk)

        def wrap(fn):
            @functools.wraps(fn)
            def inner(call, *x, **y):
                try:
                    _ui_tl.chat_id = getattr(call.from_user, "id", None) or call.message.chat.id
                except Exception:
                    _ui_tl.chat_id = None
                return fn(call, *x, **y)
            return deco(inner)
        return wrap

    b.send_message, b.edit_message_text, b.answer_callback_query = send_message, edit_message_text, answer_callback_query
    b.callback_query_handler = callback_query_handler


_install_ui_localization(bot)


user_profiles_status = load_json(PROFILE_DATA_FILE, {})
notified_groups = set(load_json(GROUPS_DATA_FILE, []))
group_settings = load_json(GROUP_SETTINGS_FILE, {})      
group_admins = load_json(GROUP_ADMINS_FILE, {})          
channel_admins = load_json(CHANNEL_ADMINS_FILE, {})
pending_requests = load_json(PENDING_REQUESTS_FILE, {})  
blocked_users = set(load_json(BLOCKED_USERS_FILE, []))


def _is_blocked(user_id):
    return int(user_id) in blocked_users


def _set_blocked(user_id, blocked):
    uid = int(user_id)
    if blocked:
        blocked_users.add(uid)
    else:
        blocked_users.discard(uid)
    save_json(list(blocked_users), BLOCKED_USERS_FILE)


# ==========================================================================
# پروفایل قفل / پروفایل باز — زیرساخت آماده برای زمانی که چت دوطرفه بین
# کاربرها اضافه بشه (فعلاً همچین قابلیتی تو ربات وجود نداره). این فقط
# ذخیره‌سازی وضعیت هر کاربره؛ عمداً به هیچ دکمه/منو/کال‌بکی وصل نشده.
# منطق پیشنهادی برای آینده: پروفایل «باز» یعنی بقیه می‌تونن باهاش چت
# دوطرفه شروع کنن، پروفایل «قفل» یعنی این امکان بسته‌ست.
# ==========================================================================
profile_lock_settings = load_json(PROFILE_LOCK_FILE, {})


def is_profile_locked(user_id):
    return profile_lock_settings.get(str(user_id), "closed") == "closed"


def set_profile_lock(user_id, locked: bool):
    profile_lock_settings[str(user_id)] = "closed" if locked else "open"
    save_json(profile_lock_settings, PROFILE_LOCK_FILE)


# ==========================================================================
# رزرو پست آماده: کاربر یه پست (متن/رسانه/دکمه/جدول) می‌سازه و یه کد ۱۰
# کاراکتری (حروف کوچیک+بزرگ+عدد) می‌گیره. هرکسی اون کد رو با استارت ربات
# بفرسته (یا لینک /start?start=CODE رو بزنه)، دکمه‌ی «دریافت پست» رو می‌بینه
# و با زدنش همون پست (با همون دکمه‌ها/رسانه/جدول) براش ارسال می‌شه.
# ==========================================================================
POST_CODE_CHARSET = string.ascii_letters + string.digits
POST_BUTTON_STYLES = {"success": "🟢 سبز", "primary": "🔵 آبی", "danger": "🔴 قرمز"}








def save_post(owner_id, text, media, buttons):
    return strong.post_create(owner_id, text, media, buttons)


def get_saved_post(code):
    """پستِ ذخیره‌شده (SQLite)؛ پستِ منقضی‌شده None برمی‌گردونه."""
    return strong.post_get(code)




def strip_tg_emoji_tags(text):
    """تگ‌های <tg-emoji> رو باز می‌کنه و فقط محتوای داخلش (اموجی فال‌بک) رو
    نگه می‌داره؛ تلگرام اجازه نمی‌ده اموجی پرمیوم مستقیم داخل نتیجه‌ی اولیه‌ی
    اینلاین باشه، پس نسخه‌ی اول همیشه باید ساده باشه."""
    if not text:
        return text
    return re.sub(r'<tg-emoji[^>]*>(.*?)</tg-emoji>', r'\1', text)


# نوع‌های دکمه‌ی پست (همه‌ی نوع‌های تلگرام جز callback). هر نوع یه «نوع مقدار» داره:
#   url   → لینک | text → متنِ قابل‌کپی | query → متنِ کوئریِ اینلاین
POST_BUTTON_TYPES = {
    "url": ("🔗 لینک", "url"),
    "web_app": ("📱 وب‌اپ (مینی‌اپ)", "url"),
    "login_url": ("🔐 ورود با تلگرام", "url"),
    "copy_text": ("📋 کپی متن", "text"),
    "switch_inline": ("🔀 اینلاین (انتخابِ چت)", "query"),
    "switch_inline_current": ("↪️ اینلاین تو همین چت", "query"),
    "switch_inline_chosen": ("🎯 اینلاین (فیلترِ چت)", "query"),
}
POST_BUTTON_TYPE_EMOJI = {k: v[0].split(" ")[0] for k, v in POST_BUTTON_TYPES.items()}


def _make_post_button(b, with_icon=True, private=False):
    """از دیکشنریِ ذخیره‌شده‌ی یه دکمه، InlineKeyboardButton می‌سازه.
    private=True یعنی پیام تو پیوی خودِ ربات می‌ره؛ فقط اونجا وب‌اپ واقعاً
    وب‌اپ باز می‌کنه — تو گروه/اینلاین تلگرام ردش می‌کنه، پس به لینک معمولی
    تبدیل می‌شه. اگه نوعی با تله‌باتِ نصب‌شده نسازه، None برمی‌گرده."""
    btype = b.get("type") or "url"
    kwargs = {"text": b["text"]}
    try:
        if btype == "web_app":
            if private:
                kwargs["web_app"] = WebAppInfo(url=b["url"])
            else:
                kwargs["url"] = b["url"]
        elif btype == "login_url":
            kwargs["login_url"] = LoginUrl(url=b["url"])
        elif btype == "copy_text":
            if CopyTextButton is None:
                return None
            kwargs["copy_text"] = CopyTextButton(text=b["copy_text"])
        elif btype == "switch_inline":
            kwargs["switch_inline_query"] = b.get("query", "")
        elif btype == "switch_inline_current":
            kwargs["switch_inline_query_current_chat"] = b.get("query", "")
        elif btype == "switch_inline_chosen":
            if SwitchInlineQueryChosenChat is None:
                kwargs["switch_inline_query"] = b.get("query", "")
            else:
                kwargs["switch_inline_query_chosen_chat"] = SwitchInlineQueryChosenChat(
                    query=b.get("query", ""),
                    allow_user_chats=True, allow_bot_chats=True,
                    allow_group_chats=True, allow_channel_chats=True,
                )
        else:  # url و دکمه‌های قدیمیِ بدون فیلدِ type
            kwargs["url"] = b["url"]
    except Exception as e:
        print(f"⚠️ [post_button] ساختِ دکمه‌ی {btype} ممکن نشد: {e}")
        return None
    if b.get("style"):
        kwargs["style"] = b["style"]
    if with_icon and b.get("icon_custom_emoji_id"):
        kwargs["icon_custom_emoji_id"] = b["icon_custom_emoji_id"]
    return InlineKeyboardButton(**kwargs)


def _build_markup_from_rows(buttons, with_icon, private):
    if not buttons:
        return None
    markup = InlineKeyboardMarkup()
    added = False
    for row in buttons:
        row_btns = [x for x in (_make_post_button(b, with_icon=with_icon, private=private) for b in row) if x is not None]
        if row_btns:
            markup.row(*row_btns)
            added = True
    return markup if added else None


def build_plain_post_markup(buttons, private=False):
    """مثل build_post_markup ولی بدون icon_custom_emoji_id (برای نسخه‌ی
    اولیه‌ی اینلاین)."""
    return _build_markup_from_rows(buttons, with_icon=False, private=private)


def build_inline_result_for_post(post, apply_token=None, force_plain=False):
    """نتیجه‌ی حالت اینلاین برای فرستادن یه پست (ذخیره‌شده یا پستِ موقتِ سلف).
    نکته‌ی مهمِ پلتفرم: تلگرام اجازه نمی‌ده اموجی پرمیوم مستقیم تو محتوای
    متنیِ (بدون رسانه) نتیجه‌ی اینلاین باشه؛ تو کپشنِ رسانه ولی مشکلی نداره.
    برای همین:
    - اگه پست رسانه داره (و force_plain نباشه): نسخه‌ی کامل مستقیم.
    - اگه رسانه نداره: نسخه‌ی ساده + (اگه apply_token داده بشه) دکمه‌ی
      «فعال‌سازی»؛ نسخه‌ی کامل بعداً با chosen_inline_result یا کلیکِ دکمه
      جایگزین می‌شه (نگاه کن به _apply_self_relay)."""
    buttons = post.get("buttons") or []
    text = sanitize_html_for_telegram(post.get("text") or "")
    media = post.get("media")

    use_plain = force_plain or not media
    if use_plain:
        markup = build_plain_post_markup(buttons)
        if apply_token and not force_plain:
            if markup is None:
                markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton(text="✨ فعال‌سازی اموجی پرمیوم", callback_data=f"apply_emoji_{apply_token}"))
        text = strip_tg_emoji_tags(text)
    else:
        markup = build_post_markup(buttons)

    result_id = f"selfpost_{apply_token}" if apply_token else f"post_{uuid.uuid4().hex[:8]}"

    if media:
        mtype = media.get("type")
        file_id = media.get("file_id")
        caption = text or None
        if mtype == "photo":
            return InlineQueryResultCachedPhoto(id=result_id, photo_file_id=file_id, caption=caption, parse_mode="HTML", reply_markup=markup)
        elif mtype == "video":
            return InlineQueryResultCachedVideo(id=result_id, video_file_id=file_id, title="ارسال پست", caption=caption, parse_mode="HTML", reply_markup=markup)
        elif mtype == "document":
            return InlineQueryResultCachedDocument(id=result_id, document_file_id=file_id, title="ارسال پست", caption=caption, parse_mode="HTML", reply_markup=markup)
        elif mtype == "animation":
            return InlineQueryResultCachedMpeg4Gif(id=result_id, mpeg4_file_id=file_id, caption=caption, parse_mode="HTML", reply_markup=markup)

    return InlineQueryResultArticle(
        id=result_id,
        title="ارسال پست",
        description=(html.unescape(re.sub(r'<[^>]+>', '', text)).strip()[:100] or "پست ذخیره‌شده"),
        input_message_content=InputTextMessageContent(message_text=text or " ", parse_mode="HTML"),
        reply_markup=markup,
    )


def build_post_markup(buttons, private=False):
    return _build_markup_from_rows(buttons, with_icon=True, private=private)


def _btn_wizard_nav_row(markup):
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )
    return markup


def _btn_type_markup():
    markup = InlineKeyboardMarkup()
    for key, (label, _kind) in POST_BUTTON_TYPES.items():
        markup.add(InlineKeyboardButton(label, callback_data=f"rpost_btype_{key}", style="primary"))
    return _btn_wizard_nav_row(markup)


def _btn_style_markup():
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("🟢 سبز", callback_data="rpost_style_success"),
        InlineKeyboardButton("🔵 آبی", callback_data="rpost_style_primary"),
        InlineKeyboardButton("🔴 قرمز", callback_data="rpost_style_danger"),
    )
    return _btn_wizard_nav_row(markup)


_BTN_VALUE_PROMPTS = {
    "url": "لینک دکمه رو بفرست (باید با http یا https یا tg:// شروع بشه) 🔗:",
    "web_app": "آدرسِ وب‌اپ رو بفرست (حتماً با https:// شروع بشه) 📱\n"
               "نکته: وب‌اپِ واقعی فقط تو پیوی ربات باز می‌شه؛ تو گروه/اینلاین به‌صورت لینکِ معمولی باز می‌شه.",
    "login_url": "آدرسِ ورود رو بفرست (حتماً https://) 🔐\n"
                 "نکته: دامنه‌ش باید تو BotFather با /setdomain برای همین ربات ثبت شده باشه، وگرنه تلگرام دکمه رو رد می‌کنه.",
    "copy_text": "متنی که با زدنِ دکمه کپی می‌شه رو بفرست (حداکثر ۲۵۶ کاراکتر) 📋:",
    "switch_inline": "متنی که تو کوئریِ اینلاین پر بشه رو بفرست (برای خالی ۰؛ حداکثر ۲۵۶ کاراکتر) 🔀\n"
                     "کاربر با زدنِ دکمه چتِ مقصد رو انتخاب می‌کنه.",
    "switch_inline_current": "متنی که تو کوئریِ اینلاین پر بشه رو بفرست (برای خالی ۰؛ حداکثر ۲۵۶ کاراکتر) ↪️\n"
                             "با زدنِ دکمه تو همین چت اینلاین باز می‌شه.",
    "switch_inline_chosen": "متنی که تو کوئریِ اینلاین پر بشه رو بفرست (برای خالی ۰؛ حداکثر ۲۵۶ کاراکتر) 🎯\n"
                            "کاربر با زدنِ دکمه از بینِ چت‌ها انتخاب می‌کنه.",
}


def _parse_btn_value(btype, raw):
    """مقدارِ واردشده برای یه نوعِ دکمه رو بررسی می‌کنه. خروجی: (فیلدهای دکمه، پیامِ خطا)."""
    raw = (raw or "").strip()
    kind = POST_BUTTON_TYPES[btype][1]
    if kind == "url":
        if btype in ("web_app", "login_url"):
            if not raw.startswith("https://"):
                return None, "آدرس باید با https:// شروع بشه ❌"
        elif not (raw.startswith("http://") or raw.startswith("https://") or raw.startswith("tg://")):
            return None, "لینک معتبر نیست؛ باید با http یا https یا tg:// شروع بشه ❌"
        return {"url": raw}, None
    if kind == "text":
        if not raw or len(raw) > 256:
            return None, "متن باید بینِ ۱ تا ۲۵۶ کاراکتر باشه ❌"
        return {"copy_text": raw}, None
    query = "" if raw == "0" else raw
    if len(query) > 256:
        return None, "متن نباید بیشتر از ۲۵۶ کاراکتر باشه ❌"
    return {"query": query}, None


_POST_VAR_RE = re.compile(r"\{(name|first_name|username|id|group|date|time|code|views)\}")


def _post_track_buttons(buttons, code):
    """دکمه‌های لینکیِ پستِ «ردیابی‌شده» از مسیر /r/<code>/<idx> رد می‌شن تا کلیک‌ها شمرده بشن."""
    if not (config.PUBLIC_URL and code):
        return buttons
    out, idx = [], 0
    for row in buttons:
        new_row = []
        for b in row:
            nb = dict(b)
            if (nb.get("type") or "url") == "url" and str(nb.get("url", "")).startswith(("http://", "https://")):
                nb["url"] = f"{config.PUBLIC_URL.rstrip('/')}/r/{code}/{idx}"
            new_row.append(nb)
            idx += 1
        out.append(new_row)
    return out


def _render_post_variables(text, chat_id, post, private):
    """متغیرهای قالب ({name} {date} ...) رو موقع ارسال جایگزین می‌کنه (فقط برای پست‌های «قالب»)."""
    if not text or "{" not in text:
        return text
    first = last = username = title = ""
    try:
        chat = bot.get_chat(chat_id)
        if private:
            first, last = chat.first_name or "", chat.last_name or ""
            username = f"@{chat.username}" if chat.username else ""
        else:
            title = chat.title or ""
    except Exception:
        pass
    stamp = _fmt_dt(post.get("owner_id"), time_module.time()).split(" ")
    vals = {
        "name": f"{first} {last}".strip() or username or str(chat_id),
        "first_name": first or username, "username": username, "id": str(chat_id), "group": title,
        "date": stamp[0], "time": stamp[-1], "code": post.get("code") or "", "views": str(post.get("views", 0)),
    }
    return _POST_VAR_RE.sub(lambda m: html.escape(vals[m.group(1)]), text)


def _send_post_impl(chat_id, post, private=True, strict=False):
    """متن از قبل (موقع ثبت پست) کامل پردازش شده؛ اینجا مستقیم و بدون فیلتر سراسری فرستاده می‌شه تا
    فرمت‌بندی اصلی (بولد/بلاک‌کوت/تگ‌های [آیدی]) دست‌نخورده بمونه. پشتیبانی از قالب/متغیر، آلبوم
    (media = لیست) و شمارش کلیک. strict=True خطا رو بالا می‌ده (برای ارسال چندمقصده/زمان‌بندی)."""
    code = post.get("code")
    raw = post.get("text") or ""
    if post.get("template"):
        raw = _render_post_variables(raw, chat_id, post, private)
    text = sanitize_html_for_telegram(raw)
    media = post.get("media")
    buttons = post.get("buttons") or []
    if post.get("track_clicks") and code:
        buttons = _post_track_buttons(buttons, code)

    try:
        with raw_text():
            markup = build_post_markup(buttons, private=private) if buttons else None
            if isinstance(media, list) and media:
                group = []
                kinds = {"photo": InputMediaPhoto, "video": InputMediaVideo, "document": InputMediaDocument}
                for m in media[:10]:
                    cls = kinds.get(m.get("type"))
                    if cls:
                        group.append(cls(m["file_id"], caption=(text or None) if not group else None, parse_mode="HTML"))
                if group:
                    bot.send_media_group(chat_id, group)
                if markup:
                    bot.send_message(chat_id, "👇", reply_markup=markup)
            elif media:
                mtype = media.get("type")
                file_id = media.get("file_id")
                senders = {"photo": bot.send_photo, "video": bot.send_video, "document": bot.send_document,
                           "animation": bot.send_animation, "audio": bot.send_audio}
                if mtype in senders:
                    senders[mtype](chat_id, file_id, caption=text or None, parse_mode="HTML", reply_markup=markup)
            elif text:
                bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)
            elif buttons:
                bot.send_message(chat_id, "📌", reply_markup=markup)
            if code:
                strong.post_view(code)
    except Exception as e:
        if strict:
            raise
        print(f"❌ خطا در ارسال پست ذخیره‌شده: {e}")
        try:
            bot.send_message(chat_id, "متأسفانه ارسال پست با خطا مواجه شد ❌")
        except Exception:
            pass


def send_saved_post(chat_id, post, private=True):
    _send_post_impl(chat_id, post, private=private)


def send_saved_post_to_group(chat_id, state_data, target_id):
    """مسیر جدا و ساده برای فرستادن یه پست ذخیره‌شده (با کد) به یه گروه، از
    طریق همون فلوی «ارسال پیام به گروه». عمداً وارد پایپ‌لاین پیچیده‌ی
    copy_message/final_html نمی‌شه چون پست از قبل کامل ساخته شده."""
    post = state_data.get("saved_post")
    post_code = state_data.get("saved_post_code")
    last_msg_id = state_data.get("last_bot_msg_id")
    user_states.pop(chat_id, None)

    admins = update_group_admins_list(target_id)
    is_user_admin = chat_id in admins
    is_locked = group_settings.get(str(target_id), "open") == "closed"

    if is_locked and not is_user_admin:
        if not admins:
            msg = "اطلاعات مدیران این گروه در سیستم ثبت نشده است ⛔"
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, msg, reply_markup=main_keyboard(chat_id))
            else:
                send_styled_message(chat_id, msg, reply_markup=main_keyboard(chat_id))
            return

        req_id = f"{chat_id}_post_{uuid.uuid4().hex[:8]}"
        pending_requests[req_id] = {
            "target_id": target_id,
            "sender_id": chat_id,
            "is_saved_post": True,
            "post_code": post_code,
            "admin_messages": {},
        }

        approval_markup = InlineKeyboardMarkup()
        approval_markup.add(
            InlineKeyboardButton("تایید درخواست", callback_data=f"approve_req_{req_id}", style="success", icon_custom_emoji_id="5465465194056525619"),
            InlineKeyboardButton("رد درخواست", callback_data=f"reject_req_{req_id}", style="danger", icon_custom_emoji_id="5465225015190367274")
        )
        try:
            user_chat_obj = bot.get_chat(chat_id)
            sender_user_name = html.escape(user_chat_obj.first_name or "کاربر")
        except Exception:
            sender_user_name = "کاربر"
        admin_text = (
            '<tg-emoji emoji-id="5454113432284446338">✉️</tg-emoji> <b>درخواست ارسال پست ذخیره‌شده به گروه قفل 🔒</b>\n\n'
            f"<b>فرستنده:</b> <a href=\"tg://user?id={chat_id}\">{sender_user_name}</a>\n"
            f"<b>کد پست:</b> <code>{post_code}</code>"
        )
        for admin_id in admins:
            if _is_blocked(admin_id):
                continue
            try:
                sent_admin_msg = send_styled_message(admin_id, admin_text, reply_markup=approval_markup)
                if sent_admin_msg:
                    pending_requests[req_id]["admin_messages"][admin_id] = sent_admin_msg.message_id
            except Exception:
                pass
        save_json(pending_requests, PENDING_REQUESTS_FILE)

        msg = "پست شما برای بررسی به ادمین(های) گروه ارسال شد ⏳"
        if last_msg_id:
            edit_or_send_message(chat_id, last_msg_id, msg, reply_markup=main_keyboard(chat_id))
        else:
            send_styled_message(chat_id, msg, reply_markup=main_keyboard(chat_id))
        return

    send_saved_post(target_id, post, private=False)
    msg = "✅ پست با موفقیت به گروه ارسال شد."
    if last_msg_id:
        edit_or_send_message(chat_id, last_msg_id, msg, reply_markup=main_keyboard(chat_id))
    else:
        send_styled_message(chat_id, msg, reply_markup=main_keyboard(chat_id))


def edit_or_send_raw_html(chat_id, message_id, text, reply_markup=None):
    """مثل edit_or_send_message ولی بدون عبور از فیلتر سراسری اموجی پرمیوم؛
    برای نمایش متنی که از قبل کامل فرمت‌دهی شده (مثل متن پست)."""
    try:
        return bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, parse_mode="HTML", reply_markup=reply_markup)
    except Exception:
        try:
            return bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=reply_markup)
        except Exception:
            return bot.send_message(chat_id, text, reply_markup=reply_markup)


def _custom_yes_no_keyboard(yes_data, no_data):
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("بله ✅", callback_data=yes_data, style="success"),
        InlineKeyboardButton("خیر ❌", callback_data=no_data, style="danger"),
    )
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )
    return markup


def build_post_builder_panel(chat_id):
    state_data = user_states.get(chat_id, {})
    text = state_data.get("draft_text") or ""
    media = state_data.get("draft_media")
    rows = state_data.get("draft_button_rows") or []
    total_buttons = sum(len(r) for r in rows)

    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("📝 متن" + (" ✅" if text else ""), callback_data="rpost_menu_text", style="primary"),
        InlineKeyboardButton("🖼 رسانه" + (" ✅" if media else ""), callback_data="rpost_menu_media", style="primary"),
    )
    markup.row(InlineKeyboardButton(f"🔘 دکمه‌ها ({total_buttons})", callback_data="rpost_menu_buttons", style="primary"))
    markup.row(InlineKeyboardButton("👁 دریافت (پیش‌نمایش)", callback_data="rpost_menu_preview", style="primary"))
    markup.row(InlineKeyboardButton("✅ پایان و دریافت کد", callback_data="rpost_menu_finish", style="success"))
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    body = (
        "<b>🛠 ساخت پست</b>\n\n"
        f"📝 متن: {'ثبت شده' if text else 'ثبت نشده'}\n"
        f"🖼 رسانه: {'ثبت شده' if media else 'ثبت نشده'}\n"
        f"🔘 دکمه‌ها: {total_buttons} عدد\n\n"
        "یکی از بخش‌ها رو انتخاب کن 👇"
    )
    return body, markup


def build_post_text_panel(chat_id):
    text = user_states.get(chat_id, {}).get("draft_text") or ""
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("✏️ ویرایش متن", callback_data="rpost_text_edit", style="primary"))
    markup.add(InlineKeyboardButton("🔙 بازگشت", callback_data="rpost_menu_back", style="danger"))
    body = "<b>📝 متن پست</b>\n\n" + (text if text else "هنوز متنی ثبت نشده.")
    return body, markup


def build_post_media_panel(chat_id):
    media = user_states.get(chat_id, {}).get("draft_media")
    markup = InlineKeyboardMarkup()
    if media:
        markup.add(InlineKeyboardButton("✏️ ویرایش رسانه", callback_data="rpost_media_edit", style="primary"))
        markup.add(InlineKeyboardButton("🗑 حذف رسانه", callback_data="rpost_media_delete", style="danger"))
    else:
        markup.add(InlineKeyboardButton("➕ افزودن رسانه", callback_data="rpost_media_edit", style="success"))
    markup.add(InlineKeyboardButton("🔙 بازگشت", callback_data="rpost_menu_back", style="danger"))
    media_label = {"photo": "عکس", "video": "ویدیو", "document": "فایل", "animation": "گیف"}.get((media or {}).get("type"), None)
    body = "<b>🖼 رسانه‌ی پست</b>\n\n" + (f"نوع فعلی: {media_label}" if media else "هنوز رسانه‌ای ثبت نشده.")
    return body, markup


def build_post_buttons_panel(chat_id):
    rows = user_states.get(chat_id, {}).get("draft_button_rows") or []
    total_buttons = sum(len(r) for r in rows)
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("➕ افزودن دکمه", callback_data="rpost_btn_add", style="success"))
    for r_idx, row in enumerate(rows):
        for c_idx, b in enumerate(row):
            kwargs = {"text": f"🗑 ({r_idx + 1},{c_idx + 1}) {POST_BUTTON_TYPE_EMOJI.get(b.get('type') or 'url', '🔗')} {b.get('text')}", "callback_data": f"rpost_btn_del_{r_idx}_{c_idx}", "style": "danger"}
            if b.get("icon_custom_emoji_id"):
                kwargs["icon_custom_emoji_id"] = b["icon_custom_emoji_id"]
            markup.add(InlineKeyboardButton(**kwargs))
    markup.add(InlineKeyboardButton("🔙 بازگشت", callback_data="rpost_menu_back", style="danger"))
    body = f"<b>🔘 دکمه‌های پست</b>\n\nتعداد فعلی: {total_buttons} دکمه در {len(rows)} ردیف\n(شماره‌ی جلوی هر دکمه یعنی: ردیف،ستون)"
    return body, markup


def _finalize_reserve_post(chat_id, msg_id):
    state_data = user_states.get(chat_id, {})
    text = state_data.get("draft_text", "")
    media = state_data.get("draft_media")
    buttons = state_data.get("draft_button_rows", [])

    code = save_post(chat_id, text, media, buttons)
    user_states[chat_id] = {}

    success_msg = (
        "✅ پست با موفقیت رزرو شد!\n\n"
        f"کد پست: <code>{code}</code>\n\n"
        f"برای فرستادنش، هرکسی این کد رو داشته باشه کافیه تو هر چتی بنویسه:\n<code>@{BOT_USERNAME} {code}</code>\n"
        "و گزینه‌ی «ارسال پست» رو بزنه؛ پست دقیقاً با همون متن/رسانه/دکمه‌ها ارسال می‌شه.\n\n"
        f"(یه راه دیگه: با /start و فرستادن همین کد تو پیوی ربات هم می‌شه پست رو گرفت.)"
    )
    try:
        if msg_id:
            bot.edit_message_text(chat_id=chat_id, message_id=msg_id, text=success_msg, parse_mode="HTML", reply_markup=main_keyboard(chat_id))
        else:
            bot.send_message(chat_id, success_msg, parse_mode="HTML", reply_markup=main_keyboard(chat_id))
    except Exception:
        bot.send_message(chat_id, success_msg, parse_mode="HTML", reply_markup=main_keyboard(chat_id))


PREMIUM_EMOJIS = {
    "👑": "5229011542011299168", "🔥": "5256047523620995497",
    "📝": "5334882760735598374", "✍️": "5334882760735598374", "✔️": "5206607081334906820", "✅": "5206607081334906820",
    "👍": "5465465194056525619", "🥰": "5465262274031659421", "👋": "5462910521739063094", "👎": "5465225015190367274",
    "😂": "5463121572137022242", "🤟": "5463412289883353404", "😴": "5462990652943904884", "💩": "5465198330558557107",
    "🤝": "5463256910851546817", "🗡": "5463277406435422003", "🛡": "5465154440287757794", "🌡": "5463054218459884779",
    "😵": "5463274047771000031", "👉": "5463392464314315076", "🤕": "5463156928307801722", "💊": "5463081281048818043",
    "🚫": "5463358164705489689", "⛔": "5463358164705489689", "⛔️": "5463358164705489689", "⚰️": "5463186335948878489", "🔝": "5463071033256848094", "⬆️": "5463122435425448565",
    "❓": "5463139580934892960", "👌": "5463423955014529788", "🔓": "5465443379917629504", "🪙": "5463046637842608206",
    "🤬": "5463335865235288297", "🛠": "5462921117423384478", "💀": "5463250708918711044",
    "💪": "5463413771647069835", "🎣": "5463406036410969564", "🙈": "5463345378587849154", "🖕": "5462957817918926146",
    "📦": "5463172695132745432", "🔮": "5463092727136661235", "😭": "5463137996091962323", "📀": "5462956611033117422",
    "🔇": "5462990730253319917", "🎂": "5454089058345042483", "⌛️": "5454415424319931791", "☝️": "5453958478454341679",
    "🧙‍♀️": "5454136337345037322", "👥": "5453957997418004470", "🍽": "5454246314277619140", "⚔️": "5454014806950429357",
    "👏": "5454092060527181056", "❌": "5210952531676504517", "🔋": "5454125707300978880", "✉️": "5454113432284446338",
    "🔫": "5454177848203951217", "😱": "5454182632797521992", "🎭": "5359441070201513074", "⚙️": "5341715473882955310",
    "🎬": "5375464961822695044", "🎯": "5463274047771000031", "💡": "5472146462362048818", "🔒": "5465443379917629504", "🚀": "5445284980978621387", "❗": "5274099962655816924",
    "↩️": "5255964497608217438", "🔗": "5271604874419647061", "👇": "5406745015365943482",
    # ── آیکن‌های رابط (اضافه‌شده) ──
    "🆔": "5226928895189598791", "🔘": "5307664681102510846", "🧾": "5444856076954520455",
    "📱": "5407025283456835913", "🖼": "5375074927252621134", "👤": "5373012449597335010",
    "💵": "5373174941095050893", "📸": "5370607250731718891", "✏️": "5395444784611480792",
    "📋": "5197269100878907942", "🔀": "5255713113172381884", "↪️": "5256144585586932056",
    "🗂": "5431736674147114227", "📢": "5388632425314140043", "📌": "5397782960512444700",
    "🛒": "5226656353744862682", "⚠️": "5447644880824181073", "😊": "5379561106492630835",
    "⏳": "5454415424319931791", "😀": "5366316836101038579", "🔁": "5226702984204797593",
    "💳": "5445353829304387411", "🗑": "5372825386591732174", "💎": "5427168083074628963",
    "✨": "5472164874886846699", "🎨": "5431456208487716895", "🔐": "5472308992514464048",
    "🔖": "5222444124698853913"
}

def parse_custom_emojis_only(raw_text: str) -> str:
    if not raw_text:
        return ""
    pattern = r"\[(\d+)\]"
    def replace_match(match):
        emoji_id = match.group(1)
        return f'<tg-emoji emoji-id="{emoji_id}">⭐</tg-emoji>'
    return re.sub(pattern, replace_match, raw_text)



# ==========================================================================
# رزرو اموجی شخصی: هر کاربر می‌تواند از پنل اصلی، اموجی‌های معمولی را به
# آی‌دی اموجی پرمیوم گره بزند (رزرو کند). از این پس هر جا همان اموجی معمولی
# را در حالت اینلاین ربات (@BotUsername متن) به‌کار ببرد، خودکار با اموجی پرمیوم
# انتخابی‌اش جایگزین می‌شود؛ بدون نیاز به نوشتنِ آی‌دی داخل [ ].
#
# ظرفیت پیش‌فرض هر کاربر ۱۰ اموجی است و با کوین قابل ارتقا تا سقف ۶۰ اموجی
# است (هر ارتقا ۵ عدد ظرفیت اضافه می‌کند)؛ هزینه‌ی هر ارتقا با ارتقاهای بعدی
# بیشتر می‌شود.
# ==========================================================================




def _get_user_emoji_data(user_id):
    return strong.emoji_data(user_id)




def get_user_emoji_reservations(user_id):
    """برمی‌گرداند {اموجی_معمولی: آیدی_پرمیوم} برای استفاده در جایگزینی خودکار متن."""
    if user_id is None:
        return {}
    return strong.emoji_mapping(user_id)


def get_user_emoji_capacity(user_id):
    return strong.get_settings(user_id)["emoji_capacity"]


def get_user_emoji_upgrade_cost(user_id):
    capacity = get_user_emoji_capacity(user_id)
    level = (capacity - DEFAULT_EMOJI_CAPACITY) // EMOJI_CAPACITY_UPGRADE_STEP
    return EMOJI_UPGRADE_BASE_COST + level * EMOJI_UPGRADE_COST_INCREMENT


def add_user_emoji_reservation(user_id, emoji_char, emoji_id, name=None, pack=None):
    return strong.emoji_add(user_id, emoji_char, emoji_id, name=name, pack=pack)


def update_user_emoji_reservation(user_id, slot_id, emoji_char=None, emoji_id=None, name=None):
    return strong.emoji_update(user_id, slot_id, char=emoji_char, emoji_id=emoji_id, name=name)


def delete_user_emoji_reservation(user_id, slot_id):
    strong.emoji_delete(user_id, slot_id)


def upgrade_user_emoji_capacity(user_id):
    """ارتقای ظرفیت (کسر کوین + افزایش ظرفیت تو یه تراکنش). خروجی (True, هزینه) یا (False, 'max'|هزینه)."""
    ok, info = strong.upgrade_capacity(user_id, get_user_emoji_upgrade_cost(user_id), EMOJI_CAPACITY_UPGRADE_STEP, MAX_EMOJI_CAPACITY)
    if ok:
        _maybe_low_balance_alert(user_id)
    return ok, info




def build_emoji_reservation_panel(user_id, page=0):
    user_data = _get_user_emoji_data(user_id)
    capacity = user_data.get("capacity", DEFAULT_EMOJI_CAPACITY)
    emojis = user_data.get("emojis", {})
    used = len(emojis)

    items = list(emojis.items())
    total_pages = max(1, math.ceil(len(items) / EMOJI_LIST_PAGE_SIZE))
    page = max(0, min(page, total_pages - 1))
    page_items = items[page * EMOJI_LIST_PAGE_SIZE: (page + 1) * EMOJI_LIST_PAGE_SIZE]

    markup = InlineKeyboardMarkup()
    if used < capacity:
        markup.add(InlineKeyboardButton(text="➕ افزودن اموجی جدید", callback_data="reserve_emoji_add_start", style="success", icon_custom_emoji_id="5465465194056525619"))

    for slot_id, entry in page_items:
        emoji_char = entry.get("emoji", "❓")
        emoji_id = entry.get("id", "")
        markup.add(InlineKeyboardButton(text=f"اموجی معمولی: {emoji_char}", callback_data=f"reserve_emoji_manage_{slot_id}", style="primary", icon_custom_emoji_id=emoji_id))

    if total_pages > 1:
        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton("◀️ صفحه قبل", callback_data=f"reserve_emoji_page_{page - 1}", style="primary", icon_custom_emoji_id="5253997076169115797"))
        if page < total_pages - 1:
            nav_buttons.append(InlineKeyboardButton("صفحه بعد ▶️", callback_data=f"reserve_emoji_page_{page + 1}", style="primary", icon_custom_emoji_id="5463392464314315076"))
        if nav_buttons:
            markup.row(*nav_buttons)

    if capacity < MAX_EMOJI_CAPACITY:
        cost = get_user_emoji_upgrade_cost(user_id)
        markup.add(InlineKeyboardButton(text=f"🔼 ارتقای ظرفیت (+{EMOJI_CAPACITY_UPGRADE_STEP} | {cost} کوین)", callback_data="reserve_emoji_upgrade", style="danger", icon_custom_emoji_id="5463046637842608206"))

    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    page_info = f"\nصفحه {page + 1} از {total_pages}" if total_pages > 1 else ""
    text = (
        f"<b>🗂 رزروهای اموجی من</b>\n\n"
        f"ظرفیت استفاده‌شده: <b>{used} از {capacity}</b>\n"
        f"حداکثر ظرفیت قابل‌ارتقا: {MAX_EMOJI_CAPACITY}{page_info}\n\n"
        f"روی هر اموجی بزنید تا مدیریتش کنید (تغییر/حذف) 👇"
    )
    return text, markup


def build_emoji_manage_panel(user_id, slot_id):
    entry = _get_user_emoji_data(user_id).get("emojis", {}).get(slot_id)
    if not entry:
        return None, None
    emoji_char = entry.get("emoji", "❓")
    emoji_id = entry.get("id", "")

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton(text="✏️ تغییر اموجی", callback_data=f"reserve_emoji_edit_char_{slot_id}", style="primary", icon_custom_emoji_id="5334882760735598374"))
    markup.add(InlineKeyboardButton(text="✏️ تغییر اموجی پرمیوم", callback_data=f"reserve_emoji_edit_id_{slot_id}", style="primary", icon_custom_emoji_id=emoji_id))
    markup.add(InlineKeyboardButton(text="🗑 حذف", callback_data=f"reserve_emoji_delete_{slot_id}", style="danger", icon_custom_emoji_id="5463358164705489689"))
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    text = f"<b>مدیریت رزرو</b>\n\nاموجی معمولی: {emoji_char}\nآی‌دی اموجی پرمیوم: <code>{emoji_id}</code>"
    return text, markup


_VS16 = "\ufe0f"
_TG_EMOJI_TAG_RE = r"<tg-emoji\b[^>]*>.*?</tg-emoji>"


def premium_emoji_id(char, user_id=None):
    """آیدی اموجی پرمیوم برای یه اموجی معمولی (با/بدون U+FE0F)؛ اگه نبود None."""
    key = (char or "").replace(_VS16, "")
    for k, v in {**PREMIUM_EMOJIS, **get_user_emoji_reservations(user_id)}.items():
        if k.replace(_VS16, "") == key:
            return v
    return None


def parse_custom_emojis_to_html(raw_text: str, user_id=None) -> str:
    if not raw_text:
        return ""
    formatted_text = parse_custom_emojis_only(raw_text)
    # کلیدها بدون U+FE0F نرمال می‌شن (✏ و ✏️ یکی حساب می‌شن)؛ رزروِ کاربر روی پیش‌فرض‌ها اولویت داره
    table = {}
    for k, v in {**PREMIUM_EMOJIS, **get_user_emoji_reservations(user_id)}.items():
        table[k.replace(_VS16, "")] = v
    if not table:
        return formatted_text
    alts = "|".join(re.escape(k) for k in sorted(table, key=len, reverse=True))
    pattern = re.compile(f"({_TG_EMOJI_TAG_RE})|((?:{alts}){_VS16}?)", re.S)

    def _sub(m):
        if m.group(1):                       # تگِ آماده: دست نمی‌زنیم (دوباره پیچیده نشه)
            return m.group(1)
        ch = m.group(2)
        return f'<tg-emoji emoji-id="{table[ch.replace(_VS16, "")]}">{ch}</tg-emoji>'

    return pattern.sub(_sub, formatted_text)

_ENTITY_TAG_MAP = {
    'bold': ('<b>', '</b>'),
    'italic': ('<i>', '</i>'),
    'underline': ('<u>', '</u>'),
    'strikethrough': ('<s>', '</s>'),
    'spoiler': ('<tg-spoiler>', '</tg-spoiler>'),
    'code': ('<code>', '</code>'),
    'pre': ('<pre>', '</pre>'),
    'blockquote': ('<blockquote>', '</blockquote>'),
    'expandable_blockquote': ('<blockquote expandable>', '</blockquote>'),
}


def entities_to_html(text, entities):
    """متن خام + entities واقعیِ تلگرام (بولد/ایتالیک/اسپویلر/بلاک‌کوت/لینک/
    اموجی‌سفارشی و...) رو به HTML معتبر برای parse_mode=HTML تبدیل می‌کنه.
    بر خلاف هر ویژگیِ احتمالاً ناقصِ فورک تله‌بات، مستقیم از روی entities
    استاندارد خودِ تلگرام کار می‌کنه که همیشه در دسترسن."""
    if not text:
        return ""
    if not entities:
        return html.escape(text)

    # آفست/طولِ entity های تلگرام بر مبنای واحد UTF-16 هستن، نه ایندکس پایتون
    utf16 = text.encode('utf-16-le')

    spans = []
    for ent in entities:
        etype = getattr(ent, 'type', None)
        start = ent.offset * 2
        end = (ent.offset + ent.length) * 2
        if etype in _ENTITY_TAG_MAP:
            open_tag, close_tag = _ENTITY_TAG_MAP[etype]
        elif etype == 'text_link':
            url = getattr(ent, 'url', '') or ''
            open_tag, close_tag = f'<a href="{html.escape(url, quote=True)}">', '</a>'
        elif etype == 'custom_emoji':
            cid = getattr(ent, 'custom_emoji_id', '')
            open_tag, close_tag = f'<tg-emoji emoji-id="{cid}">', '</tg-emoji>'
        else:
            continue
        spans.append((start, end, open_tag, close_tag))

    if not spans:
        return html.escape(text)

    cut_points = {0, len(utf16)}
    for s, e, _, _ in spans:
        cut_points.add(s)
        cut_points.add(e)
    cut_points = sorted(cut_points)

    out = []
    for i in range(len(cut_points) - 1):
        seg_start, seg_end = cut_points[i], cut_points[i + 1]
        if seg_start >= seg_end:
            continue
        seg_text = utf16[seg_start:seg_end].decode('utf-16-le')
        opens = [sp for sp in spans if sp[0] <= seg_start and sp[1] >= seg_end]
        opens.sort(key=lambda sp: (sp[0], -sp[1]))  # بیرونی‌ترین entity اول باز می‌شه
        prefix = ''.join(sp[2] for sp in opens)
        suffix = ''.join(sp[3] for sp in reversed(opens))
        out.append(prefix + html.escape(seg_text) + suffix)

    return ''.join(out)


def get_html_text_from_message(message):
    if not message:
        return ""
    entities = getattr(message, 'caption_entities', None) or getattr(message, 'entities', None)
    raw_text = message.caption if message.caption is not None else (message.text or "")
    if raw_text and entities:
        html_content = entities_to_html(raw_text, entities)
    elif raw_text:
        html_content = html.escape(raw_text)
    else:
        html_content = ""
    return parse_custom_emojis_only(html_content) if html_content else ""

# --- پشتیبانی از ارسال چند رسانه‌ای هم‌زمان (آلبوم) ---
# وقتی کاربر چند عکس/ویدیو/فایل را با هم (به‌صورت آلبوم) در تلگرام ارسال می‌کند،
# هرکدام به‌صورت یک پیام جداگانه ولی با media_group_id مشترک به ربات می‌رسد.
# تلگرام رویداد مشخصی برای «پایان آلبوم» نمی‌فرستد، پس هر پیام آلبوم را در یک
# بافر جمع می‌کنیم و کمی صبر می‌کنیم؛ اگر پیام تازه‌ای برای همان آلبوم نرسید،
# یعنی آلبوم کامل شده و آن را یک‌جا پردازش می‌کنیم.
media_group_buffer = {}
media_group_lock = threading.Lock()

def handle_incoming_media(message, on_ready):
    """
    اگر پیام بخشی از یک آلبوم باشد، آن را جمع‌آوری می‌کند و بعد از کوتاه مکثی
    on_ready را یک‌بار با لیست کامل پیام‌های آلبوم صدا می‌زند. برای پیام تکی
    (بدون آلبوم) بلافاصله on_ready با یک لیست تک‌عضوی صدا زده می‌شود.
    """
    group_id = getattr(message, "media_group_id", None)
    if not group_id:
        on_ready([message])
        return

    with media_group_lock:
        entry = media_group_buffer.setdefault(group_id, {"messages": []})
        entry["messages"].append(message)
        old_timer = entry.get("timer")
        if old_timer:
            old_timer.cancel()

        def fire():
            with media_group_lock:
                data = media_group_buffer.pop(group_id, None)
            if not data:
                return
            msgs = sorted(data["messages"], key=lambda m: m.message_id)
            on_ready(msgs)

        timer = threading.Timer(MEDIA_GROUP_WAIT_SECONDS, fire)
        timer.daemon = True
        entry["timer"] = timer
        timer.start()

def extract_media_info(message):
    """نوع و file_id یک پیام رسانه‌ای را استخراج می‌کند تا بدون نیاز به وجود خودِ
    پیام (که ممکن است بعداً حذف شود) بتوان دوباره همان رسانه را ارسال کرد."""
    content_type = message.content_type
    if content_type == 'photo':
        return {"type": "photo", "file_id": message.photo[-1].file_id}
    elif content_type == 'video':
        return {"type": "video", "file_id": message.video.file_id}
    elif content_type == 'document':
        return {"type": "document", "file_id": message.document.file_id}
    elif content_type == 'audio':
        return {"type": "audio", "file_id": message.audio.file_id}
    return None

_MEDIA_INPUT_CLASSES = {
    "photo": InputMediaPhoto,
    "video": InputMediaVideo,
    "document": InputMediaDocument,
    "audio": InputMediaAudio,
}

def build_input_media_from_info(media_info_list, caption_html=None):
    """از روی لیست {type, file_id} لیست InputMedia برای send_media_group می‌سازد.
    طبق محدودیت خود تلگرام، کپشن فقط روی اولین آیتم آلبوم قرار می‌گیرد."""
    media_list = []
    for idx, info in enumerate(media_info_list or []):
        cls = _MEDIA_INPUT_CLASSES.get(info.get("type"))
        if not cls:
            continue
        cap, parse_mode = (caption_html, "HTML") if (idx == 0 and caption_html) else (None, None)
        media_list.append(cls(info["file_id"], caption=cap, parse_mode=parse_mode))
    return media_list

def send_styled_message(chat_id, text, reply_markup=None, reply_to_message_id=None):
    formatted_text = parse_custom_emojis_to_html(text)
    try:
        return bot.send_message(chat_id, text=formatted_text, parse_mode="HTML", reply_markup=reply_markup, reply_to_message_id=reply_to_message_id)
    except Exception:
        return bot.send_message(chat_id, text=text, reply_markup=reply_markup, reply_to_message_id=reply_to_message_id)

def edit_or_send_message(chat_id, message_id, text, reply_markup=None):
    formatted_text = parse_custom_emojis_to_html(text)
    try:
        return bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=formatted_text, parse_mode="HTML", reply_markup=reply_markup)
    except Exception:
        return send_styled_message(chat_id, text, reply_markup=reply_markup)

def update_group_admins_list(group_id):
    try:
        admins = bot.get_chat_administrators(group_id)
        admin_ids = [admin.user.id for admin in admins if not admin.user.is_bot]
        group_admins[str(group_id)] = admin_ids
        save_json(group_admins, GROUP_ADMINS_FILE)
        return admin_ids
    except Exception as e:
        print(f"Error fetching admins for {group_id}: {e}")
        return group_admins.get(str(group_id), [])

def get_user_managed_groups(user_id):
    managed = []
    for g_id, admins in group_admins.items():
        if int(user_id) in [int(a) for a in admins]:
            try:
                chat_info = bot.get_chat(int(g_id))
                managed.append((str(g_id), chat_info.title))
            except Exception:
                managed.append((str(g_id), f"گروه {g_id}"))
    return managed

def update_channel_admins_list(channel_id):
    try:
        admins = bot.get_chat_administrators(channel_id)
        admin_ids = [admin.user.id for admin in admins if not admin.user.is_bot]
        channel_admins[str(channel_id)] = admin_ids
        save_json(channel_admins, CHANNEL_ADMINS_FILE)
        return admin_ids
    except Exception as e:
        print(f"Error fetching admins for channel {channel_id}: {e}")
        return channel_admins.get(str(channel_id), [])

def get_user_managed_channels(user_id):
    managed = []
    for c_id, admins in channel_admins.items():
        if int(user_id) in [int(a) for a in admins]:
            try:
                chat_info = bot.get_chat(int(c_id))
                managed.append((str(c_id), chat_info.title))
            except Exception:
                managed.append((str(c_id), f"کانال {c_id}"))
    return managed

def set_step(chat_id, step, message_id=None):
    if chat_id not in user_states:
        user_states[chat_id] = {"history": []}
    if "history" not in user_states[chat_id]:
        user_states[chat_id]["history"] = []
    user_states[chat_id]["step"] = step
    if message_id:
        user_states[chat_id]["last_bot_msg_id"] = message_id
    if not user_states[chat_id]["history"] or user_states[chat_id]["history"][-1] != step:
        user_states[chat_id]["history"].append(step)


def navigation_keyboard():
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )
    return markup

def yes_no_keyboard_with_nav():
    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("بله", callback_data="yes", style="success", icon_custom_emoji_id="5465465194056525619"), 
        InlineKeyboardButton("خیر", callback_data="no", style="danger", icon_custom_emoji_id="5465225015190367274")
    )
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )
    return markup

# ============================================================================
# پنل راهنما (/help) — کاملاً مستقل از پنل اصلی (main_keyboard). صفحه‌ی اولش
# («جدول» ۲ در ۲ - یعنی همان چیدمان چند دکمه در چند ردیف/ستون داخل یک
# InlineKeyboardMarkup) هیچ دکمه‌ی «بازگشت» ندارد چون خودش یک نقطه‌ی ورودی
# جداست، نه بخشی از پنل اصلی. هر بخش فقط یک دکمه‌ی «بازگشت» دارد که برمی‌گردد
# به همین صفحه‌ی اول راهنما (نه به پنل اصلی ربات).
# برای افزودن/تغییر بخش‌ها فقط کافی‌ست HELP_SECTIONS و help_root_keyboard را
# ویرایش کنی؛ توضیح کامل نحوه‌ی کار در پیام پاسخ آمده.
# ============================================================================
HELP_SECTIONS = {
    "1": {
        "body": (
            "💎 <b>نحوه‌ی استفاده از اموجی پرمیوم در متن</b>\n\n"
            "بعد از اینکه آی‌دی عددیِ یه اموجی پرمیوم رو گرفتی (بخش «آیدی اموجی/گروه/فرد» رو ببین)، سه‌جا می‌تونی ازش استفاده کنی:\n\n"
            "<b>۱) تست سریع تو پیوی ربات:</b>\n"
            "کافیه همینجا برای خودِ ربات بفرستی: <code>متن دلخواه [آیدی]</code> — بلافاصله همون پیام با اموجی پرمیوم برات فرستاده می‌شه.\n\n"
            "<b>۲) داخل «ارسال پیام به گروه»:</b>\n"
            "هر جای کپشن/متنی که برای گروه می‌نویسی، به همون فرمت <code>[آیدی]</code> اضافه کن؛ موقع ارسال به گروه، خودکار به اموجی پرمیوم تبدیل می‌شه.\n\n"
            "<b>۳) حالت اینلاین (تو هر چتی):</b>\n"
            "بنویس: <code>@" + BOT_USERNAME + " متن [آیدی]</code>؛ گزینه‌ی «فرستادن پیام» رو بزن و ارسال کن.\n\n"
            "🔁 اگه نمی‌خوای هر بار آیدی رو بنویسی، از قابلیت «رزرو کردن اموجی» تو منوی اصلی استفاده کن (توضیح کامل تو بخش «رزرو اموجی و ظرفیت»)."
        )
    },
    "2": {
        "body": (
            "🆔 <b>گرفتن آی‌دی اموجی و آی‌دی عددی</b>\n\n"
            "<b>آی‌دی یه اموجی پرمیوم:</b>\n"
            "همون اموجی پرمیوم رو داخل یه پیام متنی برای ربات @get_emojiid_bot بفرست، یا لینک پکِ اموجی/استیکر رو "
            "براش بفرست؛ آی‌دی عددیِ اموجی رو برات برمی‌گردونه. همون آی‌دی رو بعداً به‌صورت <code>[آیدی]</code> یا موقع رزرو اموجی استفاده کن.\n\n"
            "<b>آی‌دی عددیِ یه گروه:</b>\n"
            "ربات رو به گروه اضافه و ادمینش کن؛ گروه خودکار توی «لیست گروه‌های من» ثبت می‌شه و آی‌دیش همون‌جا قابل مشاهده‌ست. "
            "روش دیگه: یه پیام از اون گروه رو به یه ربات آی‌دی‌یاب مثل @username_to_id_bot فوروارد کن. (آی‌دی سوپرگروه‌ها معمولاً با <code>-100</code> شروع می‌شه.)\n\n"
            "<b>آی‌دی عددیِ یه شخص:</b>\n"
            "یه پیام از اون شخص رو به همون ربات آی‌دی‌یاب فوروارد کن؛ یا اگه یوزرنیم عمومی داره، مستقیم یوزرنیمش رو براش بفرست. "
            "(اگه حریم‌خصوصیِ فوروارد اون شخص بسته باشه، فقط از طریق یوزرنیم عمومی‌ش می‌شه آی‌دیش رو گرفت.)"
        )
    },
    "3": {
        "body": (
            "↩️ <b>نام فرستنده، اموجی کنار اسم و ریپلای</b>\n\n"
            "موقع «ارسال پیام به گروه»، بعد از تنظیم کپشن، ربات این سه سؤال رو به‌ترتیب می‌پرسه:\n\n"
            "۱) <b>آیا نامت به‌عنوان فرستنده زیر پیام درج بشه؟</b> (بله/خیر)\n"
            "۲) اگه «بله» بزنی، می‌تونی یه اموجی (حتی اموجی پرمیوم، با فرمت <code>[آیدی]</code>) برای نمایش کنار اسمت بفرستی؛ اگه نمی‌خوای فقط عدد <code>0</code> رو بفرست.\n"
            "۳) در آخر می‌پرسه <b>آیا می‌خوای پیامت روی یه پیام خاص تو گروه ریپلای بشه؟</b> اگه «بله» بزنی، کافیه لینک همون پیام رو بفرستی تا پیامت زیرش (به‌صورت ریپلای) ارسال بشه."
        )
    },
    "4": {
        "body": (
            "🗂 <b>رزرو اموجی و ظرفیت</b>\n\n"
            "از دکمه‌ی «رزرو کردن اموجی» تو منوی اصلی، می‌تونی یه اموجی معمولی (مثلاً 😀) رو به یه اموجی پرمیوم گره بزنی. "
            "از این پس تو حالت اینلاین، هر جا همون اموجی معمولی رو تو متنت بذاری، خودکار با اموجی پرمیومت جایگزین می‌شه — دیگه لازم نیست هر بار <code>[آیدی]</code> بنویسی.\n\n"
            f"ظرفیت پیش‌فرض هر کاربر {DEFAULT_EMOJI_CAPACITY} اموجیه و با کوین قابل ارتقاست، هر ارتقا +{EMOJI_CAPACITY_UPGRADE_STEP} ظرفیت تا سقف {MAX_EMOJI_CAPACITY} اموجی. "
            "هزینه‌ی هر ارتقا با ارتقاهای بعدی بیشتر می‌شه.\n\n"
            "از همون پنل می‌تونی رزروهات رو مدیریت کنی: تغییر اموجی، تغییر آی‌دی پرمیوم، یا حذفش."
        )
    },
    "5": {
        "body": (
            "✨ <b>فرمت‌بندی متن در حالت اینلاین</b>\n\n"
            "وقتی از @" + BOT_USERNAME + " به همراه متن دلخواه استفاده می‌کنی، می‌تونی متنت رو "
            "فرمت‌بندی کنی. ربات خودکار تشخیص می‌ده از کدوم روش استفاده کردی:\n\n"
            "<b>۱) نشانه‌های مارک‌داون:</b>\n"
            "• <code>*متن*</code> ← کلفت\n"
            "• <code>_متن_</code> ← ایتالیک\n"
            "• <code>`متن`</code> ← کد (قابل کپی)\n"
            "• <code>~متن~</code> ← خط رو\n\n"
            "<b>۲) تگ‌های HTML:</b>\n"
            "• <code>&lt;b&gt;متن&lt;/b&gt;</code> ← کلفت\n"
            "• <code>&lt;u&gt;متن&lt;/u&gt;</code> ← زیرخط\n"
            "• <code>&lt;s&gt;متن&lt;/s&gt;</code> ← خط رو\n"
            "• <code>&lt;code&gt;متن&lt;/code&gt;</code> ← کد (قابل کپی)\n"
            "• <code>&lt;a href=\"لینک\"&gt;متن&lt;/a&gt;</code> ← هایپرلینک\n\n"
            "⚠️ این دو روش رو با هم قاطی نکن؛ یا کامل از نشانه‌های مارک‌داون استفاده کن یا کامل از تگ‌های HTML، وگرنه پیام ارسال نمی‌شه."
        )
    },
    "6": {
        "body": (
            "🪙 <b>اموجی‌کوین و هزینه‌ها</b>\n\n"
            f"• ارسال پیام با اموجی پرمیوم در حالت اینلاین: {INLINE_SEND_COIN_COST} کوین\n"
            f"• ارتقای ظرفیت رزرو اموجی (هر بار +{EMOJI_CAPACITY_UPGRADE_STEP} ظرفیت): هر ارتقا {EMOJI_UPGRADE_BASE_COST} کوین (تا سقف ظرفیت {MAX_EMOJI_CAPACITY})\n\n"
            "برای افزایش موجودی کوین از دکمه‌ی «🛒 خرید اموجی کوین» تو منوی اصلی استفاده کن."
        )
    },
}

def help_root_keyboard():
    markup = InlineKeyboardMarkup()
    # هر دکمه یک متن خامِ مستقل و جدا دارد؛ هیچ‌کدام از دیکشنری مشترکی
    # خوانده نمی‌شوند تا تغییر متن یکی روی بقیه اثر نگذارد.
    markup.row(InlineKeyboardButton(text="استفاده از اموجی پرمیوم", callback_data="help_section_1", style="primary", icon_custom_emoji_id="5465465194056525619"), InlineKeyboardButton(text="آیدی اموجی/گروه/فرد", callback_data="help_section_2", style="primary", icon_custom_emoji_id="5229011542011299168"))
    markup.row(InlineKeyboardButton(text="نام فرستنده و ریپلای", callback_data="help_section_3", style="primary", icon_custom_emoji_id="5256047523620995497"), InlineKeyboardButton(text="رزرو اموجی و ظرفیت", callback_data="help_section_4", style="primary", icon_custom_emoji_id="5465443379917629504"))
    markup.row(InlineKeyboardButton(text="فرمت‌بندی متن اینلاین", callback_data="help_section_5", style="primary", icon_custom_emoji_id="5206607081334906820"), InlineKeyboardButton(text="اموجی‌کوین و هزینه‌ها", callback_data="help_section_6", style="primary", icon_custom_emoji_id="5472146462362048818"))
    return markup

def help_section_keyboard():
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("بازگشت به راهنما", callback_data="help_root", style="danger", icon_custom_emoji_id="5253997076169115797"))
    return markup

HELP_ROOT_CAPTION = "❓ **راهنما**\n\nیکی از بخش‌های زیر رو برای دیدن توضیحاتش انتخاب کن 👇"

def _help_root_rich_markdown():
    """
    متن صفحه‌ی اول راهنما را به‌صورت یک جدول واقعیِ ۵ ردیف × ۲ ستون (۱۰ واحد)
    با قابلیت Rich Messages (Bot API 10.1+، تیر ۱۴۰۵ / ژوئن ۲۰۲۶) می‌سازد.
    سینتکسش همان جدولِ مارک‌داونِ استاندارد (GFM) است: هر خط یک ردیف، سلول‌ها
    با | جدا می‌شوند و خط دوم (---) مرز هدر/بدنه‌ی جدول را مشخص می‌کند.

    ستون «امکانات» با سینتکس ![emoji](tg://emoji?id=...) پر شده که تلگرام آن
    را به‌صورت یک اموجی پرمیوم واقعی (نه اموجی معمولی) رندر می‌کند.

    عمداً هیچ متغیری اینجا خوانده نمی‌شود؛ هر سلول یک رشته‌ی خامِ مستقل است تا
    تغییر متن یک ردیف روی هیچ‌کجای دیگر اثر نگذارد. ردیف‌های جدول به همان
    ترتیب با دکمه‌های help_root_keyboard (۱ تا ۶) مطابقت دارند.
    """
    table = (
        "| توضیحات | امکانات |\n"
        "| --- | --- |\n"
        "| نحوه‌ی استفاده از اموجی پرمیوم در متن | ![👍](tg://emoji?id=5465465194056525619) استفاده از اموجی پرمیوم |\n"
        "| روش گرفتن آی‌دی اموجی/گروه/فرد | ![👑](tg://emoji?id=5229011542011299168) آیدی اموجی/گروه/فرد |\n"
        "| نام فرستنده، اموجی کنار اسم و ریپلای | ![🔥](tg://emoji?id=5256047523620995497) نام فرستنده و ریپلای |\n"
        "| رزرو اموجی برای حالت اینلاین و ارتقای ظرفیت | ![🔓](tg://emoji?id=5465443379917629504) رزرو اموجی و ظرفیت |\n"
        "| فرمت‌بندی متن در حالت اینلاین | ![✅](tg://emoji?id=5206607081334906820) فرمت‌بندی اینلاین |\n"
        "| هزینه‌ی اموجی‌کوین برای امکانات مختلف | ![💡](tg://emoji?id=5472146462362048818) اموجی‌کوین و هزینه‌ها |\n"
    )
    return f"{HELP_ROOT_CAPTION}\n\n{table}"

def _send_help_root_rich(chat_id):
    """
    تلاش برای فرستادن صفحه‌ی اول راهنما با یک جدول واقعیِ Rich Message از طریق
    متد خام sendRichMessage (چون کتابخانه‌ی telebot که این پروژه استفاده
    می‌کند هنوز این متدِ خیلی تازه را نمی‌شناسد). دکمه‌های واقعیِ قابل‌کلیک
    (reply_markup) همان InlineKeyboardMarkup همیشگی هستند تا صددرصد کار کنند؛
    جدول فقط برای نمایشِ چیدمانِ ۲×۲ به‌صورت یک جدول واقعی است.
    اگر این قابلیت روی سرور/نسخه‌ی فعلی در دسترس نباشد (یا فرمت دقیقش تغییر
    کرده باشد)، None برمی‌گرداند تا نسخه‌ی معمولیِ متن+دکمه جایگزینش شود.
    """
    try:
        res = requests.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendRichMessage",
            json={
                "chat_id": chat_id,
                "rich_message": {"markdown": _help_root_rich_markdown()},
                "reply_markup": help_root_keyboard().to_dict(),
            },
            timeout=8,
        )
        data = res.json()
        if data.get("ok"):
            return data["result"]["message_id"]
    except Exception as e:
        print(f"Rich Messages table not available (sendRichMessage) - falling back to plain /help: {e}")
    return None

def _edit_help_root_rich(chat_id, message_id):
    """نسخه‌ی edit همان جدول بالا (برگشت از یک بخش به صفحه‌ی اول راهنما)."""
    try:
        res = requests.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/editMessageText",
            json={
                "chat_id": chat_id,
                "message_id": message_id,
                "rich_message": {"markdown": _help_root_rich_markdown()},
                "reply_markup": help_root_keyboard().to_dict(),
            },
            timeout=8,
        )
        return bool(res.json().get("ok"))
    except Exception as e:
        print(f"Rich Messages table edit not available - falling back to plain /help: {e}")
        return False

def send_group_welcome_once(chat_id):
    if chat_id not in notified_groups:
        msg = (
            "درود 👋\n\n"
            "برای فعال‌سازی کامل امکانات ربات، لطفا دسترسی مدیریت (Admin) را در گروه فعال کنید 👑"
        )
        try:
            send_styled_message(chat_id, msg)
            notified_groups.add(chat_id)
            save_json(list(notified_groups), GROUPS_DATA_FILE)
        except Exception as e:
            print(f"Error sending welcome to group {chat_id}: {e}")
    
    update_group_admins_list(chat_id)

@bot.my_chat_member_handler()
def handle_bot_added_to_group(my_chat_member):
    chat_type = my_chat_member.chat.type
    new_status = my_chat_member.new_chat_member.status

    if chat_type in ['group', 'supergroup']:
        if new_status in ['member', 'administrator']:
            send_group_welcome_once(my_chat_member.chat.id)

    elif chat_type == 'channel':
        # برای کانال، ربات فقط وقتی به‌عنوان ادمین اضافه بشه می‌تونه پست
        # بفرسته/ویرایش کنه، پس فقط همون حالت رو پیگیری می‌کنیم
        if new_status == 'administrator':
            update_channel_admins_list(my_chat_member.chat.id)
        elif new_status in ['left', 'kicked']:
            channel_admins.pop(str(my_chat_member.chat.id), None)
            save_json(channel_admins, CHANNEL_ADMINS_FILE)

@bot.message_handler(content_types=['new_chat_members'])
def handle_new_chat_members(message):
    for member in message.new_chat_members:
        if member.id == bot.get_me().id:
            send_group_welcome_once(message.chat.id)

@bot.message_handler(commands=['start'])
def stop_or_start_chat(message):
    chat_id = message.chat.id
    if message.chat.type in ['group', 'supergroup']:
        update_group_admins_list(chat_id)
        return

    if _is_blocked(chat_id):
        return

    # اگه کاربر با کد پست (/start CODE یا لینک t.me/BOT?start=CODE) اومده باشه
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) > 1:
        code = parts[1].strip()
        post = get_saved_post(code)
        if post:
            user_states[chat_id] = {}
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton(text="📤 دریافت پست", callback_data=f"get_saved_post_{code}", style="success", icon_custom_emoji_id="5361840014084445540"))
            send_styled_message(chat_id, "پستی با این کد پیدا شد؛ برای دریافتش دکمه‌ی زیر رو بزن 👇", reply_markup=markup)
            return

    user_states[chat_id] = {}
    user_first_name = html.escape(message.from_user.first_name or ("دوست من" if i18n.get_lang(chat_id) == "fa" else "friend"))
    user_mention = f'<a href="tg://user?id={chat_id}">{user_first_name}</a>'

    welcome_text = _main_text(chat_id, message.from_user.first_name)
    sent_msg = send_styled_message(chat_id, welcome_text, reply_markup=main_keyboard(chat_id))
    if sent_msg:
        user_states[chat_id]["last_bot_msg_id"] = sent_msg.message_id

    # کاربر تازه‌وارد: آموزشِ کوتاه (فقط یک‌بار)
    try:
        if not strong.get_settings(chat_id)["onboarded"]:
            strong.set_setting(chat_id, onboarded=1)
            _v2_send_tutorial(chat_id, 0)
    except Exception as e:
        print(f"⚠️ tutorial: {e}")

@bot.message_handler(commands=['help'])
def help_command(message):
    chat_id = message.chat.id
    if message.chat.type in ['group', 'supergroup']:
        return

    if _is_blocked(chat_id):
        return

    if chat_id not in user_states:
        user_states[chat_id] = {}

    # اول با جدول واقعیِ Rich Message امتحان می‌کنیم؛ اگر در دسترس نبود
    # (نسخه‌ی سرور/کتابخانه هنوز پشتیبانی نمی‌کند)، همان حالت معمولی جایگزین می‌شود.
    rich_msg_id = _send_help_root_rich(chat_id)
    if rich_msg_id:
        user_states[chat_id]["last_bot_msg_id"] = rich_msg_id
        return

    help_text = "❓ <b>راهنما</b>\n\nیکی از بخش‌های زیر رو برای دیدن توضیحاتش انتخاب کن 👇"
    sent_msg = send_styled_message(chat_id, help_text, reply_markup=help_root_keyboard())
    if sent_msg:
        user_states[chat_id]["last_bot_msg_id"] = sent_msg.message_id

def build_numeric_keypad(entered_digits, title):
    """پنل کیبورد عددی (۰ تا ۹ + تایید/بک/حذف رقم) برای وارد کردن کدهای
    عددی (مثل کد تایید لاگین یوزربات) بدون نیاز به تایپ مستقیم."""
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("1", callback_data="otpkey_1"),
        InlineKeyboardButton("2", callback_data="otpkey_2"),
        InlineKeyboardButton("3", callback_data="otpkey_3"),
    )
    markup.row(
        InlineKeyboardButton("4", callback_data="otpkey_4"),
        InlineKeyboardButton("5", callback_data="otpkey_5"),
        InlineKeyboardButton("6", callback_data="otpkey_6"),
    )
    markup.row(
        InlineKeyboardButton("7", callback_data="otpkey_7"),
        InlineKeyboardButton("8", callback_data="otpkey_8"),
        InlineKeyboardButton("9", callback_data="otpkey_9"),
    )
    markup.row(
        InlineKeyboardButton("⌫ حذف رقم", callback_data="otpkey_del", style="danger"),
        InlineKeyboardButton("0", callback_data="otpkey_0"),
        InlineKeyboardButton("✅ تایید", callback_data="otpkey_confirm", style="success"),
    )
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )
    text = f"{title}\n\nکد وارد شده: <code>{entered_digits if entered_digits else '—'}</code>"
    return text, markup


@bot.callback_query_handler(func=lambda call: call.data == "help_root" or call.data.startswith("help_section_"))
def help_callback_handler(call):
    chat_id = call.message.chat.id
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    if chat_id not in user_states:
        user_states[chat_id] = {}

    user_states[chat_id]["last_bot_msg_id"] = call.message.message_id

    if call.data == "help_root":
        if _edit_help_root_rich(chat_id, call.message.message_id):
            return
        text = "❓ <b>راهنما</b>\n\nیکی از بخش‌های زیر رو برای دیدن توضیحاتش انتخاب کن 👇"
        markup = help_root_keyboard()
    else:
        section = HELP_SECTIONS.get(call.data.replace("help_section_", ""))
        if not section:
            if _edit_help_root_rich(chat_id, call.message.message_id):
                return
            text = "❓ <b>راهنما</b>\n\nیکی از بخش‌های زیر رو برای دیدن توضیحاتش انتخاب کن 👇"
            markup = help_root_keyboard()
        else:
            text = section['body']
            markup = help_section_keyboard()

    try:
        bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, text=parse_custom_emojis_to_html(text), parse_mode="HTML", reply_markup=markup)
    except Exception:
        send_styled_message(chat_id, text, reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "my_groups_list")
def show_my_groups(call):
    chat_id = call.message.chat.id
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    managed = get_user_managed_groups(chat_id)
    if not managed:
        edit_or_send_message(chat_id, call.message.message_id, "شما در حال حاضر ادمین هیچ گروه فعال ثبت‌شده‌ای نیستید ⛔", reply_markup=main_keyboard(chat_id))
        return

    markup = InlineKeyboardMarkup()
    for g_id, g_title in managed:
        markup.add(InlineKeyboardButton(text=f"{g_title}", callback_data=f"manage_group_{g_id}", style="success", icon_custom_emoji_id="5465443379917629504"))

    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )
    
    user_states[chat_id]["last_bot_msg_id"] = call.message.message_id
    bot.edit_message_text(
        chat_id=chat_id,
        message_id=call.message.message_id,
        text=parse_custom_emojis_to_html("<b>لیست گروه‌های تحت مدیریت شما 👥:</b>\n\nجهت تغییر تنظیمات، گروه مورد نظر را انتخاب کنید:"),
        parse_mode="HTML",
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith("manage_group_") or call.data.startswith("toggle_group_lock_"))
def handle_group_management(call):
    chat_id = call.message.chat.id
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    if call.data.startswith("manage_group_"):
        target_g_id = call.data.replace("manage_group_", "")
    else:
        target_g_id = call.data.replace("toggle_group_lock_", "")
        current = group_settings.get(target_g_id, "open")
        new_status = "closed" if current == "open" else "open"
        group_settings[target_g_id] = new_status
        save_json(group_settings, GROUP_SETTINGS_FILE)

    current_status = group_settings.get(target_g_id, "open")
    status_text = "آزاد ✅ (ارسال بدون نیاز به تایید)" if current_status == "open" else "قفل ⛔ (نیاز به تایید ادمین)"

    try:
        chat_info = bot.get_chat(int(target_g_id))
        g_title = chat_info.title
    except Exception:
        g_title = f"گروه {target_g_id}"

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton(text="تغییر وضعیت قفل", callback_data=f"toggle_group_lock_{target_g_id}", style="success", icon_custom_emoji_id="5465443379917629504"))
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="my_groups_list", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    msg = f"<b>پنل مدیریت گروه:</b> {g_title} 👑\n\nوضعیت پذیرش پیام: <b>{status_text}</b>"
    user_states[chat_id]["last_bot_msg_id"] = call.message.message_id
    bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, text=parse_custom_emojis_to_html(msg), parse_mode="HTML", reply_markup=markup)


# ==========================================================================
# مدیریت کانال — فقط و فقط ادمین‌های خودِ همان کانال به آن دسترسی دارند
# (ارسال پست جدید + ویرایش خودکار پست‌های قبلی با اموجی پرمیوم)
# ==========================================================================
@bot.callback_query_handler(func=lambda call: call.data == "my_channels_list")
def show_my_channels(call):
    chat_id = call.message.chat.id
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    managed = get_user_managed_channels(chat_id)
    if not managed:
        edit_or_send_message(chat_id, call.message.message_id, "شما در حال حاضر ادمین هیچ کانال فعال ثبت‌شده‌ای نیستید ⛔", reply_markup=main_keyboard(chat_id))
        return

    markup = InlineKeyboardMarkup()
    for c_id, c_title in managed:
        markup.add(InlineKeyboardButton(text=f"{c_title}", callback_data=f"manage_channel_{c_id}", style="success", icon_custom_emoji_id="5465443379917629504"))

    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    user_states[chat_id]["last_bot_msg_id"] = call.message.message_id
    bot.edit_message_text(
        chat_id=chat_id,
        message_id=call.message.message_id,
        text=parse_custom_emojis_to_html("<b>لیست کانال‌های تحت مدیریت شما 📢:</b>\n\nکانال مورد نظر را انتخاب کنید:"),
        parse_mode="HTML",
        reply_markup=markup
    )


def _is_channel_admin(user_id, channel_id):
    admins = channel_admins.get(str(channel_id), [])
    return int(user_id) in [int(a) for a in admins]


@bot.callback_query_handler(func=lambda call: call.data.startswith("manage_channel_"))
def handle_channel_management(call):
    chat_id = call.message.chat.id
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    target_c_id = call.data.replace("manage_channel_", "")

    if not _is_channel_admin(chat_id, target_c_id):
        bot.answer_callback_query(call.id, "شما ادمین این کانال نیستید ⛔", show_alert=True)
        return

    try:
        chat_info = bot.get_chat(int(target_c_id))
        c_title = chat_info.title
    except Exception:
        c_title = f"کانال {target_c_id}"

    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton(text="📮 ارسال پست به کانال", callback_data=f"channel_send_{target_c_id}", style="success", icon_custom_emoji_id="5454113432284446338"),
        InlineKeyboardButton(text="✏️ ویرایش پست کانال", callback_data=f"channel_edit_{target_c_id}", style="primary", icon_custom_emoji_id="5334882760735598374"),
    )
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="my_channels_list", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    msg = f"<b>پنل مدیریت کانال:</b> {c_title} 📢"
    user_states[chat_id]["last_bot_msg_id"] = call.message.message_id
    bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, text=parse_custom_emojis_to_html(msg), parse_mode="HTML", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("channel_send_"))
def handle_channel_send_start(call):
    chat_id = call.message.chat.id
    target_c_id = call.data.replace("channel_send_", "")
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    if not _is_channel_admin(chat_id, target_c_id):
        bot.answer_callback_query(call.id, "شما ادمین این کانال نیستید ⛔", show_alert=True)
        return

    user_states[chat_id] = {"mode": "CHANNEL_POST", "step": "WAITING_FOR_CHANNEL_CONTENT", "target_channel_id": target_c_id, "last_bot_msg_id": call.message.message_id}
    msg = "متن، عکس، ویدیو، گیف یا استیکر پست را ارسال کنید (آلبوم هم پشتیبانی می‌شود).\nبرای اموجی پرمیوم داخل متن، از [آیدی_اموجی] استفاده کنید ✉️:"
    edit_or_send_message(chat_id, call.message.message_id, msg, reply_markup=navigation_keyboard())


@bot.callback_query_handler(func=lambda call: call.data.startswith("channel_edit_"))
def handle_channel_edit_start(call):
    chat_id = call.message.chat.id
    target_c_id = call.data.replace("channel_edit_", "")
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    if not _is_channel_admin(chat_id, target_c_id):
        bot.answer_callback_query(call.id, "شما ادمین این کانال نیستید ⛔", show_alert=True)
        return

    user_states[chat_id] = {"mode": "CHANNEL_EDIT", "step": "WAITING_FOR_CHANNEL_POST_REF", "target_channel_id": target_c_id, "last_bot_msg_id": call.message.message_id}
    msg = "پست مورد نظر برای ویرایش را از همان کانال به اینجا فوروارد کنید، یا لینک آن را ارسال کنید 🔗:"
    edit_or_send_message(chat_id, call.message.message_id, msg, reply_markup=navigation_keyboard())

@bot.callback_query_handler(func=lambda call: call.data.startswith("approve_req_") or call.data.startswith("reject_req_"))
def handle_approval_action(call):
    admin_id = call.message.chat.id
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    is_approve = call.data.startswith("approve_req_")
    req_id = call.data.replace("approve_req_", "").replace("reject_req_", "")

    req_data = pending_requests.get(req_id)
    if not req_data:
        bot.edit_message_text(chat_id=admin_id, message_id=call.message.message_id, text=parse_custom_emojis_to_html("این درخواست قبلاً تعیین تکلیف شده است ⛔"))
        return

    admin_messages = req_data.get("admin_messages", {})

    # پست ذخیره‌شده (رزرو پست) که برای گروه قفل نیاز به تایید ادمین داره:
    # مسیر ساده‌تر و جدا از پایپ‌لاین copy_message/final_html معمولی، چون
    # پست از قبل کامل فرمت‌دهی شده و باید دست‌نخورده فرستاده بشه.
    if req_data.get("is_saved_post"):
        target_id = req_data["target_id"]
        sender_id = req_data["sender_id"]
        post_code = req_data.get("post_code")
        if is_approve:
            post = get_saved_post(post_code)
            if post:
                send_saved_post(target_id, post, private=False)
                send_styled_message(sender_id, "پست شما توسط ادمین تایید و به گروه ارسال شد ✅")
                status_note = "درخواست تایید و پست ارسال گردید ✅"
            else:
                status_note = "این پست دیگه در دسترس نیست ❌"
        else:
            send_styled_message(sender_id, "درخواست شما برای ارسال پست توسط ادمین رد شد ⛔")
            status_note = "درخواست ارسال رد گردید ⛔"

        for a_id_str, m_id in admin_messages.items():
            a_id = int(a_id_str)
            try:
                if a_id == admin_id:
                    bot.edit_message_text(chat_id=a_id, message_id=m_id, text=parse_custom_emojis_to_html(status_note), parse_mode="HTML")
                else:
                    bot.delete_message(chat_id=a_id, message_id=m_id)
            except Exception:
                pass

        pending_requests.pop(req_id, None)
        save_json(pending_requests, PENDING_REQUESTS_FILE)
        return

    target_id = req_data["target_id"]
    sender_id = req_data["sender_id"]
    from_chat_id = req_data["from_chat_id"]
    msg_id = req_data["msg_id"]
    final_html = req_data["final_html"]
    reply_to_msg_id = req_data.get("reply_to_msg_id")
    req_mode = req_data.get("mode")
    gif_id = req_data.get("gif_id")
    media_group_info = req_data.get("media_group_info")

    if is_approve:
        try:
            formatted_caption = parse_custom_emojis_to_html(final_html) if final_html else None

            # نکته: پیام اصلی کاربر ممکن است دیگر در چت او وجود نداشته باشد (مثلاً
            # گیف که بلافاصله بعد از دریافت حذف می‌شود)، پس برای این موارد
            # به‌جای copy_message (که وابسته به وجود پیام اصلی است و خطای
            # «message to copy not found» می‌دهد) از file_id ذخیره‌شده استفاده می‌کنیم.
            if req_mode == "GIF" and gif_id:
                bot.send_animation(target_id, animation=gif_id, caption=formatted_caption, parse_mode="HTML" if formatted_caption else None, reply_to_message_id=reply_to_msg_id)
            elif media_group_info:
                media_list = build_input_media_from_info(media_group_info, formatted_caption)
                if media_list:
                    bot.send_media_group(target_id, media_list)
            else:
                orig_msg = bot.get_message(from_chat_id, msg_id) if hasattr(bot, 'get_message') else None

                if formatted_caption and (not orig_msg or orig_msg.content_type == 'text'):
                    send_styled_message(target_id, final_html, reply_to_message_id=reply_to_msg_id)
                elif formatted_caption:
                    bot.copy_message(chat_id=target_id, from_chat_id=from_chat_id, message_id=msg_id, caption=formatted_caption, parse_mode="HTML", reply_to_message_id=reply_to_msg_id)
                else:
                    bot.copy_message(chat_id=target_id, from_chat_id=from_chat_id, message_id=msg_id, reply_to_message_id=reply_to_msg_id)
            
            send_styled_message(sender_id, "پیام شما توسط ادمین تایید و به گروه ارسال شد ✅")
            status_note = "درخواست تایید و پیام ارسال گردید ✅"
        except Exception as e:
            status_note = f"خطا در ارسال پیام ❌:\n<code>{e}</code>"
    else:
        send_styled_message(sender_id, "درخواست شما برای ارسال پیام توسط ادمین رد شد ⛔")
        status_note = "درخواست ارسال رد گردید ⛔"

    for a_id_str, m_id in admin_messages.items():
        a_id = int(a_id_str)
        try:
            if a_id == admin_id:
                bot.edit_message_text(chat_id=a_id, message_id=m_id, text=parse_custom_emojis_to_html(status_note), parse_mode="HTML")
            else:
                bot.delete_message(chat_id=a_id, message_id=m_id)
        except Exception:
            pass

    pending_requests.pop(req_id, None)
    save_json(pending_requests, PENDING_REQUESTS_FILE)

@bot.callback_query_handler(func=lambda call: call.data in ["profile_menu", "toggle_profile_status"])
def profile_callback_handler(call):
    chat_id = call.message.chat.id
    str_chat_id = str(chat_id)

    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    if str_chat_id not in user_profiles_status:
        user_profiles_status[str_chat_id] = "open"
        save_json(user_profiles_status, PROFILE_DATA_FILE)

    if call.data == "toggle_profile_status":
        current_status = user_profiles_status.get(str_chat_id, "open")
        new_status = "closed" if current_status == "open" else "open"
        user_profiles_status[str_chat_id] = new_status
        save_json(user_profiles_status, PROFILE_DATA_FILE)

    current_status = user_profiles_status.get(str_chat_id, "open")
    status_text = "فعال ✅ (دریافت پیام)" if current_status == "open" else "غیرفعال ⛔ (مسدود)"

    markup = InlineKeyboardMarkup()
    # نکته: دکمه‌ی «تغییر وضعیت دریافت پیام» (چت ناشناس/دوطرفه) فعلاً از UI
    # مخفی شده چون در حال حاضر چت دوطرفه‌ای وجود نداره؛ منطق و کالبک‌هندلرش
    # دست‌نخورده باقی مونده تا در آینده که این قابلیت دوباره لازم شد، فقط
    # کافیه همین یک خط زیر از کامنت دربیاد:
    # markup.add(InlineKeyboardButton(text="تغییر وضعیت دریافت پیام", callback_data="toggle_profile_status", style="success", icon_custom_emoji_id="5341715473882955310"))
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    profile_msg = (
        f"<b>تنظیمات حساب کاربری ⚙️:</b>\n\n"
        f"🪙 موجودی اموجی کوین: <b>{_get_coin_balance(chat_id)}</b>"
    )
    user_states[chat_id]["last_bot_msg_id"] = call.message.message_id
    try:
        bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, text=parse_custom_emojis_to_html(profile_msg), parse_mode="HTML", reply_markup=markup)
    except Exception:
        send_styled_message(chat_id, profile_msg, reply_markup=markup)


def process_final_message_sending(chat_id, state_data, target_id, reply_to_msg_id):
    msg_obj = state_data.get("media_message")
    custom_cap = state_data.get("custom_caption")
    show_sender = state_data.get("show_sender", False)
    sender_emoji = state_data.get("sender_emoji", "")
    mode = state_data.get("mode")
    gif_id = state_data.get("gif_id")
    media_group_info = state_data.get("media_group_info")  # چند رسانه‌ای هم‌زمان (آلبوم)

    final_html = custom_cap if custom_cap is not None else get_html_text_from_message(msg_obj)

    if show_sender:
        try:
            user_chat_obj = bot.get_chat(chat_id)
            sender_name = html.escape(user_chat_obj.first_name or "کاربر")
        except Exception:
            sender_name = "کاربر"
        sender_prefix = f"{sender_emoji} " if sender_emoji else ""
        signature = f'\n\n{sender_prefix}فرستنده: <a href="tg://user?id={chat_id}">{sender_name}</a>'
        if final_html:
            final_html += signature
        else:
            final_html = signature.strip()

    admins = update_group_admins_list(target_id)
    is_user_admin = chat_id in admins
    is_locked = group_settings.get(str(target_id), "open") == "closed"

    last_msg_id = state_data.get("last_bot_msg_id")

    if is_locked and not is_user_admin:
        if not admins:
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, "اطلاعات مدیران این گروه در سیستم ثبت نشده است ⛔", reply_markup=main_keyboard(chat_id))
            else:
                send_styled_message(chat_id, "اطلاعات مدیران این گروه در سیستم ثبت نشده است ⛔", reply_markup=main_keyboard(chat_id))
            user_states.pop(chat_id, None)
            return

        req_id = f"{chat_id}_{msg_obj.message_id}"
        pending_requests[req_id] = {
            "target_id": target_id,
            "sender_id": chat_id,
            "from_chat_id": chat_id,
            "msg_id": msg_obj.message_id,
            "final_html": final_html,
            "reply_to_msg_id": reply_to_msg_id,
            "admin_messages": {},
            "mode": mode,
            "gif_id": gif_id,
            "media_group_info": media_group_info,
        }

        approval_markup = InlineKeyboardMarkup()
        approval_markup.add(
            InlineKeyboardButton("تایید درخواست", callback_data=f"approve_req_{req_id}", style="success", icon_custom_emoji_id="5465465194056525619"),
            InlineKeyboardButton("رد درخواست", callback_data=f"reject_req_{req_id}", style="danger", icon_custom_emoji_id="5465225015190367274")
        )

        admin_preview_text = parse_custom_emojis_to_html(final_html) if final_html else '<i>[بدون متن]</i>'
        try:
            user_chat_obj = bot.get_chat(chat_id)
            sender_user_name = html.escape(user_chat_obj.first_name or "کاربر")
        except Exception:
            sender_user_name = "کاربر"

        admin_text = (
            f'<tg-emoji emoji-id="5454113432284446338">✉️</tg-emoji> <b>درخواست جدید ارسال پیام به گروه قفل 🔒</b>\n\n'
            f"<b>فرستنده:</b> <a href=\"tg://user?id={chat_id}\">{sender_user_name}</a>\n\n"
            f"<b>محتوای پیام:</b>\n{admin_preview_text}"
        )

        for a_id in admins:
            try:
                if mode == "GIF" and gif_id:
                    bot.send_animation(a_id, animation=gif_id)
                elif media_group_info:
                    preview_media = build_input_media_from_info(media_group_info)
                    if preview_media:
                        bot.send_media_group(a_id, preview_media)

                # توجه: admin_text از قبل (با admin_preview_text) کامل
                # پردازش شده؛ مستقیم و بدون فیلتر سراسری فرستاده می‌شه تا
                # پردازشِ دوباره (و در نتیجه خراب‌شدن/ناپدیدشدنِ اموجی و
                # فرمت‌بندی) اتفاق نیفته.
                try:
                    sent_admin_msg = bot.send_message(a_id, admin_text, parse_mode="HTML", reply_markup=approval_markup)
                except Exception:
                    sent_admin_msg = bot.send_message(a_id, admin_text, reply_markup=approval_markup)
                if sent_admin_msg:
                    pending_requests[req_id]["admin_messages"][str(a_id)] = sent_admin_msg.message_id
            except Exception as e:
                print(f"Skipping admin {a_id} because bot cannot message them: {e}")
                continue

        save_json(pending_requests, PENDING_REQUESTS_FILE)
        success_text = "گروه مقصد در حالت قفل قرار دارد 🔒 درخواست شما جهت بررسی برای مدیران ارسال گردید."
        if last_msg_id:
            edit_or_send_message(chat_id, last_msg_id, success_text, reply_markup=main_keyboard(chat_id))
        else:
            send_styled_message(chat_id, success_text, reply_markup=main_keyboard(chat_id))

    else:
        try:
            formatted_caption = parse_custom_emojis_to_html(final_html) if final_html else None
            # نکته: پیام گیف بلافاصله بعد از دریافت از چت کاربر حذف می‌شود، پس
            # اینجا دیگر از copy_message (که به وجود پیام اصلی نیاز دارد و خطای
            # «message to copy not found» می‌دهد) استفاده نمی‌کنیم و به‌جای آن مستقیماً
            # با file_id ذخیره‌شده ارسال می‌کنیم.
            if mode == "GIF" and gif_id:
                bot.send_animation(target_id, animation=gif_id, caption=formatted_caption, parse_mode="HTML" if formatted_caption else None, reply_to_message_id=reply_to_msg_id)
            elif media_group_info:
                # چند رسانه‌ای هم‌زمان (آلبوم): همه با هم به‌صورت یک آلبوم ارسال می‌شوند
                media_list = build_input_media_from_info(media_group_info, formatted_caption)
                if not media_list:
                    raise Exception("محتوای رسانه‌ای آلبوم نامعتبر است")
                bot.send_media_group(target_id, media_list)
            elif msg_obj.content_type == 'text':
                send_styled_message(target_id, final_html, reply_to_message_id=reply_to_msg_id)
            elif formatted_caption:
                bot.copy_message(chat_id=target_id, from_chat_id=chat_id, message_id=msg_obj.message_id, caption=formatted_caption, parse_mode="HTML", reply_to_message_id=reply_to_msg_id)
            else:
                bot.copy_message(chat_id=target_id, from_chat_id=chat_id, message_id=msg_obj.message_id, reply_to_message_id=reply_to_msg_id)

            success_text = "پیام شما با موفقیت به گروه مقصد ارسال شد ✅"
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, success_text, reply_markup=main_keyboard(chat_id))
            else:
                send_styled_message(chat_id, success_text, reply_markup=main_keyboard(chat_id))
        except Exception as e:
            err_text = f"خطا در ارسال پیام ❌:\n<code>{e}</code>"
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, err_text, reply_markup=main_keyboard(chat_id))
            else:
                send_styled_message(chat_id, err_text, reply_markup=main_keyboard(chat_id))

    user_states.pop(chat_id, None)

# ==========================================================================
# تایید/رد فاکتورهای خرید کوین (کیف‌پول مینی‌اپ)
# ==========================================================================

# باید دقیقاً با همین مقادیر داخل bot_config.py یکی باشند

_WALLET_ADDRESS_CHARS = string.ascii_lowercase + string.ascii_uppercase + string.digits








# ==========================================================================
# پنل ادمین (فقط برای SUPER_ADMIN_ID): جستجوی کاربر با آیدی عددی و
# مدیریت موجودی اموجی کوین و وضعیت بلاک او.
# ==========================================================================


def _build_admin_user_panel(target_id):
    target_id = int(target_id)
    try:
        chat_info = bot.get_chat(target_id)
        first_name = html.escape(chat_info.first_name or "-")
        last_name = html.escape(chat_info.last_name or "-")
        username = f"@{chat_info.username}" if chat_info.username else "-"
    except Exception:
        first_name = "نامشخص (ربات هنوز این کاربر رو ندیده)"
        last_name = "-"
        username = "-"

    balance = _get_coin_balance(target_id)
    is_blocked_now = _is_blocked(target_id)
    block_status_text = "🚫 مسدود شده" if is_blocked_now else "✅ آزاد"

    info_text = (
        f"👤 <b>اطلاعات کاربر</b>\n\n"
        f"نام: {first_name}\n"
        f"نام خانوادگی: {last_name}\n"
        f"یوزرنیم: {username}\n"
        f"آیدی عددی: <code>{target_id}</code>\n"
        f"🪙 موجودی اموجی کوین: <b>{balance}</b>\n"
        f"وضعیت: <b>{block_status_text}</b>"
    )

    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("➕ افزودن کوین", callback_data=f"admin_addcoin_{target_id}", style="success", icon_custom_emoji_id="5465465194056525619"),
        InlineKeyboardButton("➖ کم کردن کوین", callback_data=f"admin_subcoin_{target_id}", style="danger", icon_custom_emoji_id="5465225015190367274"),
    )
    block_btn_text = "✅ آنبلاک کاربر" if is_blocked_now else "🚫 بلاک از ربات"
    markup.add(InlineKeyboardButton(block_btn_text, callback_data=f"admin_toggleblock_{target_id}", style="danger", icon_custom_emoji_id="5463358164705489689"))
    markup.add(InlineKeyboardButton("🔎 بررسی کاربر دیگر", callback_data="admin_panel_open", style="primary", icon_custom_emoji_id="5463139580934892960"))
    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )
    return info_text, markup


@bot.callback_query_handler(func=lambda call: call.data == "admin_panel_open")
def admin_panel_open_callback(call):
    chat_id = call.message.chat.id
    if chat_id != SUPER_ADMIN_ID:
        try:
            bot.answer_callback_query(call.id, "⛔ دسترسی ندارید.", show_alert=True)
        except Exception:
            pass
        return
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass
    user_states[chat_id] = {"mode": "ADMIN_PANEL", "step": "WAITING_FOR_USER_ID", "last_bot_msg_id": call.message.message_id}
    edit_or_send_message(chat_id, call.message.message_id, "🛠 آیدی عددی کاربر مورد نظر را ارسال کنید:", reply_markup=navigation_keyboard())


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_addcoin_") or call.data.startswith("admin_subcoin_") or call.data.startswith("admin_toggleblock_"))
def admin_panel_action_callback(call):
    chat_id = call.message.chat.id
    if chat_id != SUPER_ADMIN_ID:
        try:
            bot.answer_callback_query(call.id, "⛔ دسترسی ندارید.", show_alert=True)
        except Exception:
            pass
        return

    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    if call.data.startswith("admin_addcoin_"):
        target_id = int(call.data.replace("admin_addcoin_", ""))
        user_states[chat_id] = {"mode": "ADMIN_PANEL", "step": "WAITING_FOR_COIN_ADD_AMOUNT", "target_id": target_id, "last_bot_msg_id": call.message.message_id}
        edit_or_send_message(chat_id, call.message.message_id, f"چند اموجی کوین به کاربر <code>{target_id}</code> اضافه شود؟ عدد را ارسال کنید:", reply_markup=navigation_keyboard())
        return

    if call.data.startswith("admin_subcoin_"):
        target_id = int(call.data.replace("admin_subcoin_", ""))
        user_states[chat_id] = {"mode": "ADMIN_PANEL", "step": "WAITING_FOR_COIN_SUB_AMOUNT", "target_id": target_id, "last_bot_msg_id": call.message.message_id}
        edit_or_send_message(chat_id, call.message.message_id, f"چند اموجی کوین از کاربر <code>{target_id}</code> کم شود؟ عدد را ارسال کنید:", reply_markup=navigation_keyboard())
        return

    if call.data.startswith("admin_toggleblock_"):
        target_id = int(call.data.replace("admin_toggleblock_", ""))
        _set_blocked(target_id, not _is_blocked(target_id))
        info_text, markup = _build_admin_user_panel(target_id)
        user_states[chat_id] = {"mode": "ADMIN_PANEL", "step": "VIEWING_USER", "target_id": target_id, "last_bot_msg_id": call.message.message_id}
        edit_or_send_message(chat_id, call.message.message_id, parse_custom_emojis_to_html(info_text), reply_markup=markup)
        return


INVOICE_STATUS_LABELS_FA = {
    "awaiting_receipt": "در انتظار رسید",
    "submitted": "در حال بررسی",
    "approved": "تایید شده ✅",
    "rejected": "رد شده ❌",
    "cancelled": "لغو شده",
}


@bot.callback_query_handler(func=lambda call: call.data == "my_invoices_menu")
def handle_my_invoices_menu(call):
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    chat_id = call.message.chat.id
    user_id = str(call.from_user.id)
    invoices = {i["id"]: i for i in strong.list_invoices(user_id)}
    my_invoices = [
        inv for inv in invoices.values()
        if str(inv.get("user_id")) == user_id and inv.get("status") == "awaiting_receipt"
    ]
    my_invoices.sort(key=lambda inv: inv.get("created_at", 0), reverse=True)

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton(text="🛒 خرید اموجی کوین", callback_data="buy_coin_start", style="success", icon_custom_emoji_id="5397916757333654639"))

    if not my_invoices:
        text = "🧾 فاکتور در انتظار رسیدی ندارید."
    else:
        text = "🧾 فاکتورهای در انتظار رسید — برای دیدن جزییات و مدیریت هر فاکتور، رویش بزنید:"
        for inv in my_invoices[:10]:
            status_fa = INVOICE_STATUS_LABELS_FA.get(inv.get("status"), inv.get("status"))
            markup.add(InlineKeyboardButton(
                text=f"#{inv.get('id')} — {inv.get('coin_amount')} اموجی کوین — {status_fa}",
                callback_data=f"inv_detail_{inv.get('id')}",
                style="primary",
                icon_custom_emoji_id="5444856076954520455",
            ))

    markup.row(
        InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("inv_detail_"))
def handle_invoice_detail(call):
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    chat_id = call.message.chat.id
    invoice_id = call.data.replace("inv_detail_", "")
    user_id = str(call.from_user.id)
    invoice = strong.get_invoice(invoice_id)

    if not invoice or str(invoice.get("user_id")) != user_id:
        bot.answer_callback_query(call.id, "این فاکتور یافت نشد ⛔", show_alert=True)
        return

    status_fa = INVOICE_STATUS_LABELS_FA.get(invoice.get("status"), invoice.get("status"))
    text = (
        f"🧾 فاکتور #{invoice_id}\n\n"
        f"🪙 مقدار: {invoice.get('coin_amount')} اموجی کوین\n"
        f"💵 مبلغ قابل پرداخت: {invoice.get('toman_amount'):,} تومان\n"
        f"📌 وضعیت: {status_fa}"
    )
    if invoice.get("discount_code"):
        text = text.replace("📌 وضعیت:", f"🎟 تخفیف ({invoice['discount_code']}): -{int(invoice.get('discount_toman') or 0):,} تومان\n📌 وضعیت:")

    markup = InlineKeyboardMarkup()
    if invoice.get("status") == "awaiting_receipt":
        markup.add(InlineKeyboardButton(
            text="📤 ارسال رسید",
            callback_data=f"inv_send_receipt_{invoice_id}",
            style="success",
            icon_custom_emoji_id="5444856076954520455",
        ))
    if invoice.get("status") in ("awaiting_receipt", "submitted"):
        markup.add(InlineKeyboardButton(
            text="❌ لغو فاکتور",
            callback_data=f"inv_self_cancel_{invoice_id}",
            style="danger",
            icon_custom_emoji_id="5210952531676504517",
        ))
    markup.row(
        InlineKeyboardButton("🔙 فاکتورهای من", callback_data="my_invoices_menu", style="primary", icon_custom_emoji_id="5253997076169115797"),
        InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
    )

    edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("inv_send_receipt_"))
def handle_invoice_send_receipt(call):
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    chat_id = call.message.chat.id
    invoice_id = call.data.replace("inv_send_receipt_", "")
    user_id = str(call.from_user.id)
    invoice = strong.get_invoice(invoice_id)

    if not invoice or str(invoice.get("user_id")) != user_id:
        bot.answer_callback_query(call.id, "این فاکتور یافت نشد ⛔", show_alert=True)
        return

    if invoice.get("status") != "awaiting_receipt":
        bot.answer_callback_query(call.id, "این فاکتور در انتظار رسید نیست ⛔", show_alert=True)
        return

    user_states[chat_id] = {"mode": "BUY_COIN", "step": "WAITING_FOR_RECEIPT", "invoice_id": invoice_id, "last_bot_msg_id": call.message.message_id}
    edit_or_send_message(chat_id, call.message.message_id, "لطفاً تصویر رسید پرداخت این فاکتور را همین‌جا (به‌صورت عکس) ارسال کنید 📸", reply_markup=navigation_keyboard())


@bot.callback_query_handler(func=lambda call: call.data.startswith("inv_self_cancel_"))
def handle_invoice_self_cancel(call):
    invoice_id = call.data.replace("inv_self_cancel_", "")
    user_id = str(call.from_user.id)
    invoice = strong.get_invoice(invoice_id)

    if not invoice or str(invoice.get("user_id")) != user_id:
        bot.answer_callback_query(call.id, "این فاکتور یافت نشد ⛔", show_alert=True)
        return

    if invoice.get("status") not in ("awaiting_receipt", "submitted"):
        bot.answer_callback_query(call.id, "این فاکتور دیگر قابل لغو نیست ⛔", show_alert=True)
        return

    was_submitted = invoice.get("status") == "submitted"
    invoice["status"] = "cancelled"
    strong.save_invoice(invoice)
    strong.discount_release(invoice_id)

    try:
        bot.answer_callback_query(call.id, "فاکتور لغو شد ✅")
    except Exception:
        pass

    if was_submitted:
        try:
            send_styled_message(INVOICE_APPROVER_ID, f"⚠️ فاکتور #{invoice_id} توسط خریدار لغو شد و دیگر نیازی به بررسی ندارد.")
        except Exception:
            pass

    # همون منو رو با وضعیت به‌روزشده دوباره نشون بده
    handle_my_invoices_menu(call)


@bot.callback_query_handler(func=lambda call: call.data.startswith("inv_approve_") or call.data.startswith("inv_reject_"))
def handle_invoice_decision(call):
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    is_approve = call.data.startswith("inv_approve_")
    invoice_id = call.data.replace("inv_approve_", "") if is_approve else call.data.replace("inv_reject_", "")

    invoice = strong.get_invoice(invoice_id)

    if not invoice:
        bot.answer_callback_query(call.id, "این فاکتور دیگر وجود ندارد ⛔", show_alert=True)
        return

    if invoice.get("status") in ("approved", "rejected"):
        bot.answer_callback_query(call.id, "این فاکتور قبلاً پردازش شده است ⛔", show_alert=True)
        return

    buyer_id = invoice.get("user_id")

    if is_approve:
        approved_inv, err = strong.approve_invoice(invoice_id)
        if err:
            bot.answer_callback_query(call.id, "این فاکتور قبلاً پردازش شده است ⛔", show_alert=True)
            return
        invoice = approved_inv

        result_caption = "✅ این فاکتور تایید و اموجی کوین برای خریدار واریز شد."
        buyer_text = f"خرید شما تایید شد ✅\n🪙 مقدار {invoice.get('coin_amount')} اموجی کوین به کیف‌پول شما واریز گردید."
    else:
        invoice["status"] = "rejected"
        strong.save_invoice(invoice)
        strong.discount_release(invoice_id)

        result_caption = "❌ این فاکتور حذف شد."
        buyer_text = "متاسفانه فاکتور شما لغو شد ❌"

    try:
        send_styled_message(buyer_id, buyer_text)
    except Exception as e:
        print(f"⚠️ خطا در اطلاع‌رسانی به خریدار: {e}")

    # حذف دکمه‌های تایید/حذف از پیام ادمین تا دوباره قابل کلیک نباشند، و
    # نمایش نتیجه در کپشن همان پیام (که شامل عکس رسید است)
    contact_button = InlineKeyboardMarkup()
    contact_button.add(InlineKeyboardButton(text="💬 ارتباط با خریدار", url=f"tg://user?id={buyer_id}"))
    try:
        new_caption = parse_custom_emojis_to_html(f"{call.message.caption}\n\n{result_caption}")
        bot.edit_message_caption(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            caption=new_caption,
            parse_mode="HTML",
            reply_markup=contact_button,
        )
    except Exception as e:
        print(f"⚠️ خطا در ویرایش پیام فاکتور: {e}")


_self_notify_last = {}  # user_id -> زمانِ آخرین پیامِ هشدار (برای جلوگیری از اسپم)


def _notify_self_user(user_id, text):
    """هشدارِ خصوصی (حداکثر دقیقه‌ای یکی) وقتی اعمالِ پیامِ سلف نشد، تا خطا بی‌صدا نمونه."""
    now = time_module.time()
    if now - _self_notify_last.get(user_id, 0) < 60:
        return
    _self_notify_last[user_id] = now
    try:
        bot.send_message(user_id, text)
    except Exception:
        pass


def _edit_inline_with_post(inline_message_id, post):
    """متنِ کامل (اموجی پرمیوم، فرمت‌ها) و دکمه‌های پست رو جایگزینِ نسخه‌ی ساده‌ی
    پیامِ اینلاین می‌کنه. reply_markup رو صریحاً پاس می‌دیم؛ وگرنه تلگرام موقعِ
    ادیت کیبورد رو پاک می‌کنه (و اینجا دکمه‌ی «فعال‌سازی» هم باید پاک بشه).
    خروجی: (موفق؟، متنِ خطا)."""
    full_text = sanitize_html_for_telegram(post.get("text") or "")
    buttons = post.get("buttons") or []
    is_media = bool(post.get("media"))
    last_error = ""
    for builder in (build_post_markup, build_plain_post_markup):
        try:
            if is_media:
                bot.edit_message_caption(
                    inline_message_id=inline_message_id,
                    caption=full_text or None,
                    parse_mode="HTML",
                    reply_markup=builder(buttons),
                )
            else:
                bot.edit_message_text(
                    inline_message_id=inline_message_id,
                    text=full_text or " ",
                    parse_mode="HTML",
                    reply_markup=builder(buttons),
                )
            return True, ""
        except Exception as e:
            if "message is not modified" in str(e).lower():
                return True, ""
            last_error = str(e)
            print(f"❌ [apply_self_relay] خطا در ویرایش با {builder.__name__}: {e}")
            if not buttons:
                break  # بدون دکمه، تلاشِ دوباره با مارکاپِ ساده فرقی نمی‌کنه
    return False, last_error


def _apply_self_relay(token, inline_message_id):
    """تنها نقطه‌ی اعمالِ پستِ موقتِ سلف — هم از دکمه (callback) و هم از
    chosen_inline_result صدا زده می‌شه؛ قفلِ هر پست تضمین می‌کنه یه پیام
    فقط یک‌بار ادیت و یک‌بار حساب بشه، هر کدوم از مسیرها زودتر برسه.
    خروجی: "applied" | "no_coins" | "error" | "missing"."""
    entry = _self_relay_cache.get(token)
    if entry is None:
        return "missing"
    with entry["lock"]:
        if entry["status"] == "applied":
            return "applied"
        user_id = entry["user_id"]
        charged = False
        if entry["charge"]:
            if not _charge_coins(user_id, INLINE_SEND_COIN_COST):
                entry["status"] = "no_coins"
                _notify_self_user(
                    user_id,
                    f"موجودی اموجی کوین کافی نیست ⛔️ برای فرستادنِ هر پیام با اموجی پرمیوم {INLINE_SEND_COIN_COST} کوین لازمه؛ "
                    "این پیام با اموجی معمولی ارسال شد.",
                )
                return "no_coins"
            charged = True
        ok, err = _edit_inline_with_post(inline_message_id, entry["post"])
        if ok:
            entry["status"] = "applied"
            return "applied"
        if charged:
            _refund_coins(user_id, INLINE_SEND_COIN_COST)
        entry["status"] = "error"
        _notify_self_user(
            user_id,
            "❌ اعمالِ اموجی پرمیوم روی پیام انجام نشد (احتمالاً یکی از آی‌دی‌های اموجی نامعتبره).\n\n"
            f"خطا: {err[:300]}",
        )
        return "error"


def _handle_self_relay_callback(call, token):
    entry = _self_relay_cache.get(token)
    if entry is not None and call.from_user.id != entry["user_id"]:
        # دکمه فقط برای خودِ سلف‌ـه؛ بقیه‌ی اعضای چت نباید بتونن بزننش
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        return
    status = _apply_self_relay(token, call.inline_message_id)
    try:
        if status == "applied":
            bot.answer_callback_query(call.id)
        elif status == "no_coins":
            bot.answer_callback_query(
                call.id,
                f"موجودی اموجی کوین کافی نیست ⛔️ برای این کار {INLINE_SEND_COIN_COST} کوین نیاز داری.",
                show_alert=True,
            )
        elif status == "missing":
            bot.answer_callback_query(call.id, "این پیام قدیمیه یا ربات ری‌استارت شده ⛔️ یه بار دیگه بفرست.", show_alert=True)
        else:
            bot.answer_callback_query(call.id, "خطا در اعمال اموجی پرمیوم ❌", show_alert=True)
    except Exception:
        pass


@bot.callback_query_handler(func=lambda call: call.data.startswith("apply_emoji_"))
def handle_apply_emoji_callback(call):
    """دکمه‌ی روی پیامِ اینلاین‌فرستاده‌شده — همیشه و بدون نیاز به تنظیم
    /setinlinefeedback کار می‌کنه، چون callback_query یه رویداد استاندارده."""
    short_id = call.data.replace("apply_emoji_", "", 1)

    # پستِ موقتِ سلف: کلِ منطق تو _apply_self_relay ـه
    if short_id.startswith(SELF_RELAY_PREFIX):
        _handle_self_relay_callback(call, short_id)
        return

    cache_entry = _inline_emoji_cache.get(short_id)

    if not cache_entry:
        try:
            bot.answer_callback_query(call.id, "این پیام قدیمیه یا ربات ری‌استارت شده ⛔️ یه بار دیگه از inline بفرست.", show_alert=True)
        except Exception:
            pass
        return

    final_text = cache_entry["final_text"]
    original_sender_id = cache_entry["user_id"]
    cached_parse_mode = cache_entry.get("parse_mode", "HTML")

    already_charged = call.inline_message_id in _charged_inline_messages
    if not already_charged:
        if not _charge_coins(original_sender_id, INLINE_SEND_COIN_COST):
            try:
                bot.answer_callback_query(
                    call.id,
                    f"موجودی اموجی کوین کافی نیست ⛔️ برای این کار {INLINE_SEND_COIN_COST} کوین نیاز داری.",
                    show_alert=True,
                )
            except Exception:
                pass
            return
        _charged_inline_messages.add(call.inline_message_id)

    _inline_emoji_cache.pop(short_id, None)

    try:
        bot.edit_message_text(
            inline_message_id=call.inline_message_id,
            text=final_text,
            parse_mode=cached_parse_mode,
        )
        bot.answer_callback_query(call.id, "اموجی پرمیوم اعمال شد ✅")
    except Exception as e:
        print(f"❌ [apply_emoji_callback] خطا در ویرایش: {e}")
        try:
            bot.answer_callback_query(call.id, "خطا در اعمال اموجی پرمیوم ❌", show_alert=True)
        except Exception:
            pass


# ==========================================================================
# قابلیت‌های نسخه‌ی ۲: پست‌های من، زمان‌بندی و ارسال چندمقصده، کیف پول (تاریخچه/پاداش/هدیه/انتقال/هشدار)،
# رزروهای اموجی با اسم و جستجو و رزروِ تک‌پیامی، پنل سلف، داشبورد ادمین، آموزش و دوزبانگی.
# همه‌ی callbackها با پیشوند «v2:» ـن و باید قبل از callback_listener (که همه‌چیز رو می‌گیره) ثبت بشن.
# ==========================================================================
import datetime as _dt
from zoneinfo import ZoneInfo as _ZoneInfo

import i18n
import self as self_module
from i18n import t as tr

_TG_EMOJI_PACK_RE = re.compile(r"(?:https?://)?t\.me/(?:addemoji|addstickers)/([A-Za-z0-9_]+)")
_SPARK = "▁▂▃▄▅▆▇█"


# ── ابزارهای کوچک ───────────────────────────────────────────────────────
def _ic(char):
    try:
        return premium_emoji_id(char)
    except Exception:
        return None


def _B(text, data=None, style=None, icon=None, url=None, raw=False, web_app=None):
    """دکمه‌ی کمکی. متنِ انگلیسیِ دکمه با فونت ᴇᴍᴏᴊɪ؛ raw=True برای متنِ پویا/کاربری (اسم پست، اسم اموجی، عنوان گروه)."""
    kw = {"text": text if raw else i18n.sc_plain(text)}
    if web_app:
        kw["web_app"] = WebAppInfo(url=web_app)
    elif url:
        kw["url"] = url
    else:
        kw["callback_data"] = data
    if style:
        kw["style"] = style
    icon_id = _ic(icon) if icon and not str(icon).isdigit() else icon
    if icon_id:
        kw["icon_custom_emoji_id"] = icon_id
    return InlineKeyboardButton(**kw)


def _kb(*rows):
    markup = InlineKeyboardMarkup()
    for row in rows:
        row = [b for b in row if b is not None]
        if row:
            markup.row(*row)
    return markup


def _nav(uid, back=None):
    row = []
    if back:
        row.append(_B(tr(uid, "back"), back, "danger", "↪️"))
    row.append(_B(tr(uid, "main_menu"), "nav_all_back", "danger", "🔀"))
    return row


def _ans(call, text=None, alert=False):
    try:
        bot.answer_callback_query(call.id, text, show_alert=alert)
    except Exception:
        pass


def _show(call, text, markup=None):
    return edit_or_send_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)


def _reset_state(chat_id, keep=()):
    old = user_states.get(chat_id) or {}
    new = {"history": []}
    for k in keep:
        if k in old:
            new[k] = old[k]
    user_states[chat_id] = new
    return new


def _set_v2_step(chat_id, step, msg_id=None, **extra):
    st = user_states.setdefault(chat_id, {"history": []})
    st["mode"] = "V2"
    st["step"] = step
    if msg_id:
        st["last_bot_msg_id"] = msg_id
    st.update(extra)
    return st


def _clear_step(chat_id):
    st = user_states.setdefault(chat_id, {"history": []})
    st.pop("step", None)
    if st.get("mode") == "V2":
        st.pop("mode", None)
    return st


def _tz():
    try:
        return _ZoneInfo(TIMEZONE)
    except Exception:
        return _dt.timezone.utc


def _g2j(gy, gm, gd):
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    if gy > 1600:
        jy, gy = 979, gy - 1600
    else:
        jy, gy = 0, gy - 621
    gy2 = gy + 1 if gm > 2 else gy
    days = 365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100 + (gy2 + 399) // 400 - 80 + gd + g_d_m[gm - 1]
    jy += 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm, jd = 1 + days // 31, 1 + days % 31
    else:
        jm, jd = 7 + (days - 186) // 30, 1 + (days - 186) % 30
    return jy, jm, jd


def _j2g(jy, jm, jd):
    jy += 1595
    days = (-355668 + 365 * jy + (jy // 33) * 8 + ((jy % 33) + 3) // 4 + jd
            + ((jm - 1) * 31 if jm < 7 else (jm - 7) * 30 + 186))
    gy = 400 * (days // 146097)
    days %= 146097
    if days > 36524:
        days -= 1
        gy += 100 * (days // 36524)
        days %= 36524
        if days >= 365:
            days += 1
    gy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        gy += (days - 1) // 365
        days = (days - 1) % 365
    gd = days + 1
    leap = (gy % 4 == 0 and gy % 100 != 0) or gy % 400 == 0
    sal = [0, 31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    gm = 0
    while gm < 13 and gd > sal[gm]:
        gd -= sal[gm]
        gm += 1
    return gy, gm, gd


def _fmt_dt(uid, ts):
    if not ts:
        return tr(uid, "none")
    d = _dt.datetime.fromtimestamp(ts, _tz())
    if i18n.get_lang(uid) == "fa":
        jy, jm, jd = _g2j(d.year, d.month, d.day)
        return f"{jy}/{jm:02d}/{jd:02d} {d:%H:%M}"
    return f"{d:%Y-%m-%d %H:%M}"


def _norm_digits(s):
    return (s or "").translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))


def _parse_when(text):
    """'2026-11-20 18:30' | '1405/08/29 18:30' (شمسی) | '18:30' → timestamp یا None."""
    s = _norm_digits(text).strip().replace("T", " ")
    tz = _tz()
    now = _dt.datetime.now(tz)
    m = re.fullmatch(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})\s+(\d{1,2}):(\d{2})", s)
    try:
        if m:
            y, mo, d, h, mi = map(int, m.groups())
            if y < 1700:
                y, mo, d = _j2g(y, mo, d)
            return _dt.datetime(y, mo, d, h, mi, tzinfo=tz).timestamp()
        m = re.fullmatch(r"(\d{1,2}):(\d{2})", s)
        if m:
            h, mi = map(int, m.groups())
            cand = now.replace(hour=h, minute=mi, second=0, microsecond=0)
            if cand <= now:
                cand += _dt.timedelta(days=1)
            return cand.timestamp()
    except ValueError:
        return None
    return None


def _plain_snippet(html_text, n=80):
    plain = html.unescape(re.sub(r"<[^>]+>", "", html_text or "")).strip().replace("\n", " ")
    plain = (plain[:n] + "…") if len(plain) > n else plain
    return html.escape(plain) or "—"


def _media_label(uid, media):
    if not media:
        return tr(uid, "media_none")
    if isinstance(media, list):
        return tr(uid, "media_album", n=len(media))
    return tr(uid, "media_" + str(media.get("type")), ) if ("media_" + str(media.get("type"))) in i18n.STRINGS["fa"] else str(media.get("type"))


def _flat_buttons(buttons):
    return [b for row in (buttons or []) for b in row]


def _maybe_low_balance_alert(user_id):
    try:
        if not strong.low_balance_check(user_id):
            return
    except Exception as e:
        print(f"⚠️ low-balance check: {e}")
        return

    def _send():
        try:
            bal = strong.get_balance(user_id)
            markup = _kb([_B(tr(user_id, "w_buy"), "buy_coin_start", "success", "🛒")])
            send_styled_message(user_id, tr(user_id, "low_alert", bal=bal), reply_markup=markup)
        except Exception as e:
            print(f"⚠️ low-balance notify: {e}")
    threading.Thread(target=_send, daemon=True).start()


# ── روتر callbackها ─────────────────────────────────────────────────────
_V2_ROUTES = {}


def _route(name):
    def deco(fn):
        _V2_ROUTES[name] = fn
        return fn
    return deco


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("v2:"))
def v2_callback(call):
    msg = call.message
    if msg is None or msg.chat.type != "private":
        return
    chat_id = msg.chat.id
    if _is_blocked(chat_id):
        _ans(call)
        return
    parts = call.data.split(":")
    fn = _V2_ROUTES.get(parts[1] if len(parts) > 1 else "")
    if not fn:
        _ans(call)
        return
    try:
        fn(call, chat_id, parts[2:])
    except Exception as e:
        print(f"❌ [v2:{parts[1]}] {type(e).__name__}: {e}")
        _ans(call, tr(chat_id, "error"), True)


# ── پست‌های من ──────────────────────────────────────────────────────────
def _post_label(uid, p):
    title = p.get("title") or _plain_snippet(p.get("text"), 22)
    mark = " " + tr(uid, "expired_mark") if p.get("expires_at") and p["expires_at"] <= time_module.time() else ""
    return f"{title} · 👁{p.get('views', 0)}{mark}"[:60]


@_route("posts")
def v2_posts(call, chat_id, args):
    page = max(0, int(args[0])) if args else 0
    total = strong.posts_count(chat_id)
    pages = max(1, -(-total // POST_PAGE_SIZE))
    page = min(page, pages - 1)
    posts = strong.posts_of(chat_id, POST_PAGE_SIZE, page * POST_PAGE_SIZE)
    _reset_state(chat_id)
    rows = [[_B(_post_label(chat_id, p), f"v2:post:{p['code']}", "primary", "📋", raw=True)] for p in posts]
    nav = []
    if page > 0:
        nav.append(_B(tr(chat_id, "prev"), f"v2:posts:{page - 1}"))
    if page < pages - 1:
        nav.append(_B(tr(chat_id, "next"), f"v2:posts:{page + 1}"))
    rows.append(nav)
    rows.append([_B(tr(chat_id, "post_new"), "reserve_post_start", "success", "✨")])
    rows.append(_miniapp_row(chat_id))
    rows.append(_nav(chat_id))
    text = tr(chat_id, "posts_title", n=total)
    text += "\n\n" + (tr(chat_id, "page", p=page + 1, n=pages) if posts else tr(chat_id, "posts_empty"))
    _ans(call)
    _show(call, text, _kb(*rows))


def _post_detail_screen(uid, code):
    p = strong.post_get(code, include_expired=True)
    if not p or int(p["owner_id"]) != int(uid):
        return None, None
    expired = p["expires_at"] and p["expires_at"] <= time_module.time()
    expiry = tr(uid, "forever") if not p["expires_at"] else _fmt_dt(uid, p["expires_at"]) + (" " + tr(uid, "expired_mark") if expired else "")
    text = tr(uid, "post_detail", title=p.get("title") or tr(uid, "post_untitled"), code=code,
              snippet=_plain_snippet(p["text"]), media=_media_label(uid, p["media"]),
              buttons=len(_flat_buttons(p["buttons"])), views=p["views"], created=_fmt_dt(uid, p["created_at"]),
              expiry=expiry, template=tr(uid, "on" if p["template"] else "off"),
              track=tr(uid, "on" if p["track_clicks"] else "off"))
    if p["template"]:
        text += "\n\n" + html.escape(tr(uid, "template_help"))
    c = f"v2:%s:{code}"
    markup = _kb(
        [_B(tr(uid, "post_edit_title"), c % "pe:title", "primary", "✏️"), _B(tr(uid, "post_edit_text"), c % "pe:text", "primary", "✏️")],
        [_B(tr(uid, "post_edit_media"), c % "pe:media", "primary", "🖼"), _B(tr(uid, "post_edit_album"), c % "pe:album", "primary", "📸")],
        [_B(tr(uid, "post_expiry"), c % "pexp", "primary", "⏳"),
         _B(f"{tr(uid, 'post_template')}: {tr(uid, 'on' if p['template'] else 'off')}", c % "ptpl", "primary", "🔀")],
        [_B(f"{tr(uid, 'post_track')}: {tr(uid, 'on' if p['track_clicks'] else 'off')}", c % "ptrk", "primary", "🔘"),
         _B(tr(uid, "post_stats"), c % "pstat", "primary", "🧾")],
        [_B(tr(uid, "post_send"), c % "sd", "success", "📢"), _B(tr(uid, "post_copy"), c % "pget", "success", "📌")],
        [_B(tr(uid, "post_delete"), c % "pdel", "danger", "🗑")],
        _nav(uid, "v2:posts:0"),
    )
    return text, markup


@_route("post")
def v2_post(call, chat_id, args):
    _reset_state(chat_id)
    text, markup = _post_detail_screen(chat_id, args[0])
    if not text:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    _ans(call)
    _show(call, text, markup)


def _owned_post(call, chat_id, code, include_expired=True):
    p = strong.post_get(code, include_expired=include_expired)
    if not p or int(p["owner_id"]) != int(chat_id):
        _ans(call, tr(chat_id, "not_found"), True)
        return None
    return p


@_route("pe")
def v2_post_edit(call, chat_id, args):
    field, code = args[0], args[1]
    if not _owned_post(call, chat_id, code):
        return
    prompts = {"title": "ask_title", "text": "ask_text", "media": "ask_media", "album": "ask_album"}
    if field not in prompts:
        _ans(call)
        return
    extra = {"v2_code": code}
    if field == "album":
        extra["v2_album"] = []
    st = _set_v2_step(chat_id, f"v2_pe_{field}", call.message.message_id, **extra)
    rows = [[_B(tr(chat_id, "done"), f"v2:albdone:{code}", "success", "✅")]] if field == "album" else []
    rows.append([_B(tr(chat_id, "cancel"), f"v2:post:{code}", "danger", "↪️")])
    _ans(call)
    _show(call, tr(chat_id, prompts[field]), _kb(*rows))


@_route("albdone")
def v2_album_done(call, chat_id, args):
    code = args[0]
    st = user_states.get(chat_id) or {}
    items = st.get("v2_album") or []
    if not _owned_post(call, chat_id, code):
        return
    if not items:
        _ans(call, tr(chat_id, "album_empty"), True)
        return
    strong.post_update(code, chat_id, media=items[0] if len(items) == 1 else items)
    _clear_step(chat_id)
    st.pop("v2_album", None)
    _ans(call, tr(chat_id, "saved"))
    text, markup = _post_detail_screen(chat_id, code)
    _show(call, text, markup)


@_route("pexp")
def v2_post_expiry(call, chat_id, args):
    code = args[0]
    if not _owned_post(call, chat_id, code):
        return
    c = f"v2:pexs:{code}:%s"
    markup = _kb(
        [_B(tr(chat_id, "exp_1h"), c % "1h"), _B(tr(chat_id, "exp_1d"), c % "1d")],
        [_B(tr(chat_id, "exp_7d"), c % "7d"), _B(tr(chat_id, "exp_30d"), c % "30d")],
        [_B(tr(chat_id, "exp_custom"), c % "custom"), _B(tr(chat_id, "exp_off"), c % "off", "success")],
        _nav(chat_id, f"v2:post:{code}"))
    _ans(call)
    _show(call, tr(chat_id, "ask_expiry"), markup)


@_route("pexs")
def v2_post_expiry_set(call, chat_id, args):
    code, opt = args[0], args[1]
    if not _owned_post(call, chat_id, code):
        return
    if opt == "custom":
        _set_v2_step(chat_id, "v2_pe_hours", call.message.message_id, v2_code=code)
        _ans(call)
        _show(call, tr(chat_id, "ask_expiry_hours"), _kb([_B(tr(chat_id, "cancel"), f"v2:post:{code}", "danger", "↪️")]))
        return
    hours = {"1h": 1, "1d": 24, "7d": 168, "30d": 720}.get(opt)
    strong.post_update(code, chat_id, expires_at=(time_module.time() + hours * 3600) if hours else None)
    _ans(call, tr(chat_id, "saved"))
    text, markup = _post_detail_screen(chat_id, code)
    _show(call, text, markup)


@_route("ptpl")
def v2_post_template(call, chat_id, args):
    p = _owned_post(call, chat_id, args[0])
    if not p:
        return
    strong.post_update(args[0], chat_id, template=0 if p["template"] else 1)
    _ans(call)
    text, markup = _post_detail_screen(chat_id, args[0])
    _show(call, text, markup)


@_route("ptrk")
def v2_post_track(call, chat_id, args):
    p = _owned_post(call, chat_id, args[0])
    if not p:
        return
    if not p["track_clicks"] and not config.PUBLIC_URL:
        _ans(call, tr(chat_id, "track_need_url"), True)
        return
    strong.post_update(args[0], chat_id, track_clicks=0 if p["track_clicks"] else 1)
    _ans(call)
    text, markup = _post_detail_screen(chat_id, args[0])
    _show(call, text, markup)


@_route("pstat")
def v2_post_stats(call, chat_id, args):
    code = args[0]
    p = _owned_post(call, chat_id, code)
    if not p:
        return
    text = tr(chat_id, "stats_title", code=code, views=p["views"])
    if not p["track_clicks"]:
        text += tr(chat_id, "stats_not_tracking")
    else:
        stats = strong.click_stats(code)
        flat = _flat_buttons(p["buttons"])
        lines = [tr(chat_id, "stats_line", text=html.escape(str(flat[i].get("text", i)) if i < len(flat) else i),
                    total=s["total"], unique=s["unique"]) for i, s in sorted(stats.items())]
        text += tr(chat_id, "stats_clicks", lines="\n".join(lines)) if lines else tr(chat_id, "stats_no_clicks")
    _ans(call)
    _show(call, text, _kb([_B(tr(chat_id, "refresh"), f"v2:pstat:{code}", "primary", "🔁"), _B(tr(chat_id, "post_widget"), f"v2:pwid:{code}", "success", "🪟") if _widgets_ok() else None],
                          _nav(chat_id, f"v2:post:{code}")))


@_route("pget")
def v2_post_get(call, chat_id, args):
    p = _owned_post(call, chat_id, args[0])
    if not p:
        return
    _ans(call)
    send_saved_post(chat_id, p, private=True)


@_route("pdel")
def v2_post_delete(call, chat_id, args):
    code = args[0]
    if not _owned_post(call, chat_id, code):
        return
    markup = _kb([_B(tr(chat_id, "yes"), f"v2:pdely:{code}", "danger", "🗑"), _B(tr(chat_id, "no"), f"v2:post:{code}", "success", "↪️")])
    _ans(call)
    _show(call, tr(chat_id, "confirm_delete", code=code), markup)


@_route("pdely")
def v2_post_delete_yes(call, chat_id, args):
    ok = strong.post_delete(args[0], chat_id)
    _ans(call, tr(chat_id, "deleted" if ok else "not_found"))
    v2_posts(call, chat_id, ["0"])


# ── ارسال چندمقصده و زمان‌بندی ───────────────────────────────────────────
def _user_destinations(uid):
    dests = []
    for gid, title in get_user_managed_groups(uid):
        dests.append({"id": str(gid), "title": title, "kind": "group"})
    for cid, title in get_user_managed_channels(uid):
        dests.append({"id": str(cid), "title": title, "kind": "channel"})
    return dests[:SCHEDULE_MAX_DESTINATIONS]


def _is_dest_admin(uid, dest_id):
    d = str(dest_id)
    for table in (group_admins, channel_admins):
        if d in table and int(uid) in [int(a) for a in table[d]]:
            return True
    return False


def _send_post_to_dest(chat_id, post):
    """مثل send_saved_post ولی خطا رو بالا می‌ده (تا تو گزارشِ چندمقصده دیده بشه)."""
    return _send_post_impl(chat_id, post, private=False, strict=True)


def _run_multi_send(owner_id, code, dests, check_admin=True):
    """به همه‌ی مقصدها می‌فرسته و {dest: 'ok' | 'err:...'} برمی‌گردونه."""
    results = {}
    post = strong.post_get(code)
    for d in dests:
        key = str(d)
        if post is None:
            results[key] = "expired"
        elif check_admin and not _is_dest_admin(owner_id, d):
            results[key] = "not_admin"
        else:
            try:
                _send_post_to_dest(int(d), post)
                results[key] = "ok"
            except Exception as e:
                results[key] = f"err:{str(e)[:80]}"
        time_module.sleep(0.35)          # فاصله‌ی کوتاه تا به flood-limit نخوریم
    return results


def _dest_name(sch, d):
    for x in (sch.get("dests") or []):
        if x["id"] == str(d):
            return html.escape(x["title"] or str(d))
    return html.escape(str(d))


def _results_lines(uid, results, names=None):
    lines = []
    for dest, res in (results or {}).items():
        name = html.escape((names or {}).get(dest, dest))
        if res == "ok":
            lines.append(tr(uid, "sc_res_ok", dest=name))
        else:
            why = {"expired": tr(uid, "why_expired"), "not_admin": tr(uid, "why_not_admin")}.get(res, html.escape(res.replace("err:", "")))
            lines.append(tr(uid, "sc_res_fail", dest=name, why=why))
    return "\n".join(lines) or "—"


@_route("sd")
def v2_send_dest(call, chat_id, args):
    code = args[0]
    p = _owned_post(call, chat_id, code, include_expired=False)
    if not p:
        return
    dests = _user_destinations(chat_id)
    _ans(call)
    if not dests:
        _show(call, tr(chat_id, "sd_none"), _kb(
            [_B(tr(chat_id, "m_add_group"), url=f"https://t.me/{BOT_USERNAME}?startgroup=botstart", style="success", icon="📢")],
            _nav(chat_id, f"v2:post:{code}")))
        return
    st = _reset_state(chat_id)
    st["v2_sch"] = {"code": code, "dests": dests, "sel": [], "when": None, "repeat": 0}
    _render_dest_screen(call, chat_id)


def _render_dest_screen(call, chat_id):
    sch = (user_states.get(chat_id) or {}).get("v2_sch")
    if not sch:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    rows = []
    for i, d in enumerate(sch["dests"]):
        mark = "✅" if i in sch["sel"] else "⬜"
        kind = tr(chat_id, "sd_" + d["kind"])
        rows.append([_B(f"{mark} {d['title']} ({kind})"[:60], f"v2:sdt:{i}", raw=True)])
    rows.append([_B(tr(chat_id, "sd_all"), "v2:sda", "primary", "📌"), _B(tr(chat_id, "sd_next"), "v2:sdn", "success", "↪️")])
    rows.append(_nav(chat_id, f"v2:post:{sch['code']}"))
    _show(call, tr(chat_id, "sd_title", code=sch["code"]), _kb(*rows))


@_route("sdt")
def v2_dest_toggle(call, chat_id, args):
    sch = (user_states.get(chat_id) or {}).get("v2_sch")
    if not sch:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    i = int(args[0])
    if i in sch["sel"]:
        sch["sel"].remove(i)
    else:
        sch["sel"].append(i)
    _ans(call)
    _render_dest_screen(call, chat_id)


@_route("sda")
def v2_dest_all(call, chat_id, args):
    sch = (user_states.get(chat_id) or {}).get("v2_sch")
    if not sch:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    sch["sel"] = [] if len(sch["sel"]) == len(sch["dests"]) else list(range(len(sch["dests"])))
    _ans(call)
    _render_dest_screen(call, chat_id)


@_route("sdn")
def v2_dest_next(call, chat_id, args):
    sch = (user_states.get(chat_id) or {}).get("v2_sch")
    if not sch:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    if not sch["sel"]:
        _ans(call, tr(chat_id, "sd_pick_one"), True)
        return
    c = "v2:st:%s"
    markup = _kb(
        [_B(tr(chat_id, "st_now"), c % "now", "success", "🚀")],
        [_B(tr(chat_id, "st_15m"), c % "15m"), _B(tr(chat_id, "st_1h"), c % "1h")],
        [_B(tr(chat_id, "st_3h"), c % "3h"), _B(tr(chat_id, "st_tom"), c % "tom")],
        [_B(tr(chat_id, "st_custom"), c % "custom", "primary", "⏳")],
        _nav(chat_id, f"v2:sd:{sch['code']}"))
    _ans(call)
    _show(call, tr(chat_id, "st_title", tz=TIMEZONE), markup)


@_route("st")
def v2_time_pick(call, chat_id, args):
    sch = (user_states.get(chat_id) or {}).get("v2_sch")
    if not sch:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    opt = args[0]
    now = time_module.time()
    if opt == "custom":
        _set_v2_step(chat_id, "v2_sch_when", call.message.message_id)
        _ans(call)
        _show(call, tr(chat_id, "ask_when"), _kb([_B(tr(chat_id, "cancel"), "v2:sdn", "danger", "↪️")]))
        return
    if opt == "now":
        sch["when"] = None
    elif opt == "tom":
        d = _dt.datetime.now(_tz()) + _dt.timedelta(days=1)
        sch["when"] = d.replace(hour=9, minute=0, second=0, microsecond=0).timestamp()
    else:
        sch["when"] = now + {"15m": 900, "1h": 3600, "3h": 10800}[opt]
    _ans(call)
    _render_confirm_screen(call.message.chat.id, call.message.message_id)


def _render_confirm_screen(chat_id, msg_id):
    sch = (user_states.get(chat_id) or {}).get("v2_sch")
    if not sch:
        return
    names = [sch["dests"][i]["title"] for i in sch["sel"]]
    dests_txt = "\n".join("• " + html.escape(n or "?") for n in names[:10]) + (f"\n… +{len(names) - 10}" if len(names) > 10 else "")
    when_txt = tr(chat_id, "sc_now_label") if not sch["when"] else _fmt_dt(chat_id, sch["when"])
    rep = {0: "rep_none", 1440: "rep_daily", 10080: "rep_weekly"}[sch["repeat"]]
    text = tr(chat_id, "sc_summary", code=sch["code"], n=len(names), dests=dests_txt, when=when_txt, repeat=tr(chat_id, rep))
    p = strong.post_get(sch["code"], include_expired=True)
    if p and p["expires_at"] and sch["when"] and p["expires_at"] < sch["when"]:
        text += tr(chat_id, "sc_expiry_warn")
    rows = [[_B(tr(chat_id, "sc_repeat", r=tr(chat_id, rep)), "v2:sr", "primary", "🔁")],
            [_B(tr(chat_id, "sc_confirm"), "v2:sok", "success", "✅")],
            _nav(chat_id, "v2:sdn")]
    edit_or_send_message(chat_id, msg_id, text, reply_markup=_kb(*rows))


@_route("sr")
def v2_repeat_cycle(call, chat_id, args):
    sch = (user_states.get(chat_id) or {}).get("v2_sch")
    if not sch:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    sch["repeat"] = {0: 1440, 1440: 10080, 10080: 0}[sch["repeat"]]
    _ans(call)
    _render_confirm_screen(chat_id, call.message.message_id)


@_route("sok")
def v2_schedule_confirm(call, chat_id, args):
    st = user_states.get(chat_id) or {}
    sch = st.get("v2_sch")
    if not sch or not sch["sel"]:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    dest_ids = [sch["dests"][i]["id"] for i in sch["sel"]]
    names = {sch["dests"][i]["id"]: sch["dests"][i]["title"] for i in sch["sel"]}
    code = sch["code"]
    _ans(call, tr(chat_id, "self_busy") if not sch["when"] else None)
    if not sch["when"]:
        results = _run_multi_send(chat_id, code, dest_ids)
        _reset_state(chat_id)
        _show(call, tr(chat_id, "sc_sent", lines=_results_lines(chat_id, results, names)),
              _kb(_nav(chat_id, f"v2:post:{code}")))
        return
    sid = strong.schedule_create(chat_id, code, dest_ids, sch["when"], sch["repeat"] or None)
    _reset_state(chat_id)
    _show(call, tr(chat_id, "sc_created", id=sid, when=_fmt_dt(chat_id, sch["when"])),
          _kb([_B(tr(chat_id, "m_schedule"), "v2:sch:0", "primary", "📅")], _nav(chat_id, f"v2:post:{code}")))


def _sched_status(uid, s):
    return tr(uid, "status_" + s["status"]) if ("status_" + s["status"]) in i18n.STRINGS["fa"] else s["status"]


@_route("sch")
def v2_schedules(call, chat_id, args):
    items = strong.schedule_list(chat_id, limit=15)
    _reset_state(chat_id)
    rows = []
    for s in items:
        label = tr(chat_id, "sch_item", id=s["id"], code=s["post_code"], n=len(s["destinations"]), when=_fmt_dt(chat_id, s["run_at"]))
        label = re.sub(r"<[^>]+>", "", label)
        rows.append([_B(f"{'🟢' if s['status'] == 'pending' else '⚪'} {label}"[:60], f"v2:schi:{s['id']}", raw=True)])
    rows.append(_nav(chat_id))
    _ans(call)
    _show(call, tr(chat_id, "sch_title") + ("" if items else "\n\n" + tr(chat_id, "sch_empty")), _kb(*rows))


@_route("schi")
def v2_schedule_item(call, chat_id, args):
    sid = int(args[0])
    s = next((x for x in strong.schedule_list(chat_id, limit=50) if x["id"] == sid), None)
    if not s:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    rep = tr(chat_id, "rep_none") if not s["repeat_minutes"] else tr(chat_id, "rep_daily" if s["repeat_minutes"] == 1440 else "rep_weekly")
    res = ("\n\n" + _results_lines(chat_id, s["results"])) if s.get("results") else ""
    text = tr(chat_id, "sch_detail", id=s["id"], code=s["post_code"], n=len(s["destinations"]),
              when=_fmt_dt(chat_id, s["run_at"]), repeat=rep, status=_sched_status(chat_id, s), results=res)
    rows = []
    if s["status"] == "pending":
        rows.append([_B(tr(chat_id, "sch_cancel"), f"v2:schx:{sid}", "danger", "🗑")])
    rows.append(_nav(chat_id, "v2:sch:0"))
    _ans(call)
    _show(call, text, _kb(*rows))


@_route("schx")
def v2_schedule_cancel(call, chat_id, args):
    ok = strong.schedule_cancel(int(args[0]), chat_id)
    _ans(call, tr(chat_id, "sch_cancelled" if ok else "not_found"))
    v2_schedules(call, chat_id, [])


def _run_schedule(s):
    owner = s["owner_id"]
    try:
        results = _run_multi_send(owner, s["post_code"], s["destinations"])
    except Exception as e:
        results = {str(d): f"err:{e}" for d in s["destinations"]}
    strong.schedule_finish(s["id"], results)
    try:
        send_styled_message(owner, tr(owner, "sc_report", code=s["post_code"], lines=_results_lines(owner, results)))
    except Exception as e:
        print(f"⚠️ schedule report to {owner}: {e}")


def scheduler_loop():
    """از main.py تو یه ترد اجرا می‌شه: زمان‌بندی‌های سررسیده رو می‌فرسته و هر ساعت پاک‌سازی می‌کنه."""
    last_purge = 0.0
    while True:
        try:
            for s in strong.schedule_due():
                if strong.schedule_claim(s["id"]):
                    threading.Thread(target=_run_schedule, args=(s,), daemon=True, name=f"sched-{s['id']}").start()
            if time_module.time() - last_purge > 3600:
                strong.posts_purge_expired()
                strong.purge_stale_flows()
                last_purge = time_module.time()
        except Exception as e:
            print(f"❌ [scheduler] {e}")
        time_module.sleep(SCHEDULE_POLL_SECONDS)


# ── کیف پول ─────────────────────────────────────────────────────────────
def _tx_line(uid, r):
    label = tr(uid, "tx_" + r["type"]) if ("tx_" + r["type"]) in i18n.STRINGS["fa"] else r["type"]
    sign = "➕" if r["amount"] > 0 else "➖"
    return f"{sign} <b>{r['amount']:+d}</b> · {label} · {_fmt_dt(uid, r['created_at'])}"


@_route("wallet")
def v2_wallet(call, chat_id, args):
    _reset_state(chat_id)
    addr = strong.ensure_wallet(chat_id)
    rows = strong.get_history(chat_id, limit=3)
    recent = tr(chat_id, "wallet_recent", lines="\n".join(_tx_line(chat_id, r) for r in rows)) if rows else tr(chat_id, "wallet_no_tx")
    text = tr(chat_id, "wallet_title", bal=strong.get_balance(chat_id), addr=addr, recent=recent)
    markup = _kb(
        [_B(tr(chat_id, "w_history"), "v2:hist:0", "primary", "🧾"), _B(tr(chat_id, "w_daily"), "v2:daily", "success", "💎")],
        [_B(tr(chat_id, "w_gift"), "v2:gift", "primary", "🔖"), _B(tr(chat_id, "w_transfer"), "v2:xfer", "primary", "💵")],
        [_B(tr(chat_id, "w_buy"), "buy_coin_start", "success", "🛒"), _B(tr(chat_id, "w_alert"), "v2:low", "primary", "⚠️")],
        [_B(tr(chat_id, "w_widget"), "v2:wcard", "success", "🪟") if _widgets_ok() else None],
        _nav(chat_id))
    _ans(call)
    _show(call, text, markup)


@_route("hist")
def v2_history(call, chat_id, args):
    page = max(0, int(args[0])) if args else 0
    per = 8
    total = strong.count_history(chat_id)
    pages = max(1, -(-total // per))
    page = min(page, pages - 1)
    rows = strong.get_history(chat_id, limit=per, offset=page * per)
    text = tr(chat_id, "hist_title") + "\n\n" + ("\n".join(_tx_line(chat_id, r) for r in rows) if rows else tr(chat_id, "hist_empty"))
    nav = []
    if page > 0:
        nav.append(_B(tr(chat_id, "prev"), f"v2:hist:{page - 1}"))
    if page < pages - 1:
        nav.append(_B(tr(chat_id, "next"), f"v2:hist:{page + 1}"))
    _ans(call)
    _show(call, text + f"\n\n{tr(chat_id, 'page', p=page + 1, n=pages)}", _kb(nav, _nav(chat_id, "v2:wallet")))


@_route("daily")
def v2_daily(call, chat_id, args):
    strong.ensure_wallet(chat_id)
    amount, info = strong.daily_claim(chat_id)
    if amount is None:
        h, m = info // 3600, (info % 3600) // 60
        _ans(call, re.sub(r"<[^>]+>", "", tr(chat_id, "daily_wait", h=h, m=m)), True)
        return
    _ans(call)
    _show(call, tr(chat_id, "daily_ok", amount=amount, streak=info), _kb(_nav(chat_id, "v2:wallet")))


@_route("gift")
def v2_gift(call, chat_id, args):
    _set_v2_step(chat_id, "v2_gift", call.message.message_id)
    _ans(call)
    _show(call, tr(chat_id, "ask_gift"), _kb(_nav(chat_id, "v2:wallet")))


@_route("xfer")
def v2_transfer(call, chat_id, args):
    strong.ensure_wallet(chat_id)
    _set_v2_step(chat_id, "v2_xfer_to", call.message.message_id)
    _ans(call)
    _show(call, tr(chat_id, "ask_xfer_to"), _kb(_nav(chat_id, "v2:wallet")))


def _xfer_fee(amount):
    return -(-amount * TRANSFER_FEE_PERCENT // 100) if TRANSFER_FEE_PERCENT else 0


@_route("xok")
def v2_transfer_confirm(call, chat_id, args):
    x = (user_states.get(chat_id) or {}).get("v2_xfer")
    if not x:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    amount, to_id, fee = int(x["amount"]), int(x["to"]), _xfer_fee(int(x["amount"]))

    class _Insufficient(Exception):
        pass

    try:
        with strong.tx():
            ok, why = strong.transfer(chat_id, to_id, amount, {"id": chat_id}, {"id": to_id})
            if not ok:
                raise _Insufficient(why)
            if fee and not strong.charge(chat_id, fee, "transfer_fee"):
                raise _Insufficient("insufficient")
    except _Insufficient:
        _ans(call, tr(chat_id, "xfer_insufficient"), True)
        return
    _reset_state(chat_id)
    _ans(call)
    _show(call, tr(chat_id, "xfer_ok", amount=amount), _kb(_nav(chat_id, "v2:wallet")))
    _maybe_low_balance_alert(chat_id)
    try:
        send_styled_message(to_id, tr(to_id, "xfer_received", amount=amount, frm=chat_id))
    except Exception:
        pass


@_route("low")
def v2_low_alert(call, chat_id, args):
    if args:
        n = int(args[0])
        strong.set_setting(chat_id, low_threshold=n, low_alert=0)
        _ans(call, re.sub(r"<[^>]+>", "", tr(chat_id, "low_set", n=n)), True)
        return v2_wallet(call, chat_id, [])
    opts = [0, 10, 20, 50, 100]
    cur = strong.get_settings(chat_id)["low_threshold"]
    rows = [[_B(("✅ " if n == cur else "") + (tr(chat_id, "low_off") if n == 0 else str(n)), f"v2:low:{n}") for n in opts]]
    rows.append(_nav(chat_id, "v2:wallet"))
    _ans(call)
    _show(call, tr(chat_id, "low_title"), _kb(*rows))


# ── رزروهای اموجی ───────────────────────────────────────────────────────
def _emoji_label(e):
    return f"{e['emoji']} {e.get('name') or e['id']}"[:60]


@_route("emo")
def v2_emojis(call, chat_id, args):
    page = max(0, int(args[0])) if args else 0
    data = strong.emoji_data(chat_id)
    items = list(data["emojis"].items())
    per = 8
    pages = max(1, -(-len(items) // per))
    page = min(page, pages - 1)
    _reset_state(chat_id)
    rows = [[_B(_emoji_label(e), f"v2:emoi:{slot}", "primary", raw=True)] for slot, e in items[page * per:(page + 1) * per]]
    nav = []
    if page > 0:
        nav.append(_B(tr(chat_id, "prev"), f"v2:emo:{page - 1}"))
    if page < pages - 1:
        nav.append(_B(tr(chat_id, "next"), f"v2:emo:{page + 1}"))
    rows.append(nav)
    rows.append([_B(tr(chat_id, "emo_search"), "v2:emos", "primary", "🔖"), _B(tr(chat_id, "emo_upgrade"), "reserve_emoji_start", "success", "💎")])
    rows.append(_miniapp_row(chat_id))
    rows.append(_nav(chat_id))
    text = tr(chat_id, "emo_title", used=len(items), cap=data["capacity"])
    if not items:
        text += "\n\n" + tr(chat_id, "emo_empty")
    _ans(call)
    _show(call, text, _kb(*rows))


@_route("emoi")
def v2_emoji_item(call, chat_id, args):
    slot = args[0]
    e = strong.emoji_data(chat_id)["emojis"].get(slot)
    if not e:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    preview = f'<tg-emoji emoji-id="{e["id"]}">{html.escape(e["emoji"])}</tg-emoji>'
    text = tr(chat_id, "emo_detail", preview=preview, name=html.escape(e.get("name") or "—"), id=e["id"],
              pack=html.escape(e.get("pack") or "—"), char=html.escape(e["emoji"]))
    markup = _kb([_B(tr(chat_id, "emo_rename"), f"v2:emor:{slot}", "primary", "✏️"), _B(tr(chat_id, "emo_delete"), f"v2:emod:{slot}", "danger", "🗑")],
                 _nav(chat_id, "v2:emo:0"))
    _ans(call)
    try:
        bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, text=text, parse_mode="HTML", reply_markup=markup)
    except Exception:
        _show(call, re.sub(r"<[^>]+>", "", text), markup)


@_route("emor")
def v2_emoji_rename(call, chat_id, args):
    _set_v2_step(chat_id, "v2_emo_name", call.message.message_id, v2_slot=args[0])
    _ans(call)
    _show(call, tr(chat_id, "ask_emo_name"), _kb([_B(tr(chat_id, "cancel"), f"v2:emoi:{args[0]}", "danger", "↪️")]))


@_route("emod")
def v2_emoji_delete(call, chat_id, args):
    markup = _kb([_B(tr(chat_id, "yes"), f"v2:emody:{args[0]}", "danger", "🗑"), _B(tr(chat_id, "no"), f"v2:emoi:{args[0]}", "success", "↪️")])
    _ans(call)
    _show(call, tr(chat_id, "emo_confirm_delete"), markup)


@_route("emody")
def v2_emoji_delete_yes(call, chat_id, args):
    ok = strong.emoji_delete(chat_id, args[0])
    _ans(call, tr(chat_id, "deleted" if ok else "not_found"))
    v2_emojis(call, chat_id, ["0"])


@_route("emos")
def v2_emoji_search_start(call, chat_id, args):
    _set_v2_step(chat_id, "v2_emo_search", call.message.message_id)
    _ans(call)
    _show(call, tr(chat_id, "ask_emo_search"), _kb(_nav(chat_id, "v2:emo:0")))


# رزروِ تک‌پیامی: پیام با اموجی پرمیوم یا لینک پک → همه‌ی اموجی‌ها یک‌جا
def _u16_slice(text, offset, length):
    raw = text.encode("utf-16-le")
    return raw[offset * 2:(offset + length) * 2].decode("utf-16-le", errors="ignore")


def _custom_emoji_entities(m):
    ents = (getattr(m, "entities", None) or getattr(m, "caption_entities", None) or [])
    return [e for e in ents if getattr(e, "type", None) == "custom_emoji" and getattr(e, "custom_emoji_id", None)]


def _wants_emoji_reserve(m):
    if m.chat.type != "private" or _is_blocked(m.chat.id) or not _has_no_active_flow(m):
        return False
    if _custom_emoji_entities(m):
        return True
    return bool(m.text and _TG_EMOJI_PACK_RE.search(m.text))


def _offer_reserve(chat_id, items, pack_label=""):
    if not items:
        return
    uniq, seen = [], set()
    for it in items:
        if it["id"] not in seen:
            seen.add(it["id"])
            uniq.append(it)
    st = user_states.setdefault(chat_id, {"history": []})
    st["v2_pending_emoji"] = uniq[:200]
    free = max(0, strong.get_settings(chat_id)["emoji_capacity"] - strong.emoji_count(chat_id))
    text = tr(chat_id, "rsv_found", n=len(uniq), pack=tr(chat_id, "rsv_pack_label", pack=html.escape(pack_label)) if pack_label else "", free=free)
    markup = _kb([_B(tr(chat_id, "rsv_all", n=len(uniq[:200])), "v2:rsvall", "success", "🔖"), _B(tr(chat_id, "cancel"), "v2:rsvno", "danger", "🗑")])
    send_styled_message(chat_id, text, reply_markup=markup)


@bot.message_handler(func=_wants_emoji_reserve, content_types=["text", "photo", "video", "animation", "document"])
def handle_emoji_reserve_message(message):
    chat_id = message.chat.id
    text = message.text or message.caption or ""
    m = _TG_EMOJI_PACK_RE.search(text) if message.text else None
    if m:
        try:
            sset = bot.get_sticker_set(m.group(1))
        except Exception:
            send_styled_message(chat_id, tr(chat_id, "rsv_pack_fail"))
            return
        stickers = [s for s in (sset.stickers or []) if getattr(s, "custom_emoji_id", None)]
        if not stickers:
            send_styled_message(chat_id, tr(chat_id, "rsv_not_emoji_pack"))
            return
        title = getattr(sset, "title", None) or sset.name
        items = [{"char": s.emoji or "⭐", "id": s.custom_emoji_id, "name": f"{s.emoji or ''} {title}".strip(), "pack": title} for s in stickers]
        _offer_reserve(chat_id, items, title)
        return
    ents = _custom_emoji_entities(message)
    ids = [e.custom_emoji_id for e in ents]
    info = {}
    try:
        for s in bot.get_custom_emoji_stickers(list(dict.fromkeys(ids))[:200]):
            info[s.custom_emoji_id] = s
    except Exception as e:
        print(f"⚠️ get_custom_emoji_stickers: {e}")
    items = []
    for e in ents:
        s = info.get(e.custom_emoji_id)
        char = (getattr(s, "emoji", None) if s else None) or _u16_slice(text, e.offset, e.length) or "⭐"
        pack = getattr(s, "set_name", None) if s else None
        items.append({"char": char, "id": e.custom_emoji_id, "name": f"{char} {pack or ''}".strip(), "pack": pack})
    _offer_reserve(chat_id, items, items[0]["pack"] or "" if items and len({i["pack"] for i in items}) == 1 else "")


@_route("rsvall")
def v2_reserve_all(call, chat_id, args):
    st = user_states.get(chat_id) or {}
    items = st.pop("v2_pending_emoji", None)
    if not items:
        _ans(call, tr(chat_id, "rsv_expired"), True)
        return
    res = strong.emoji_add_many(chat_id, items)
    text = tr(chat_id, "rsv_result", added=res["added"], dup=res["duplicates"], full=res["full"])
    if res["full"]:
        text += tr(chat_id, "rsv_full_hint")
    _ans(call)
    _show(call, text, _kb([_B(tr(chat_id, "m_emoji"), "v2:emo:0", "primary", "🔖")], _nav(chat_id)))


@_route("rsvno")
def v2_reserve_no(call, chat_id, args):
    (user_states.get(chat_id) or {}).pop("v2_pending_emoji", None)
    _ans(call)
    try:
        bot.delete_message(chat_id, call.message.message_id)
    except Exception:
        pass


# ── پنل سلف ─────────────────────────────────────────────────────────────
def _self_screen(uid):
    s = self_module.selfbot_status(uid)
    if not s["has_session"] and not s["connected"]:
        state = tr(uid, "self_nosession")
    elif not s["connected"]:
        state = tr(uid, "self_disconnected")
    elif s["paused"]:
        state = tr(uid, "self_paused")
    else:
        state = tr(uid, "self_active")
    text = tr(uid, "self_title", state=state, posts=s["posts"], emoji=s["emoji"], last=_fmt_dt(uid, s["last"]))
    rows = []
    if not s["has_session"] and not s["connected"]:
        rows.append([_B(tr(uid, "self_login"), "userbot_login_start", "success", "🔐")])
    else:
        if s["connected"]:
            rows.append([_B(tr(uid, "self_resume" if s["paused"] else "self_pause"), "v2:selft", "primary", "🔁"),
                         _B(tr(uid, "self_disconnect"), "v2:selfd", "danger", "📌")])
        else:
            rows.append([_B(tr(uid, "self_reconnect"), "v2:selfr", "success", "🔁")])
        rows.append([_B(tr(uid, "self_logout"), "v2:selfo", "danger", "🗑")])
    rows.append([_B(tr(uid, "refresh"), "v2:self", "primary", "🔁")])
    rows.append(_nav(uid))
    return text, _kb(*rows)


@_route("self")
def v2_self(call, chat_id, args):
    _ans(call)
    text, markup = _self_screen(chat_id)
    _show(call, text, markup)


@_route("selft")
def v2_self_toggle(call, chat_id, args):
    self_module.selfbot_set_paused(chat_id, not self_module.selfbot_status(chat_id)["paused"])
    v2_self(call, chat_id, [])


@_route("selfd")
def v2_self_disconnect(call, chat_id, args):
    _ans(call, tr(chat_id, "self_busy"))
    self_module.selfbot_disconnect(chat_id)
    v2_self(call, chat_id, [])


@_route("selfr")
def v2_self_reconnect(call, chat_id, args):
    _ans(call, tr(chat_id, "self_busy"))
    ok = False
    try:
        ok = self_module.selfbot_reconnect(chat_id)
    except Exception as e:
        print(f"⚠️ selfbot_reconnect: {e}")
    if not ok:
        _ans(call, tr(chat_id, "self_fail"), True)
    v2_self(call, chat_id, [])


@_route("selfo")
def v2_self_logout(call, chat_id, args):
    if args and args[0] == "y":
        _ans(call, tr(chat_id, "self_busy"))
        try:
            self_module.selfbot_disconnect(chat_id, logout=True)
        except Exception as e:
            print(f"⚠️ selfbot logout: {e}")
        v2_self(call, chat_id, [])
        return
    _ans(call)
    _show(call, tr(chat_id, "self_logout_confirm"),
          _kb([_B(tr(chat_id, "yes"), "v2:selfo:y", "danger", "🗑"), _B(tr(chat_id, "no"), "v2:self", "success", "↪️")]))


# ── داشبورد ادمین و کدهای هدیه ──────────────────────────────────────────
def _admin_only(call, chat_id):
    if chat_id != SUPER_ADMIN_ID:
        _ans(call, tr(chat_id, "no_access"), True)
        return False
    return True


@_route("adm")
def v2_admin_dashboard(call, chat_id, args):
    if not _admin_only(call, chat_id):
        return
    st = strong.dashboard_stats()
    top_n = max(st["last7_inline"]) or 1
    spark = "".join(_SPARK[min(7, int(v / top_n * 7))] if v else _SPARK[0] for v in st["last7_inline"]) + f"  ({sum(st['last7_inline'])})"
    top = "\n".join(f"{i}. <code>{r['user_id']}</code> — {r['spent']}" for i, r in enumerate(st["top_spenders"], 1)) or "—"
    text = tr(chat_id, "adm_title", self_online=len(self_module.selfbot_connected_ids()), spark=spark, top=top, **st)
    markup = _kb([_B(tr(chat_id, "refresh"), "v2:adm", "primary", "🔁"), _B(tr(chat_id, "adm_btn_gifts"), "v2:admg", "primary", "🔖")],
                 [_B(tr(chat_id, "adm_widget"), "v2:awid", "success", "🪟") if _widgets_ok() else None],
                 _nav(chat_id))
    _ans(call)
    _show(call, text, markup)


@_route("admg")
def v2_admin_gifts(call, chat_id, args):
    if not _admin_only(call, chat_id):
        return
    gifts = strong.gift_list(15)
    lines = "\n".join(tr(chat_id, "adm_gift_line", code=g["code"], amount=g["amount"], used=g["used"], max=g["max_uses"]) for g in gifts) or tr(chat_id, "adm_gift_none")
    rows = [[_B(f"🗑 {g['code']}", f"v2:admgd:{g['code']}", "danger", raw=True)] for g in gifts[:8]]
    rows.append([_B(tr(chat_id, "adm_gift_new"), "v2:admgn", "success", "✨")])
    rows.append(_nav(chat_id, "v2:adm"))
    _ans(call)
    _show(call, tr(chat_id, "adm_gifts", lines=lines), _kb(*rows))


@_route("admgn")
def v2_admin_gift_new(call, chat_id, args):
    if not _admin_only(call, chat_id):
        return
    _set_v2_step(chat_id, "v2_adm_gift", call.message.message_id)
    _ans(call)
    _show(call, tr(chat_id, "adm_ask_gift"), _kb(_nav(chat_id, "v2:admg")))


@_route("admgd")
def v2_admin_gift_delete(call, chat_id, args):
    if not _admin_only(call, chat_id):
        return
    strong.gift_delete(args[0])
    _ans(call, tr(chat_id, "deleted"))
    v2_admin_gifts(call, chat_id, [])


# ── آموزش و زبان ────────────────────────────────────────────────────────
_TUT_PAGES = 5


def _tutorial_screen(uid, n):
    n = max(0, min(_TUT_PAGES - 1, n))
    text = tr(uid, f"tut_{n + 1}") + f"\n\n{n + 1}/{_TUT_PAGES}"
    nav = []
    if n > 0:
        nav.append(_B(tr(uid, "prev"), f"v2:tut:{n - 1}"))
    if n < _TUT_PAGES - 1:
        nav.append(_B(tr(uid, "next"), f"v2:tut:{n + 1}", "success"))
    else:
        nav.append(_B(tr(uid, "tut_done"), "nav_all_back", "success", "✨"))
    rows = [nav]
    if n < _TUT_PAGES - 1:
        rows.append([_B(tr(uid, "skip"), "nav_all_back", "danger", "🔀")])
    return text, _kb(*rows)


def _v2_send_tutorial(chat_id, n=0):
    text, markup = _tutorial_screen(chat_id, n)
    send_styled_message(chat_id, text, reply_markup=markup)


@_route("tut")
def v2_tutorial(call, chat_id, args):
    text, markup = _tutorial_screen(chat_id, int(args[0]) if args else 0)
    _ans(call)
    _show(call, text, markup)


@_route("lang")
def v2_language(call, chat_id, args):
    if args and args[0] in i18n.STRINGS:
        i18n.set_lang(chat_id, args[0])
        _ans(call, re.sub(r"<[^>]+>", "", tr(chat_id, "lang_set")))
        _show(call, _main_text(chat_id, call.from_user.first_name), main_keyboard(chat_id))
        return
    _ans(call)
    _show(call, tr(chat_id, "lang_title"), _kb([_B(label, f"v2:lang:{code}", "primary", raw=True) for code, label in i18n.LANGS.items()], _nav(chat_id)))


# ── ورودی‌های متنی/رسانه‌ای مرحله‌های v2 ───────────────────────────────────
def _v2_step_active(m):
    return m.chat.type == "private" and str((user_states.get(m.chat.id) or {}).get("step") or "").startswith("v2_") and not _is_blocked(m.chat.id)


def _edit_prompt_msg(chat_id, st, text, markup=None):
    msg_id = st.get("last_bot_msg_id")
    if msg_id:
        return edit_or_send_message(chat_id, msg_id, text, reply_markup=markup)
    return send_styled_message(chat_id, text, reply_markup=markup)


def _back_to_post(chat_id, code, note=None):
    _clear_step(chat_id)
    text, markup = _post_detail_screen(chat_id, code)
    if not text:
        return
    sent = send_styled_message(chat_id, (note + "\n\n" if note else "") + text, reply_markup=markup)
    if sent:
        user_states.setdefault(chat_id, {"history": []})["last_bot_msg_id"] = sent.message_id


def _media_info_from_message(message):
    if message.content_type == "animation":
        return {"type": "animation", "file_id": message.animation.file_id}
    return extract_media_info(message)


@bot.message_handler(func=_v2_step_active, content_types=["text", "photo", "video", "document", "animation", "audio"])
def v2_step_handler(message):
    chat_id = message.chat.id
    st = user_states.get(chat_id) or {}
    step = st.get("step")
    raw = (message.text or "").strip()
    if raw.startswith("/"):                       # دستورها (مثل /start) مسیر خودشون رو دارن؛ مرحله رو ول کن
        _clear_step(chat_id)
        return
    code = st.get("v2_code")

    if step == "v2_pe_title" and raw:
        title = None if raw == "-" else html.escape(raw[:60])
        strong.post_update(code, chat_id, title=title)
        return _back_to_post(chat_id, code, tr(chat_id, "saved"))

    if step == "v2_pe_text":
        new_text = sanitize_html_for_telegram(get_html_text_from_message(message))
        if not new_text:
            return send_styled_message(chat_id, tr(chat_id, "ask_text"))
        strong.post_update(code, chat_id, text=new_text)
        return _back_to_post(chat_id, code, tr(chat_id, "saved"))

    if step == "v2_pe_media":
        if raw == "-":
            strong.post_update(code, chat_id, media=None)
            return _back_to_post(chat_id, code, tr(chat_id, "saved"))
        info = _media_info_from_message(message)
        if not info:
            return send_styled_message(chat_id, tr(chat_id, "ask_media"))
        strong.post_update(code, chat_id, media=info)
        return _back_to_post(chat_id, code, tr(chat_id, "saved"))

    if step == "v2_pe_album":
        info = _media_info_from_message(message)
        if not info or info["type"] not in ("photo", "video", "document"):
            return send_styled_message(chat_id, tr(chat_id, "ask_album"))
        items = st.setdefault("v2_album", [])
        if len(items) < 10:
            items.append(info)
        send_styled_message(chat_id, tr(chat_id, "album_count", n=len(items)),
                            reply_markup=_kb([_B(tr(chat_id, "done"), f"v2:albdone:{code}", "success", "✅")]))
        return

    if step == "v2_pe_hours":
        try:
            hours = float(_norm_digits(raw))
            assert 0 < hours <= 8760
        except (ValueError, AssertionError):
            return send_styled_message(chat_id, tr(chat_id, "bad_number"))
        strong.post_update(code, chat_id, expires_at=time_module.time() + hours * 3600)
        return _back_to_post(chat_id, code, tr(chat_id, "saved"))

    if step == "v2_sch_when":
        ts = _parse_when(raw)
        if ts is None or ts <= time_module.time() + 30:
            return send_styled_message(chat_id, tr(chat_id, "bad_when"))
        if ts > time_module.time() + 365 * 86400:
            return send_styled_message(chat_id, tr(chat_id, "far_when"))
        sch = st.get("v2_sch")
        if not sch:
            return _clear_step(chat_id)
        sch["when"] = ts
        _clear_step(chat_id)
        sent = send_styled_message(chat_id, "…")
        return _render_confirm_screen(chat_id, sent.message_id)

    if step == "v2_emo_search":
        found = strong.emoji_search(chat_id, raw)
        _clear_step(chat_id)
        rows = [[_B(_emoji_label(e), f"v2:emoi:{e['slot']}", "primary", raw=True)] for e in found[:10]]
        rows.append(_nav(chat_id, "v2:emo:0"))
        text = tr(chat_id, "emo_results", n=len(found)) if found else tr(chat_id, "emo_no_results")
        return send_styled_message(chat_id, text, reply_markup=_kb(*rows))

    if step == "v2_emo_name" and raw:
        slot = st.get("v2_slot")
        strong.emoji_update(chat_id, slot, name=raw[:40])
        _clear_step(chat_id)
        return send_styled_message(chat_id, tr(chat_id, "saved"), reply_markup=_kb([_B(tr(chat_id, "m_emoji"), "v2:emo:0", "primary", "🔖")]))

    if step == "v2_gift" and raw:
        amount, why = strong.gift_redeem(raw.strip().upper(), chat_id)
        if amount is None:
            return send_styled_message(chat_id, tr(chat_id, "gift_" + why))
        _clear_step(chat_id)
        return send_styled_message(chat_id, tr(chat_id, "gift_ok", amount=amount), reply_markup=_kb(_nav(chat_id, "v2:wallet")))

    if step == "v2_xfer_to":
        fwd = getattr(message, "forward_from", None)
        try:
            to_id = fwd.id if fwd else int(_norm_digits(raw))
        except (ValueError, AttributeError):
            return send_styled_message(chat_id, tr(chat_id, "bad_number"))
        if to_id == chat_id:
            return send_styled_message(chat_id, tr(chat_id, "xfer_self"))
        if strong.get_balance(to_id) == 0 and not strong.get_history(to_id, limit=1):
            return send_styled_message(chat_id, tr(chat_id, "xfer_no_receiver"))
        st["v2_xfer"] = {"to": to_id}
        st["step"] = "v2_xfer_amt"
        return send_styled_message(chat_id, tr(chat_id, "ask_xfer_amt", min=TRANSFER_MIN, bal=strong.get_balance(chat_id)))

    if step == "v2_xfer_amt":
        try:
            amount = int(_norm_digits(raw))
            assert amount >= TRANSFER_MIN
        except (ValueError, AssertionError):
            return send_styled_message(chat_id, tr(chat_id, "bad_number"))
        fee = _xfer_fee(amount)
        if strong.get_balance(chat_id) < amount + fee:
            return send_styled_message(chat_id, tr(chat_id, "xfer_insufficient"))
        st["v2_xfer"]["amount"] = amount
        _clear_step(chat_id)
        text = tr(chat_id, "xfer_confirm", to=st["v2_xfer"]["to"], amount=amount, fee=fee, total=amount + fee)
        return send_styled_message(chat_id, text, reply_markup=_kb([_B(tr(chat_id, "confirm"), "v2:xok", "success", "✅"), _B(tr(chat_id, "cancel"), "v2:wallet", "danger", "↪️")]))

    if step == "v2_buy_code" and raw:
        return _buy_code_from_text(message, raw)

    if step == "v2_adm_gift" and chat_id == SUPER_ADMIN_ID:
        return _admin_gift_from_text(chat_id, st, raw)

    _clear_step(chat_id)


# ==========================================================================
# نسخه‌ی ۳: منوی اصلیِ جمع‌وجور (۴ ردیف) + زیرمنوها، خرید کوین با کد تخفیف (تومنی/درصدی)،
# سه نوع کد (کوین هدیه / تخفیف تومنی / تخفیف درصدی) و ویجت‌های Bot API 10.4.
# ==========================================================================


# ── منوی اصلی ───────────────────────────────────────────────────────────
def _main_text(uid, first_name=None):
    name = html.escape(first_name or ("دوست من" if i18n.get_lang(uid) == "fa" else "friend"))
    text = tr(uid, "welcome", name=f'<a href="tg://user?id={uid}">{name}</a>')
    try:
        text += tr(uid, "welcome_stats", bal=strong.get_balance(uid), posts=strong.posts_count(uid),
                   used=strong.emoji_count(uid), cap=strong.get_settings(uid)["emoji_capacity"])
    except Exception as e:
        print(f"⚠️ main text stats: {e}")
    return text


def main_keyboard(user_id):
    """منوی اصلی: فقط ۴-۵ ردیف. بقیه‌ی گزینه‌ها تو زیرمنوهای «ارسال» و «بیشتر» هستن."""
    u = user_id
    markup = InlineKeyboardMarkup()
    markup.add(_B(tr(u, "m_add_group"), url=f"https://t.me/{BOT_USERNAME}?startgroup=botstart", style="success", icon="5397916757333654639"))
    if _miniapp_url():                                     # مینی‌اپ: فقط وقتی آدرسش آماده‌ست (cloudflared / MINIAPP_URL)
        markup.add(_B(tr(u, "m_miniapp"), web_app=_miniapp_url(), style="primary", icon="🖥"))
    markup.row(_B(tr(u, "m_posts"), "v2:posts:0", "primary", "📋"), _B(tr(u, "m_emoji"), "v2:emo:0", "primary", "🔖"))
    markup.row(_B(tr(u, "m_wallet"), "v2:wallet", "primary", "💵"), _B(tr(u, "m_schedule"), "v2:sch:0", "primary", "⏳"))
    markup.row(_B(tr(u, "m_send"), "v2:send", "success", "📢"), _B(tr(u, "m_self"), "v2:self", "primary", "👤"))
    last = [_B(tr(u, "m_more"), "v2:more", "primary", "🗂")]
    if int(u) == SUPER_ADMIN_ID:
        last.append(_B(tr(u, "m_dashboard"), "v2:adm", "danger", "⚠️"))
    markup.row(*last)
    return markup


@_route("send")
def v2_send_hub(call, chat_id, args):
    u = chat_id
    _reset_state(chat_id)
    rows = [[_B(tr(u, "m_send_group"), "type_emoji", "primary", "📢"), _B(tr(u, "m_send_gif"), "type_gif", "danger", "5375464961822695044")]]
    sub = []
    if get_user_managed_groups(u):
        sub.append(_B(tr(u, "m_my_groups"), "my_groups_list", "primary", "5453957997418004470"))
    if get_user_managed_channels(u):
        sub.append(_B(tr(u, "m_my_channels"), "my_channels_list", "primary", "5454113432284446338"))
    rows.append(sub)
    rows.append(_nav(u))
    _ans(call)
    _show(call, tr(u, "hub_send_title"), _kb(*rows))


@_route("more")
def v2_more_hub(call, chat_id, args):
    u = chat_id
    _reset_state(chat_id)
    rows = [_miniapp_row(u)]
    sub = []
    if get_user_managed_groups(u):
        sub.append(_B(tr(u, "m_my_groups"), "my_groups_list", "primary", "5453957997418004470"))
    if get_user_managed_channels(u):
        sub.append(_B(tr(u, "m_my_channels"), "my_channels_list", "primary", "5454113432284446338"))
    rows.append(sub)
    rows.append([_B(tr(u, "m_profile"), "profile_menu", "primary", "👤"), _B(tr(u, "m_invoices"), "my_invoices_menu", "primary", "🧾")])
    rows.append([_B(tr(u, "m_reserve_post"), "reserve_post_start", "success", "✨"), _B(tr(u, "m_help"), "help_root", "primary", "🆔")])
    rows.append([_B(tr(u, "m_connect"), "userbot_login_start", "danger", "🔐")])
    rows.append([_B(tr(u, "m_lang"), "v2:lang", "primary", "😊"), _B(tr(u, "m_tutorial"), "v2:tut:0", "primary", "💎")])
    if int(u) == SUPER_ADMIN_ID:
        rows.append([_B(tr(u, "m_admin"), "admin_panel_open", "danger", "⚠️")])
    rows.append(_nav(u))
    _ans(call)
    _show(call, tr(u, "hub_more_title"), _kb(*rows))


# ── خرید کوین با کد تخفیف ───────────────────────────────────────────────
def _fmt_toman(n):
    return f"{int(n):,}"


def _buy_state(chat_id):
    return (user_states.get(chat_id) or {}).get("v2_buy")


def _buy_disc_text(uid, b):
    if not b.get("code"):
        return ""
    return tr(uid, "buy_disc_line", code=b["code"], discount=_fmt_toman(b["discount"]), final=_fmt_toman(b["price"] - b["discount"]))


def _buy_markup(uid, b):
    rows = [[_B(tr(uid, "buy_btn_remove"), "v2:buyr", "danger", "🗑")] if b.get("code")
            else [_B(tr(uid, "buy_btn_code"), "v2:buyd", "primary", "🔖")],
            [_B(tr(uid, "buy_btn_continue"), "v2:buyc", "success", "💳")],
            [_B(tr(uid, "cancel"), "v2:buyx", "danger", "↪️")]]
    return _kb(*rows)


def _buy_quote_text(uid, b):
    return tr(uid, "buy_quote", coins=b["coins"], price=_fmt_toman(b["price"]), disc=_buy_disc_text(uid, b))


def _buy_offer(chat_id, coins):
    """بعد از واردکردنِ مقدار: قیمت + امکانِ واردکردنِ کد تخفیف (قبل از پرداخت)."""
    coins = int(coins) if float(coins).is_integer() else coins
    st = _reset_state(chat_id)
    st["mode"] = "V2"
    st["v2_buy"] = {"coins": coins, "price": int(round(coins * COIN_PRICE_TOMAN)), "code": None, "discount": 0}
    send_styled_message(chat_id, _buy_quote_text(chat_id, st["v2_buy"]), reply_markup=_buy_markup(chat_id, st["v2_buy"]))


def _buy_show(chat_id, msg_id=None):
    b = _buy_state(chat_id)
    if not b:
        return
    text, markup = _buy_quote_text(chat_id, b), _buy_markup(chat_id, b)
    if msg_id:
        edit_or_send_message(chat_id, msg_id, text, reply_markup=markup)
    else:
        send_styled_message(chat_id, text, reply_markup=markup)


@_route("buyd")
def v2_buy_ask_code(call, chat_id, args):
    if not _buy_state(chat_id):
        _ans(call, tr(chat_id, "buy_expired"), True)
        return
    _set_v2_step(chat_id, "v2_buy_code", call.message.message_id)
    _ans(call)
    _show(call, tr(chat_id, "buy_ask_code"), _kb([_B(tr(chat_id, "cancel"), "v2:buyb", "danger", "↪️")]))


@_route("buyb")
def v2_buy_back(call, chat_id, args):
    _clear_step(chat_id)
    _ans(call)
    _buy_show(chat_id, call.message.message_id)


@_route("buyr")
def v2_buy_remove_code(call, chat_id, args):
    b = _buy_state(chat_id)
    if not b:
        _ans(call, tr(chat_id, "buy_expired"), True)
        return
    b["code"], b["discount"] = None, 0
    _ans(call)
    _buy_show(chat_id, call.message.message_id)


@_route("buyx")
def v2_buy_cancel(call, chat_id, args):
    _reset_state(chat_id)
    _ans(call)
    _show(call, tr(chat_id, "buy_cancelled"), _kb(_nav(chat_id)))


@_route("buyc")
def v2_buy_continue(call, chat_id, args):
    """ساخت فاکتور: کد تخفیف همین‌جا (اتمیک) مصرف می‌شه؛ اگه فاکتور لغو/رد بشه آزاد می‌شه."""
    b = _buy_state(chat_id)
    if not b:
        _ans(call, tr(chat_id, "buy_expired"), True)
        return
    invoice_id = uuid.uuid4().hex[:10]
    price, final, discount, code = b["price"], b["price"], 0, None
    if b.get("code"):
        info, err = strong.discount_redeem(b["code"], chat_id, invoice_id, price)
        if err:                                   # مثلاً تو فاصله‌ی دو کلیک ظرفیتش تموم شده
            b["code"], b["discount"] = None, 0
            _ans(call, re.sub(r"<[^>]+>", "", tr(chat_id, "disc_" + err)), True)
            _buy_show(chat_id, call.message.message_id)
            return
        final, discount, code = info["final"], info["discount"], info["code"]
    invoice = {"id": invoice_id, "user_id": str(chat_id), "coin_amount": b["coins"], "toman_amount": final,
               "original_toman": price, "discount_code": code, "discount_toman": discount,
               "status": "awaiting_receipt", "receipt_path": None, "created_at": time_module.time()}
    try:
        strong.save_invoice(invoice)
    except Exception:
        strong.discount_release(invoice_id)
        raise
    user_states[chat_id] = {"history": [], "mode": "BUY_COIN", "step": "WAITING_FOR_RECEIPT", "invoice_id": invoice_id}
    disc = tr(chat_id, "buy_disc_line", code=code, discount=_fmt_toman(discount), final=_fmt_toman(final)) if code else ""
    _ans(call)
    _show(call, tr(chat_id, "invoice_created", coins=b["coins"], price=_fmt_toman(price), disc=disc,
                   card=CARD_NUMBER, holder=html.escape(CARD_HOLDER_NAME)), None)


def _buy_code_from_text(message, raw):
    chat_id = message.chat.id
    b = _buy_state(chat_id)
    if not b:
        _clear_step(chat_id)
        return send_styled_message(chat_id, tr(chat_id, "buy_expired"))
    info, err = strong.discount_quote(raw, chat_id, b["price"])
    if err:
        return send_styled_message(chat_id, tr(chat_id, "disc_" + err))
    b["code"], b["discount"] = info["code"], info["discount"]
    _clear_step(chat_id)
    _buy_show(chat_id)


# ── ادمین: سه نوع کد (کوین هدیه / تخفیف تومنی / تخفیف درصدی) ─────────────────
def _gift_what(uid, g):
    kind = g.get("kind", "coins")
    if kind == "percent":
        cap = tr(uid, "cap_part", n=_fmt_toman(g["max_discount"])) if g.get("max_discount") else ""
        return tr(uid, "what_percent", n=g["amount"], cap=cap)
    return tr(uid, "what_fixed" if kind == "fixed" else "what_coins", n=_fmt_toman(g["amount"]))


@_route("admg")
def v2_admin_gifts(call, chat_id, args):
    if not _admin_only(call, chat_id):
        return
    gifts = strong.gift_list(15)
    lines = "\n".join(tr(chat_id, "adm_gift_line", code=g["code"], what=_gift_what(chat_id, g), used=g["used"], max=g["max_uses"]) for g in gifts) \
        or tr(chat_id, "adm_gift_none")
    rows = [[_B(f"🗑 {g['code']}", f"v2:admgd:{g['code']}", "danger", raw=True)] for g in gifts[:8]]
    rows.append([_B(tr(chat_id, "adm_gift_new"), "v2:admgn", "success", "✨")])
    rows.append(_nav(chat_id, "v2:adm"))
    _ans(call)
    _show(call, tr(chat_id, "adm_gifts", lines=lines), _kb(*rows))


@_route("admgn")
def v2_admin_gift_new(call, chat_id, args):
    if not _admin_only(call, chat_id):
        return
    if not args:
        rows = [[_B(tr(chat_id, "kind_coins"), "v2:admgn:coins", "primary", "💵")],
                [_B(tr(chat_id, "kind_fixed"), "v2:admgn:fixed", "primary", "🧾")],
                [_B(tr(chat_id, "kind_percent"), "v2:admgn:percent", "primary", "🔖")],
                _nav(chat_id, "v2:admg")]
        _ans(call)
        _show(call, tr(chat_id, "adm_pick_kind"), _kb(*rows))
        return
    kind = args[0] if args[0] in strong.GIFT_KINDS else "coins"
    _set_v2_step(chat_id, "v2_adm_gift", call.message.message_id, v2_kind=kind)
    _ans(call)
    _show(call, tr(chat_id, f"adm_ask_{kind}"), _kb(_nav(chat_id, "v2:admgn")))


def _admin_gift_from_text(chat_id, st, raw):
    kind = st.get("v2_kind", "coins")
    try:
        nums = [int(x) for x in _norm_digits(raw).replace(",", "").split()]
        amount, uses, days = nums[:3]
        cap = nums[3] if kind == "percent" and len(nums) > 3 else None
        assert amount > 0 and uses > 0 and days >= 0 and (kind != "percent" or amount <= 100)
    except (ValueError, AssertionError):
        return send_styled_message(chat_id, tr(chat_id, "bad_number"))
    gift_code = None
    for _ in range(5):
        cand = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        if strong.gift_create(cand, amount, uses, time_module.time() + days * 86400 if days else None, chat_id, kind=kind, max_discount=cap):
            gift_code = cand
            break
    _clear_step(chat_id)
    expiry = _fmt_dt(chat_id, time_module.time() + days * 86400) if days else tr(chat_id, "forever")
    what = _gift_what(chat_id, {"kind": kind, "amount": amount, "max_discount": cap})
    return send_styled_message(chat_id, tr(chat_id, "adm_gift_created", code=gift_code, what=what, max=uses, expiry=expiry),
                               reply_markup=_kb(_nav(chat_id, "v2:admg")))


# ── مینی‌اپ مدیریت (رزروها + ساخت پست با پیش‌نمایش زنده) ───────────────────────
def _miniapp_url():
    """آدرسِ فعلیِ مینی‌اپ؛ همیشه از config خونده می‌شه چون لینکِ cloudflared بعد از استارت مشخص می‌شه."""
    url = config.PUBLIC_URL
    return (url.rstrip("/") + "/") if url else None


def _miniapp_row(uid):
    """ردیفِ دکمه‌ی مینی‌اپ؛ اگه PUBLIC_URL ست نشده باشه خالیه (و تو _kb حذف می‌شه)."""
    url = _miniapp_url()
    return [_B(tr(uid, "m_miniapp"), web_app=url, style="success", icon="🖥")] if url else []


def setup_miniapp_menu():
    """دکمه‌ی «App» کنار فیلد پیام تو پیوی ربات (برای همه‌ی کاربرها). از main.py صدا زده می‌شه."""
    url = _miniapp_url()
    if not url:
        return False
    try:
        bot.set_chat_menu_button(menu_button=telebot.types.MenuButtonWebApp(text="App", web_app=WebAppInfo(url=url)))
        return True
    except Exception as e:
        print(f"⚠️ set_chat_menu_button: {e}")
        return False


@bot.message_handler(commands=["app"])
def open_miniapp(message):
    if message.chat.type != "private" or _is_blocked(message.chat.id):
        return
    uid = message.chat.id
    if not _miniapp_url():
        send_styled_message(uid, tr(uid, "app_unavailable"))
        return
    send_styled_message(uid, tr(uid, "app_intro"), reply_markup=_kb(_miniapp_row(uid), _nav(uid)))


# ── ویجت‌ها (Bot API 10.4 — ۹ نوامبر ۲۰۲۶) ─────────────────────────────────
# sendWidget فقط تو پیوی ربات کار می‌کنه؛ ویجت یه HTML خودکفاست (بدون fetch/input) که با
# TelegramWidget.request(...) از ربات سؤال می‌پرسه. ربات جواب رو با answerWidgetQuery می‌ده و
# با editMessageWidgetData وضعیت (chat_data، حداکثر ۱۰۲۴ بایت) رو عوض می‌کنه.
_WIDGET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
_widget_block_until = 0.0            # تلگرام ویجت رو رد کرد → تا این زمان دکمه‌های ویجت مخفی می‌مونن
_WIDGET_BLOCK_SECONDS = 6 * 3600


def _widgets_ok():
    return bool(WIDGETS_ENABLED) and time_module.time() >= _widget_block_until


def _widget_failed(call, chat_id, e, what):
    """INPUT_MEDIA_WIDGET_NOT_ALLOWED یعنی تلگرام ویجت رو برای این ربات/چت نمی‌پذیره؛ مخفی‌کردنِ دکمه‌ها
    جلوی تلاش و خطای تکراری رو می‌گیره. خطاهای دیگه (مثل حجم یا شبکه) فقط alert می‌دن."""
    global _widget_block_until
    print(f"⚠️ sendWidget({what}): {e}")
    if "INPUT_MEDIA_WIDGET_NOT_ALLOWED" in str(e):
        _widget_block_until = time_module.time() + _WIDGET_BLOCK_SECONDS
        key = "wd_blocked"
    else:
        key = "wd_fail"
    _ans(call, re.sub(r"<[^>]+>", "", tr(chat_id, key)), True)


def _bot_api(method, **params):
    """صدا زدنِ مستقیمِ Bot API (کتابخونه‌ی telebot ممکنه هنوز متدهای 10.4 رو نداشته باشه)."""
    r = requests.post(f"https://api.telegram.org/bot{BOT_TOKEN}/{method}", json=params, timeout=20)
    try:
        j = r.json()
    except ValueError:
        raise RuntimeError(f"{method}: HTTP {r.status_code}")
    if not j.get("ok"):
        raise RuntimeError(f"{method}: {j.get('description')}")
    return j["result"]


def _widget_html(name, labels):
    with open(os.path.join(_WIDGET_DIR, f"widget_{name}.html"), encoding="utf-8") as f:
        return f.read().replace("__L__", json.dumps(labels, ensure_ascii=False))


def _chat_data(obj):
    data = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    if len(data.encode("utf-8")) > 1024:
        raise ValueError("widget chat_data > 1024 bytes")
    return data


def send_widget(chat_id, html_text, chat_data, caption):
    """محدودیت‌های تلگرام: HTML ≤ ۳۲۷۶۸ بایت و بعد از zlib سطح ۹ ≤ ۴۰۹۶ بایت."""
    raw = html_text.encode("utf-8")
    if len(raw) > 32768 or len(zlib.compress(raw, 9)) > 4096:
        raise ValueError("widget html too large")
    return _bot_api("sendWidget", chat_id=chat_id, html=html_text, chat_data=chat_data, allow_queries=True, caption=caption)


def _wallet_labels(uid):
    return {"bal": tr(uid, "wd_balance"), "daily": tr(uid, "wd_daily"), "st": tr(uid, "wd_streak"), "ref": tr(uid, "wd_refresh"),
            "wait": "⏳", "none": tr(uid, "wd_none"),
            "ty": {k: re.sub(r"<[^>]+>", "", tr(uid, "tx_" + k)) for k in
                   ("buy", "welcome", "inline_send", "emoji_upgrade", "transfer_in", "transfer_out", "transfer_fee", "gift", "daily", "refund", "admin_adjust", "spend")}}


def _wallet_chat_data(uid, flash=""):
    s = strong.get_settings(uid)
    left = max(0, int(s["last_daily"] + 20 * 3600 - time_module.time())) if s["last_daily"] else 0
    tx = [[r["amount"], r["type"], _fmt_dt(uid, r["created_at"])] for r in strong.get_history(uid, limit=3)]
    return _chat_data({"b": strong.get_balance(uid), "s": s["streak"], "w": left, "t": tx, "m": flash})


def _stats_labels(uid):
    return {"ref": tr(uid, "wd_refresh"), "none": tr(uid, "wd_none")}


def _post_stats_chat_data(uid, code):
    p = strong.post_get(code, include_expired=True)
    if not p or int(p["owner_id"]) != int(uid):
        return None
    flat = _flat_buttons(p["buttons"])
    stats = strong.click_stats(code)
    kv = [[tr(uid, "wd_views"), p["views"]]]
    bars = []
    for i, st in sorted(stats.items())[:5]:
        label = re.sub(r"\s+", " ", str(flat[i].get("text", i)) if i < len(flat) else str(i))[:14]
        kv.append([f"{tr(uid, 'wd_clicks')} · {label}", f"{st['total']} ({st['unique']})"])
        bars.append(st["total"])
    return _chat_data({"t": p.get("title") or code, "k": kv, "v": bars, "r": f"s:r:{code}"})


def _admin_chat_data():
    st = strong.dashboard_stats()
    uid = SUPER_ADMIN_ID
    kv = [["👥", st["users"]], ["🪙", st["coins_total"]], ["📤", st["inline_today"]], ["🧾", st["pending_invoices"]],
          ["📋", st["posts"]], ["📅", st["schedules_pending"]]]
    return _chat_data({"t": re.sub(r"<[^>]+>", "", tr(uid, "wd_caption_admin")), "k": kv, "v": st["last7_inline"], "r": "a:r"})


def _handle_widget_query(q):
    """به ضربه‌ی کاربر رو ویجت جواب می‌ده. جواب فوری، بعد به‌روزرسانیِ وضعیتِ ویجت."""
    qid = q.get("id")
    uid = (q.get("from") or {}).get("id")
    chat_id = (q.get("chat") or {}).get("id")
    mid = q.get("message_id")
    data = q.get("data") or ""
    try:
        if not qid or not uid:
            return
        reply, new_data = "", None
        if (q.get("type") or {}).get("type") not in (None, "data"):
            pass                                                       # مثلاً sign/transaction: فقط جواب خالی
        elif data in ("w:daily", "w:refresh"):
            if data == "w:daily":
                strong.ensure_wallet(uid)
                amount, info = strong.daily_claim(uid)
                reply = tr(uid, "wd_daily_ok", amount=amount, streak=info) if amount is not None else \
                    tr(uid, "wd_daily_wait", h=info // 3600, m=(info % 3600) // 60)
            new_data = _wallet_chat_data(uid, reply)
        elif data.startswith("s:r:"):
            new_data = _post_stats_chat_data(uid, data[4:])
        elif data == "a:r" and uid == SUPER_ADMIN_ID:
            new_data = _admin_chat_data()
        _bot_api("answerWidgetQuery", widget_query_id=qid, **({"data": reply[:512]} if reply else {}))
        if new_data and chat_id and mid:
            _bot_api("editMessageWidgetData", chat_id=chat_id, message_id=mid, chat_data=new_data)
    except Exception as e:
        print(f"❌ [widget_query] {type(e).__name__}: {e}")
        try:
            _bot_api("answerWidgetQuery", widget_query_id=qid)
        except Exception:
            pass


def _dispatch_widget_update(u):
    q = u.get("widget_query") or u.get("shared_widget_query")
    if q:
        _handle_widget_query(q)


def _install_widget_updates():
    """pyTelegramBotAPI آپدیت‌های ناشناس (widget_query) رو دور می‌ریزه؛ پس خروجیِ خامِ getUpdates رو قبل از
    کتابخونه می‌خونیم و فقط widget_queryها رو جدا می‌کنیم (بقیه‌ی مسیر دست‌نخورده)."""
    try:
        from telebot import apihelper
        orig = apihelper.get_updates

        def get_updates(*a, **k):
            updates = orig(*a, **k)
            for u in (updates or []):
                if isinstance(u, dict) and ("widget_query" in u or "shared_widget_query" in u):
                    threading.Thread(target=_dispatch_widget_update, args=(u,), daemon=True).start()
            return updates

        apihelper.get_updates = get_updates
        return True
    except Exception as e:
        print(f"⚠️ widget updates hook: {e}")
        return False


_install_widget_updates()


@_route("wcard")
def v2_wallet_widget(call, chat_id, args):
    strong.ensure_wallet(chat_id)
    try:
        send_widget(chat_id, _widget_html("wallet", _wallet_labels(chat_id)), _wallet_chat_data(chat_id),
                    re.sub(r"<[^>]+>", "", tr(chat_id, "wd_caption_wallet", bal=strong.get_balance(chat_id))))
        _ans(call)
    except Exception as e:
        _widget_failed(call, chat_id, e, "wallet")


@_route("pwid")
def v2_post_widget(call, chat_id, args):
    code = args[0]
    data = _post_stats_chat_data(chat_id, code)
    if data is None:
        _ans(call, tr(chat_id, "not_found"), True)
        return
    try:
        send_widget(chat_id, _widget_html("stats", _stats_labels(chat_id)), data, tr(chat_id, "wd_caption_stats", code=code))
        _ans(call)
    except Exception as e:
        _widget_failed(call, chat_id, e, "stats")


@_route("awid")
def v2_admin_widget(call, chat_id, args):
    if not _admin_only(call, chat_id):
        return
    try:
        send_widget(chat_id, _widget_html("stats", _stats_labels(chat_id)), _admin_chat_data(), re.sub(r"<[^>]+>", "", tr(chat_id, "wd_caption_admin")))
        _ans(call)
    except Exception as e:
        _widget_failed(call, chat_id, e, "admin")


@bot.callback_query_handler(func=lambda call: True)
def callback_listener(call):
    chat_id = call.message.chat.id
    if call.message.chat.type in ['group', 'supergroup']:
        return

    if _is_blocked(chat_id):
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        return

    if chat_id not in user_states:
        user_states[chat_id] = {"history": []}
    
    state_data = user_states[chat_id]
    state_data["last_bot_msg_id"] = call.message.message_id
    step = state_data.get("step")

    if call.data == "nav_all_back":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        user_states[chat_id] = {}
        welcome_text = _main_text(chat_id, call.from_user.first_name)
        edit_or_send_message(chat_id, call.message.message_id, welcome_text, reply_markup=main_keyboard(chat_id))
        return

    elif call.data == "nav_back":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        history = state_data.get("history", [])
        if len(history) > 1:
            history.pop()  
            prev_step = history[-1]  
            state_data["step"] = prev_step
            
            if prev_step == "WAITING_FOR_CONTENT":
                edit_or_send_message(chat_id, call.message.message_id, "لطفاً متن یا رسانه (تصویر، ویدیو، صوت) مورد نظر خود را ارسال کنید؛ می‌توانید چند رسانه را هم‌زمان (آلبوم) ارسال کنید ✉️:", reply_markup=navigation_keyboard())
            elif prev_step == "WAITING_FOR_GIF":
                edit_or_send_message(chat_id, call.message.message_id, "لطفاً فایل گیف (GIF) مورد نظر را ارسال کنید 🎬:", reply_markup=navigation_keyboard())
            elif prev_step == "WAITING_FOR_CAPTION_CHOICE":
                edit_or_send_message(chat_id, call.message.message_id, "آیا تمایل دارید کپشن اختصاصی ثبت کنید؟ 📝", reply_markup=yes_no_keyboard_with_nav())
            elif prev_step == "WAITING_FOR_CAPTION":
                edit_or_send_message(chat_id, call.message.message_id, "کپشن دلخواه خود را تایپ و ارسال کنید 📝:", reply_markup=navigation_keyboard())
            elif prev_step == "WAITING_FOR_SENDER_NAME_CHOICE":
                edit_or_send_message(chat_id, call.message.message_id, "آیا مایلید نام شما به عنوان فرستنده زیر پیام درج شود؟ 👑", reply_markup=yes_no_keyboard_with_nav())
            elif prev_step == "WAITING_FOR_SENDER_EMOJI_CHOICE":
                edit_or_send_message(chat_id, call.message.message_id, "یک ایموجی برای نمایش در کنار نام خود بفرستید (در صورت عدم تمایل عدد 0 را بفرستید) 🥰:", reply_markup=navigation_keyboard())
            elif prev_step == "WAITING_FOR_REPLY_CHOICE":
                edit_or_send_message(chat_id, call.message.message_id, "آیا می‌خواهید روی پیام خاصی ریپلای شود؟ ↩️", reply_markup=yes_no_keyboard_with_nav())
            elif prev_step == "WAITING_FOR_REPLY_LINK":
                edit_or_send_message(chat_id, call.message.message_id, "لطفاً لینک پیام مورد نظر را ارسال کنید 🔗:", reply_markup=navigation_keyboard())
            elif prev_step == "WAITING_FOR_TARGET_ID":
                edit_or_send_message(chat_id, call.message.message_id, "لطفاً شناسه عددی گروه مقصد را وارد کنید 🎯:", reply_markup=navigation_keyboard())
            else:
                user_states[chat_id] = {}
                edit_or_send_message(chat_id, call.message.message_id, "منوی اصلی خدمات. گزینه مورد نظر را انتخاب نمایید 👇", reply_markup=main_keyboard(chat_id))
        else:
            user_states[chat_id] = {}
            edit_or_send_message(chat_id, call.message.message_id, "منوی اصلی خدمات. گزینه مورد نظر را انتخاب نمایید 👇", reply_markup=main_keyboard(chat_id))
        return

    # دکمه‌های پنلِ ساخت پست وقتی state درون‌حافظه‌ای گم شده (مثلاً ری‌استارتِ ربات)
    # باید یه پیش‌نویسِ تازه بسازن؛ وگرنه set_step یه state بدونِ mode می‌ساخت و
    # متنی که کاربر می‌فرسته به‌جای ثبت‌شدن تو پست، به هندلرِ پیش‌نمایش می‌رسید و
    # عیناً برگردونده می‌شد.
    if call.data.startswith("rpost_") and (user_states.get(chat_id) or {}).get("mode") != "RESERVE_POST":
        user_states[chat_id] = {
            "mode": "RESERVE_POST",
            "history": [],
            "last_bot_msg_id": call.message.message_id,
            "draft_text": "",
            "draft_media": None,
            "draft_button_rows": [],
        }
        try:
            bot.answer_callback_query(call.id, "نشستِ قبلی منقضی شده بود؛ پیش‌نویسِ پست از اول ساخته شد ♻️", show_alert=True)
        except Exception:
            pass
        body, markup = build_post_builder_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)
        return

    if call.data == "buy_coin_start":
        user_states[chat_id] = {"mode": "BUY_COIN", "step": "WAITING_FOR_COIN_AMOUNT", "last_bot_msg_id": call.message.message_id}
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        msg = f"🛒 مقدار اموجی کوین مورد نظر برای خرید را وارد کنید (حداقل {MIN_PURCHASE_COINS}):"
        edit_or_send_message(chat_id, call.message.message_id, msg, reply_markup=navigation_keyboard())

    elif call.data == "type_emoji":
        user_states[chat_id] = {
            "mode": "BULK_SEND", 
            "history": [],
            "show_sender": False,
            "sender_emoji": "",
            "custom_caption": None,
            "reply_to_msg_id": None,
            "last_bot_msg_id": call.message.message_id
        }
        set_step(chat_id, "WAITING_FOR_CONTENT", call.message.message_id)
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        msg = "لطفاً متن یا رسانه (تصویر، ویدیو، صوت) مورد نظر خود را ارسال کنید؛ می‌توانید چند رسانه را هم‌زمان (آلبوم) ارسال کنید ✉️:"
        edit_or_send_message(chat_id, call.message.message_id, msg, reply_markup=navigation_keyboard())

    elif call.data == "reserve_emoji_start":
        user_states[chat_id] = {"history": []}
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        text, markup = build_emoji_reservation_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)

    elif call.data == "reserve_emoji_add_start":
        capacity = get_user_emoji_capacity(chat_id)
        used = len(_get_user_emoji_data(chat_id).get("emojis", {}))
        if used >= capacity:
            try:
                bot.answer_callback_query(call.id, "ظرفیت شما پر شده؛ برای افزودن بیشتر ابتدا ظرفیت را ارتقا دهید ⛔", show_alert=True)
            except Exception:
                pass
            return
        user_states[chat_id] = {
            "mode": "RESERVE_EMOJI",
            "history": [],
            "last_bot_msg_id": call.message.message_id
        }
        set_step(chat_id, "WAITING_FOR_NORMAL_EMOJI", call.message.message_id)
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        msg = "لطفاً یک اموجی معمولی که می‌خواهید رزرو کنید را ارسال کنید 😊:"
        edit_or_send_message(chat_id, call.message.message_id, msg, reply_markup=navigation_keyboard())

    elif call.data.startswith("reserve_emoji_manage_"):
        slot_id = call.data.replace("reserve_emoji_manage_", "")
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        text, markup = build_emoji_manage_panel(chat_id, slot_id)
        if not text:
            text, markup = build_emoji_reservation_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)

    elif call.data.startswith("reserve_emoji_edit_char_"):
        slot_id = call.data.replace("reserve_emoji_edit_char_", "")
        user_states[chat_id] = {
            "mode": "RESERVE_EMOJI",
            "history": [],
            "edit_slot_id": slot_id,
            "last_bot_msg_id": call.message.message_id
        }
        set_step(chat_id, "WAITING_FOR_EDIT_EMOJI", call.message.message_id)
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        edit_or_send_message(chat_id, call.message.message_id, "اموجی معمولی جدید را ارسال کنید 😊:", reply_markup=navigation_keyboard())

    elif call.data.startswith("reserve_emoji_edit_id_"):
        slot_id = call.data.replace("reserve_emoji_edit_id_", "")
        user_states[chat_id] = {
            "mode": "RESERVE_EMOJI",
            "history": [],
            "edit_slot_id": slot_id,
            "last_bot_msg_id": call.message.message_id
        }
        set_step(chat_id, "WAITING_FOR_EDIT_EMOJI_ID", call.message.message_id)
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        edit_or_send_message(chat_id, call.message.message_id, "آی‌دی اموجی پرمیوم جدید را ارسال کنید 🆔:", reply_markup=navigation_keyboard())

    elif call.data.startswith("reserve_emoji_delete_"):
        slot_id = call.data.replace("reserve_emoji_delete_", "")
        delete_user_emoji_reservation(chat_id, slot_id)
        try:
            bot.answer_callback_query(call.id, "حذف شد ✅")
        except Exception:
            pass
        text, markup = build_emoji_reservation_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)

    elif call.data.startswith("reserve_emoji_page_"):
        try:
            page = int(call.data.replace("reserve_emoji_page_", ""))
        except ValueError:
            page = 0
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        text, markup = build_emoji_reservation_panel(chat_id, page=page)
        edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)

    elif call.data == "reserve_emoji_upgrade":
        success, info = upgrade_user_emoji_capacity(chat_id)
        if success:
            try:
                bot.answer_callback_query(call.id, f"ظرفیت با موفقیت ارتقا یافت ✅ ({info} کوین کسر شد)", show_alert=True)
            except Exception:
                pass
        else:
            if info == "max":
                alert_msg = "شما به حداکثر ظرفیت رسیده‌اید ⛔"
            else:
                balance = _get_coin_balance(chat_id)
                alert_msg = f"موجودی کوین کافی نیست ⛔\nهزینه‌ی ارتقا: {info} کوین\nموجودی شما: {balance} کوین"
            try:
                bot.answer_callback_query(call.id, alert_msg, show_alert=True)
            except Exception:
                pass
        text, markup = build_emoji_reservation_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)

    elif call.data == "reserve_post_start":
        user_states[chat_id] = {
            "mode": "RESERVE_POST",
            "history": [],
            "last_bot_msg_id": call.message.message_id,
            "draft_text": "",
            "draft_media": None,
            "draft_button_rows": [],
        }
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        body, markup = build_post_builder_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data == "userbot_login_start":
        if not _TELETHON_AVAILABLE:
            try:
                bot.answer_callback_query(call.id, "کتابخونه‌ی telethon روی سرور نصب نیست ❌", show_alert=True)
            except Exception:
                pass
            return
        user_states[chat_id] = {
            "mode": "USERBOT_LOGIN",
            "history": [],
            "last_bot_msg_id": call.message.message_id,
        }
        set_step(chat_id, "WAITING_FOR_PHONE", call.message.message_id)
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        msg = "شماره‌تلفن اکانت تلگرامت رو با فرمت بین‌المللی بفرست (مثلاً +989123456789) 📱:"
        edit_or_send_message(chat_id, call.message.message_id, msg, reply_markup=navigation_keyboard())

    elif call.data.startswith("otpkey_"):
        state_data = user_states.get(chat_id)
        if not state_data or state_data.get("mode") != "USERBOT_LOGIN" or state_data.get("step") != "WAITING_FOR_CODE":
            try:
                bot.answer_callback_query(call.id)
            except Exception:
                pass
            return

        action = call.data.replace("otpkey_", "")
        entered = state_data.get("entered_code", "")

        if action == "del":
            entered = entered[:-1]
            state_data["entered_code"] = entered
            try:
                bot.answer_callback_query(call.id)
            except Exception:
                pass
            text, markup = build_numeric_keypad(entered, "کدی که تلگرام الان برات فرستاد رو با کیبورد زیر وارد کن 🔢:")
            edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)

        elif action == "confirm":
            if not entered:
                try:
                    bot.answer_callback_query(call.id, "هنوز هیچ رقمی وارد نکردی ❌", show_alert=True)
                except Exception:
                    pass
                return
            try:
                bot.answer_callback_query(call.id)
            except Exception:
                pass
            login_data = _userbot_login_state.get(chat_id)
            if not login_data:
                edit_or_send_message(chat_id, call.message.message_id, "جلسه‌ی لاگین منقضی شده؛ از اول شروع کن ❌", reply_markup=main_keyboard(chat_id))
                user_states[chat_id] = {}
                return
            try:
                run_userbot_coro(_userbot_sign_in_code(login_data["client"], login_data["phone"], entered, login_data["phone_code_hash"]))
            except SessionPasswordNeededError:
                set_step(chat_id, "WAITING_FOR_PASSWORD", call.message.message_id)
                edit_or_send_message(chat_id, call.message.message_id, "اکانتت تایید دومرحله‌ای داره؛ رمز عبورش رو بفرست 🔒:", reply_markup=navigation_keyboard())
                return
            except Exception as e:
                state_data["entered_code"] = ""
                text, markup = build_numeric_keypad("", f"کد اشتباهه یا منقضی شده ❌:\n<code>{e}</code>\nدوباره وارد کن:")
                edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)
                return
            user_states[chat_id] = {}
            logged_in_client = login_data["client"]
            _userbot_login_state.pop(chat_id, None)
            finalize_login_session(logged_in_client, chat_id)
            edit_or_send_message(chat_id, call.message.message_id, "✅ اکانتت با موفقیت وصل شد و شنودگر خودکار فعال شد!", reply_markup=main_keyboard(chat_id))

        else:
            # رقم ۰ تا ۹
            if len(entered) < 10:
                entered += action
                state_data["entered_code"] = entered
            try:
                bot.answer_callback_query(call.id)
            except Exception:
                pass
            text, markup = build_numeric_keypad(entered, "کدی که تلگرام الان برات فرستاد رو با کیبورد زیر وارد کن 🔢:")
            edit_or_send_message(chat_id, call.message.message_id, text, reply_markup=markup)

    elif call.data == "rpost_menu_back":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        state_data = user_states.get(chat_id) or {}
        state_data.pop("step", None)
        body, markup = build_post_builder_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data == "rpost_menu_text":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        body, markup = build_post_text_panel(chat_id)
        edit_or_send_raw_html(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data == "rpost_text_edit":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        set_step(chat_id, "WAITING_FOR_DRAFT_TEXT", call.message.message_id)
        edit_or_send_message(chat_id, call.message.message_id, "متن پست رو بفرست ✏️:", reply_markup=navigation_keyboard())

    elif call.data == "rpost_menu_media":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        body, markup = build_post_media_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data == "rpost_media_edit":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        set_step(chat_id, "WAITING_FOR_DRAFT_MEDIA", call.message.message_id)
        edit_or_send_message(chat_id, call.message.message_id, "رسانه‌ی (عکس/ویدیو/فایل/گیف) پست رو بفرست 🖼:", reply_markup=navigation_keyboard())

    elif call.data == "rpost_media_delete":
        try:
            bot.answer_callback_query(call.id, "رسانه حذف شد ✅")
        except Exception:
            pass
        user_states[chat_id]["draft_media"] = None
        body, markup = build_post_media_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data == "rpost_menu_buttons":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        body, markup = build_post_buttons_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data == "rpost_btn_add":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        set_step(chat_id, "WAITING_FOR_BTN_TEXT", call.message.message_id)
        edit_or_send_message(chat_id, call.message.message_id, "متن دکمه رو بفرست ✏️:", reply_markup=navigation_keyboard())

    elif call.data.startswith("rpost_btn_del_"):
        parts = call.data.replace("rpost_btn_del_", "").split("_")
        try:
            r_idx, c_idx = int(parts[0]), int(parts[1])
        except (ValueError, IndexError):
            r_idx = c_idx = None
        rows = user_states.get(chat_id, {}).get("draft_button_rows", [])
        if r_idx is not None and 0 <= r_idx < len(rows) and 0 <= c_idx < len(rows[r_idx]):
            rows[r_idx].pop(c_idx)
            if not rows[r_idx]:
                rows.pop(r_idx)
        try:
            bot.answer_callback_query(call.id, "دکمه حذف شد ✅")
        except Exception:
            pass
        body, markup = build_post_buttons_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data.startswith("rpost_btype_"):
        btype = call.data.replace("rpost_btype_", "")
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        if btype not in POST_BUTTON_TYPES or "pending_btn_text" not in user_states.get(chat_id, {}):
            return
        user_states[chat_id]["pending_btn_type"] = btype
        set_step(chat_id, "WAITING_FOR_BTN_STYLE", call.message.message_id)
        edit_or_send_message(chat_id, call.message.message_id, "استایل دکمه رو انتخاب کن 🎨:", reply_markup=_btn_style_markup())

    elif call.data in ("rpost_style_success", "rpost_style_primary", "rpost_style_danger"):
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        style = call.data.replace("rpost_style_", "")
        user_states[chat_id]["pending_btn_style"] = style
        set_step(chat_id, "WAITING_FOR_BTN_ICON", call.message.message_id)
        msg = "اگه می‌خوای دکمه آیکون (آی‌دی اموجی پرمیوم) داشته باشه بفرست؛ وگرنه عدد 0 رو بفرست 🆔:"
        edit_or_send_message(chat_id, call.message.message_id, msg, reply_markup=navigation_keyboard())

    elif call.data == "rpost_row_same":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        state_data = user_states.get(chat_id, {})
        rows = state_data.setdefault("draft_button_rows", [])
        new_btn = state_data.pop("pending_new_btn", None)
        if new_btn:
            if rows:
                rows[-1].append(new_btn)
            else:
                rows.append([new_btn])
        state_data.pop("step", None)
        body, markup = build_post_buttons_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data == "rpost_row_new":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        state_data = user_states.get(chat_id, {})
        rows = state_data.setdefault("draft_button_rows", [])
        new_btn = state_data.pop("pending_new_btn", None)
        if new_btn:
            rows.append([new_btn])
        state_data.pop("step", None)
        body, markup = build_post_buttons_panel(chat_id)
        edit_or_send_message(chat_id, call.message.message_id, body, reply_markup=markup)

    elif call.data == "rpost_menu_preview":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        state_data = user_states.get(chat_id, {})
        draft_post = {
            "owner_id": chat_id,
            "text": state_data.get("draft_text", ""),
            "media": state_data.get("draft_media"),
            "buttons": state_data.get("draft_button_rows", []),
        }
        send_saved_post(chat_id, draft_post)
        body, markup = build_post_builder_panel(chat_id)
        sent = send_styled_message(chat_id, body, reply_markup=markup)
        if sent:
            state_data["last_bot_msg_id"] = sent.message_id

    elif call.data == "rpost_menu_finish":
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        _finalize_reserve_post(chat_id, call.message.message_id)

    elif call.data.startswith("get_saved_post_"):
        code = call.data.replace("get_saved_post_", "")
        post = get_saved_post(code)
        if not post:
            try:
                bot.answer_callback_query(call.id, "این پست دیگه در دسترس نیست ❌", show_alert=True)
            except Exception:
                pass
            return
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        send_saved_post(chat_id, post)

    elif call.data == "type_gif":
        user_states[chat_id] = {
            "mode": "GIF", 
            "history": [],
            "show_sender": False,
            "sender_emoji": "",
            "custom_caption": None,
            "reply_to_msg_id": None,
            "last_bot_msg_id": call.message.message_id
        }
        set_step(chat_id, "WAITING_FOR_GIF", call.message.message_id)
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        msg = "لطفاً فایل گیف (GIF) مورد نظر را ارسال کنید 🎬:"
        edit_or_send_message(chat_id, call.message.message_id, msg, reply_markup=navigation_keyboard())

    elif call.data in ["yes", "no"]:
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        if step == "WAITING_FOR_CAPTION_CHOICE":
            if call.data == "yes":
                set_step(chat_id, "WAITING_FOR_CAPTION", call.message.message_id)
                edit_or_send_message(chat_id, call.message.message_id, "کپشن دلخواه خود را تایپ و ارسال کنید 📝:", reply_markup=navigation_keyboard())
            else:
                user_states[chat_id]["custom_caption"] = None
                set_step(chat_id, "WAITING_FOR_SENDER_NAME_CHOICE", call.message.message_id)
                edit_or_send_message(chat_id, call.message.message_id, "آیا مایلید نام شما به عنوان فرستنده زیر پیام درج شود؟ 👑", reply_markup=yes_no_keyboard_with_nav())
        elif step == "WAITING_FOR_SENDER_NAME_CHOICE":
            if call.data == "yes":
                user_states[chat_id]["show_sender"] = True
                set_step(chat_id, "WAITING_FOR_SENDER_EMOJI_CHOICE", call.message.message_id)
                edit_or_send_message(chat_id, call.message.message_id, "یک ایموجی برای نمایش در کنار نام خود بفرستید (در صورت عدم تمایل عدد 0 را بفرستید) 🥰:", reply_markup=navigation_keyboard())
            else:
                user_states[chat_id]["show_sender"] = False
                user_states[chat_id]["sender_emoji"] = ""
                set_step(chat_id, "WAITING_FOR_REPLY_CHOICE", call.message.message_id)
                edit_or_send_message(chat_id, call.message.message_id, "آیا می‌خواهید روی پیام خاصی ریپلای شود؟ ↩️", reply_markup=yes_no_keyboard_with_nav())
        elif step == "WAITING_FOR_REPLY_CHOICE":
            if call.data == "yes":
                set_step(chat_id, "WAITING_FOR_REPLY_LINK", call.message.message_id)
                edit_or_send_message(chat_id, call.message.message_id, "لطفاً لینک پیام مورد نظر را ارسال کنید 🔗:", reply_markup=navigation_keyboard())
            else:
                user_states[chat_id]["reply_to_msg_id"] = None
                set_step(chat_id, "WAITING_FOR_TARGET_ID", call.message.message_id)
                edit_or_send_message(chat_id, call.message.message_id, "لطفاً شناسه عددی گروه مقصد را وارد کنید 🎯:", reply_markup=navigation_keyboard())

# ==========================================================================
# ابزار سریع تست اموجی پرمیوم: هر متنی که با یه آی‌دی عددی داخل [ ] تموم بشه
# (با یا بدون منشن @ربات جلوش، برای وقتی داخل گروه صداش می‌زنی)، همون متن رو
# با اموجی پرمیومِ همون آی‌دی برمی‌گردونه. مثلاً:
#   باشه بابا [1252726373672662]
# یا داخل گروه:
#   @BotUsername باشه بابا [1252726373672662]
# این‌جوری بدون دست‌زدن به کد، هر آی‌دی اموجی رو می‌شه سریع پیش‌نمایش گرفت.
# ==========================================================================
EMOJI_ID_PREVIEW_PATTERN = re.compile(r'\[(\d{5,25})\]')


def _has_no_active_flow(m):
    # اگه کاربر وسط یه فرآیند دیگه‌ست (مثلاً ارسال پیام به گروه، خرید کوین و...)
    # این قابلیتِ «تست سریع» نباید متنش رو بقاپه؛ باید بذاره هندلر اصلی
    # (handle_all_messages) اون رو به‌عنوان بخشی از همون فرآیند پردازش کنه.
    state = user_states.get(m.chat.id) or {}
    # اگه mode گم شده ولی هنوز یه step باز مونده (مثلاً بعد از ری‌استارت ربات و زدنِ
    # دکمه‌ی یه پنلِ قدیمی)، باز هم نباید پیامِ کاربر رو بقاپیم و نتیجه رو
    # برگردونیم؛ اون پیام متعلقِ همون فرآیندِ نیمه‌کاره‌ست.
    return not state.get("mode") and not state.get("step")

def _should_echo_emoji_preview(m):
    """پیش‌نمایشِ [آیدی] فقط تو پیوی ربات، یا تو گروه وقتی صریحاً ربات منشن شده.
    وگرنه هر پیامی که کاربر تو گروه با [آیدی] می‌نویسه (که سلف خودش هندل می‌کنه)
    ربات هم دوباره می‌فرستاد و پیام دوتا می‌شد."""
    if not m.text or not EMOJI_ID_PREVIEW_PATTERN.search(m.text):
        return False
    if m.chat.type != "private" and not m.text.lstrip().lower().startswith("@" + BOT_USERNAME.lower()):
        return False
    return _has_no_active_flow(m) and not _is_blocked(m.chat.id)


@bot.message_handler(func=_should_echo_emoji_preview, content_types=['text'])
def handle_emoji_id_preview(message):
    text = message.text
    # اگه پیام با منشن ربات شروع شده (توی گروه)، اون تیکه رو نادیده بگیر
    text = re.sub(r'^@\S+\s+', '', text)

    fallback_char = "🔥"

    def _replace(m):
        emoji_id = m.group(1)
        return f'<tg-emoji emoji-id="{emoji_id}">{fallback_char}</tg-emoji>'

    final_text = EMOJI_ID_PREVIEW_PATTERN.sub(_replace, text)

    try:
        bot.send_message(message.chat.id, final_text, parse_mode="HTML")
    except Exception as e:
        # اگه حتی یکی از آی‌دی‌ها نامعتبر باشه، تلگرام کل پیام رو رد می‌کنه؛
        # پس خطای واقعی رو مستقیم نشون می‌دیم تا بفهمی کدوم آی‌دی مشکل داره
        bot.reply_to(message, f"❌ حداقل یکی از آی‌دی‌های اموجی معتبر نیست یا پیدا نشد.\n\nخطا: {e}")


# ==========================================================================
# حالت اینلاین (Inline Mode): تو هر چتی (نه فقط PV خود ربات) بنویس
#   @Permium_emoji_LKbot متن دلخواه [1252726373672662]
# یه گزینه به اسم «فرستادن پیام» ظاهر می‌شه؛ روش که بزنی، همون متن با اموجی
# پرمیومِ واقعی (نه فقط یه ایموجی معمولی) مستقیم توی همون چت فرستاده می‌شه.
#
# نکته‌ی فنی مهم (طبق مستندات رسمی تلگرام): اموجی پرمیوم داخل خودِ نتیجه‌ی
# اولیه‌ی inline قابل‌استفاده نیست — باید اول پیام با اموجی معمولی (فال‌بک)
# فرستاده بشه، بعد همون پیام ویرایش بشه تا اموجی پرمیوم واقعی جایگزینش بشه.
#
# راه‌حل قابل‌اطمینان: به‌جای تکیه‌ی صرف به رویداد chosen_inline_result (که
# غیرقابل‌اعتماده، چون ۱) فقط با فعال‌کردن /setinlinefeedback از BotFather
# کار می‌کنه و ۲) طبق مستندات، inline_message_id فقط وقتی برگردونده می‌شه که
# نتیجه از قبل یه کیبورد اینلاین (دکمه) داشته باشه)، یه دکمه‌ی «فعال‌سازی
# اموجی پرمیوم» به خودِ نتیجه اضافه می‌کنیم. با زدن این دکمه، از طریق
# callback_query (که همیشه و بدون هیچ تنظیم اضافه‌ای کار می‌کنه) پیام
# ویرایش و اموجی واقعی جایگزین می‌شه. رویداد chosen_inline_result هم
# به‌عنوان یه لایه‌ی خودکارِ اضافه (در صورت فعال بودن feedback) نگه داشته
# شده، ولی دیگه چیزی به کارکردنِ اصلیِ قابلیت بند نیست.
#
# تنها تنظیم لازم (یک‌بار، از طریق BotFather):
#   /setinline → فعال‌سازی خودِ حالت اینلاین
# ==========================================================================
_inline_emoji_cache = {}  # {short_id: {"final_text": ..., "user_id": ..., "charged": bool}} — حافظه‌ی موقت
# نکته: مقدار INLINE_SEND_COIN_COST بالاتر تو فایل (کنار بقیه‌ی ثابت‌های
# ظرفیت اموجی) تعریف شده تا قبل از HELP_SECTIONS در دسترس باشه.








_HTML_TAG_PATTERN = re.compile(r'<\s*/?\s*[a-zA-Z]+[^<>]*>')
_MARKDOWN_MARKER_PATTERN = re.compile(r'[*_`~]')


def _detect_parse_mode(text):
    """اگه تگ HTML توی متن باشه، همون رو در اولویت می‌ذاریم (چون دقیق‌تر
    قابل‌تشخیصه)؛ وگرنه اگه نشانه‌ی مارک‌داون (* _ ` ~) باشه، MarkdownV2؛
    وگرنه HTML به‌عنوان پیش‌فرضِ بی‌ضرر (چون متن فرمت خاصی نداره)."""
    if _HTML_TAG_PATTERN.search(text):
        return "HTML"
    if _MARKDOWN_MARKER_PATTERN.search(text):
        return "MarkdownV2"
    return "HTML"


def _build_final_and_plain(query_text, user_id=None):
    fallback_char = "🔥"
    parse_mode = _detect_parse_mode(query_text)

    if parse_mode == "MarkdownV2":
        def _replace(m):
            return f'![{fallback_char}](tg://emoji?id={m.group(1)})'
    else:
        def _replace(m):
            return f'<tg-emoji emoji-id="{m.group(1)}">{fallback_char}</tg-emoji>'

    final_text = EMOJI_ID_PREVIEW_PATTERN.sub(_replace, query_text)
    plain_text = EMOJI_ID_PREVIEW_PATTERN.sub(fallback_char, query_text)

    # اموجی‌های رزروشده‌ی همین کاربر: هر جا اموجی معمولیِ رزروشده تو متنش
    # باشه، خودکار با اموجی پرمیوم اختصاصی‌اش جایگزین می‌شه (بدون نیاز به [آیدی])
    for emoji_char, emoji_id in get_user_emoji_reservations(user_id).items():
        if emoji_char in final_text:
            if parse_mode == "MarkdownV2":
                final_text = final_text.replace(emoji_char, f'![{emoji_char}](tg://emoji?id={emoji_id})')
            else:
                final_text = final_text.replace(emoji_char, f'<tg-emoji emoji-id="{emoji_id}">{emoji_char}</tg-emoji>')

    return final_text, plain_text, parse_mode


@bot.inline_handler(func=lambda query: True)
def handle_inline_query(inline_query):
    query_text = inline_query.query or ""

    # اگه متن دقیقاً یه کدِ پستِ رزروشده باشه (۱۰ کاراکتر حروف+عدد)، به‌جای
    # منطق اموجی پرمیوم، همون پست رو به‌عنوان نتیجه‌ی اینلاین نشون بده
    stripped_query = query_text.strip()

    # رله‌ی سلف: «پستِ موقت» (متن HTML + دکمه‌ها) از قبل توسط سلفِ همین کاربر تو
    # _self_relay_cache گذاشته شده و کوئری فقط یه توکنه. نتیجه همون نتیجه‌ی
    # پست (نسخه‌ی ساده + دکمه‌ی فعال‌سازی) ـه؛ نسخه‌ی کامل رو _apply_self_relay
    # جایگزین می‌کنه. result_id با "selfpost_" شروع می‌شه تا مسیرِ معمولیِ
    # chosen_inline_result (که فقط "send_emoji_msg" و "post_" رو می‌شناسه) دخالت نکنه.
    if stripped_query.startswith(SELF_RELAY_PREFIX):
        entry = _self_relay_cache.get(stripped_query)
        if not entry or entry["user_id"] != inline_query.from_user.id:
            bot.answer_inline_query(inline_query.id, [], cache_time=0, is_personal=True)
            return

        post = entry["post"]
        if post.get("media"):
            # رسانه داره: تلگرام تو کپشن مشکلی با اموجی پرمیوم نداره، پس
            # می‌شه مستقیم نسخه‌ی کامل فرستاد؛ کسرِ کوین همینجا (قبل از ارسال)
            force_plain = False
            with entry["lock"]:
                if entry["status"] is None:
                    if entry["charge"]:
                        if _charge_coins(entry["user_id"], INLINE_SEND_COIN_COST):
                            entry["status"] = "applied"
                        else:
                            entry["status"] = "no_coins"
                            force_plain = True
                            _notify_self_user(
                                entry["user_id"],
                                f"موجودی اموجی کوین کافی نیست ⛔️ برای فرستادنِ هر پیام با اموجی پرمیوم {INLINE_SEND_COIN_COST} کوین لازمه؛ "
                                "این پیام با اموجی معمولی ارسال شد.",
                            )
                    else:
                        entry["status"] = "applied"
                else:
                    force_plain = entry["status"] == "no_coins"
            result = build_inline_result_for_post(post, force_plain=force_plain)
        else:
            # بدون رسانه: تلگرام اجازه نمی‌ده اموجی پرمیوم مستقیم تو محتوای
            # متنیِ نتیجه‌ی اینلاین باشه؛ نسخه‌ی ساده + دکمه می‌فرستیم، اعمالِ
            # واقعی (و کسرِ کوین) رو _apply_self_relay انجام می‌ده.
            result = build_inline_result_for_post(post, apply_token=stripped_query)

        try:
            _t_mark(inline_query.from_user.id, stripped_query)
            bot.answer_inline_query(inline_query.id, [result], cache_time=0, is_personal=True)
        except Exception as e:
            print(f"❌ [inline_query:self_relay] خطا: {e}")
        return

    if is_valid_post_code(stripped_query):
        post = get_saved_post(stripped_query)
        if post:
            if post.get("media"):
                result = build_inline_result_for_post(post)
            else:
                # بدون رسانه: همون مکانیزمِ عمومیِ اعمال (ثبت توکن + دکمه) رو
                # برای هر کاربری (نه فقط سلف) استفاده می‌کنیم؛ charge=False
                # چون پست‌ها رایگانن.
                token = register_self_relay(inline_query.from_user.id, post, charge=False)
                result = build_inline_result_for_post(post, apply_token=token)
            bot.answer_inline_query(inline_query.id, [result], cache_time=1, is_personal=True)
            return

    if not query_text.strip():
        # هنوز هیچ متنی تایپ نشده
        results = [
            InlineQueryResultArticle(
                id="hint",
                title="متن دلخواهت رو بنویس",
                description="می‌تونی فرمت‌بندی (بولد/کد/...) و اموجی پرمیوم [آی‌دی] هم اضافه کنی",
                input_message_content=InputTextMessageContent(
                    message_text="بعد از منشن ربات، متن دلخواهت رو بنویس. برای اموجی پرمیوم: متن [آی‌دی اموجی]",
                    parse_mode="HTML",
                ),
            )
        ]
        bot.answer_inline_query(inline_query.id, results, cache_time=1, is_personal=True)
        return

    final_text, plain_text, detected_mode = _build_final_and_plain(query_text, user_id=inline_query.from_user.id)

    # این مسیر همیشه فقط متنه (بدون رسانه)، و تلگرام اجازه نمی‌ده اموجی
    # پرمیوم مستقیم تو محتوای متنیِ نتیجه‌ی اینلاین باشه؛ پس نسخه‌ی ساده
    # می‌ره + دکمه‌ی «فعال‌سازی». نسخه‌ی کامل بعداً خودکار (chosen_inline_result)
    # یا با کلیکِ دکمه جایگزین می‌شه — همونجا هم کوین کسر می‌شه.
    has_premium_emoji = final_text != plain_text
    apply_markup = None
    if has_premium_emoji:
        short_id = uuid.uuid4().hex[:16]
        _inline_emoji_cache[short_id] = {
            "final_text": final_text,
            "user_id": inline_query.from_user.id,
            "charged": False,
            "parse_mode": detected_mode,
        }
        apply_markup = InlineKeyboardMarkup()
        apply_markup.add(InlineKeyboardButton(text="✨ فعال‌سازی اموجی پرمیوم", callback_data=f"apply_emoji_{short_id}"))

    results = [
        InlineQueryResultArticle(
            id="send_emoji_msg" if has_premium_emoji else "send_plain_msg",
            title="فرستادن پیام",
            description=plain_text.strip() or "ارسال پیام",
            input_message_content=InputTextMessageContent(message_text=plain_text, parse_mode=detected_mode),
            reply_markup=apply_markup,
        )
    ]
    try:
        _t_mark(inline_query.from_user.id, query_text)
        bot.answer_inline_query(inline_query.id, results, cache_time=1, is_personal=True)
    except Exception as e:
        print(f"❌ [inline_query] خطا: {e}")




_charged_inline_messages = set()  # inline_message_id هایی که قبلاً ۷ کوین‌شون کم شده — جلوگیری از کسر دوباره


@bot.chosen_inline_handler(func=lambda result: True)
def handle_chosen_inline_result(chosen_result):
    """لایه‌ی خودکارِ اضافه: اگه /setinlinefeedback فعال باشه و تلگرام
    inline_message_id رو بده، بدون نیاز به زدن دکمه هم خودکار اموجی واقعی
    جایگزین می‌شه (و همینجا کوین کم می‌شه). اگه این رویداد نرسه یا
    inline_message_id نداشته باشه، مشکلی نیست — همون دکمه‌ی بالا (که همیشه
    کار می‌کنه، و همونجا کوین کم می‌شه) جایگزینش می‌شه."""
    if not chosen_result.inline_message_id:
        return

    _t_arrive = time_module.time()
    _d = _t_since(chosen_result.from_user.id, chosen_result.query)
    if _d is not None:
        print(f"⏱ [timing] از جواب‌دادنِ ربات به inline_query تا رسیدنِ chosen_inline_result: {_d*1000:.0f}ms")

    # مسیرِ سریعِ سلف: اگه /setinlinefeedback فعاله، ربات همین الان (بدون
    # منتظرِ کلیکِ دکمه‌ی سلف موندن) پستِ موقت رو اعمال می‌کنه. اگه دکمه
    # زودتر برسه، _apply_self_relay خودش دوباره‌کاری/کسرِ دوباره رو نمی‌ذاره.
    if chosen_result.result_id.startswith("selfpost_"):
        token = (chosen_result.query or "").strip()
        entry = _self_relay_cache.get(token)
        if entry is not None and entry["user_id"] == chosen_result.from_user.id:
            _apply_self_relay(token, chosen_result.inline_message_id)
            if DEBUG_TIMING:
                print(f"⏱ [timing] اعمال (کسر کوین + ادیت) تو ربات: {(time_module.time()-_t_arrive)*1000:.0f}ms")
        return

    # پست‌های رسانه‌دار (result_id با "post_" شروع می‌شه) نیازی به این لایه
    # ندارن: متن/دکمه‌هاشون از همون ابتدا کامل (با اموجی/آیکون پرمیوم) تو
    # کپشنِ نتیجه‌ی اینلاین فرستاده شده، پس چیزی برای آپدیت کردن نمی‌مونه.
    # (پست‌های بدون رسانه با پیشوندِ "selfpost_" میان و بالاتر هندل می‌شن.)
    if chosen_result.result_id.startswith("post_"):
        return

    if chosen_result.result_id != "send_emoji_msg":
        return

    if chosen_result.inline_message_id in _charged_inline_messages:
        return

    if not _charge_coins(chosen_result.from_user.id, INLINE_SEND_COIN_COST):
        # موجودی کافی نیست؛ پیام همون فال‌بک (اموجی معمولی) باقی می‌مونه
        return

    _charged_inline_messages.add(chosen_result.inline_message_id)

    final_text, _, detected_mode = _build_final_and_plain(chosen_result.query or "", user_id=chosen_result.from_user.id)

    try:
        bot.edit_message_text(
            inline_message_id=chosen_result.inline_message_id,
            text=final_text,
            parse_mode=detected_mode,
        )
        if DEBUG_TIMING:
            print(f"⏱ [timing] اعمال (کسر کوین + ادیت) تو ربات: {(time_module.time()-_t_arrive)*1000:.0f}ms")
    except Exception as e:
        print(f"❌ [chosen_inline_result] خطا در ویرایش خودکار: {e}")


@bot.message_handler(content_types=['text', 'animation', 'document', 'photo', 'video', 'voice', 'audio'])
def handle_all_messages(message):
    chat_id = message.chat.id

    if message.chat.type in ['group', 'supergroup']:
        update_group_admins_list(chat_id)
        return

    if _is_blocked(chat_id):
        return

    # ==========================================================================
    # پنل ادمین (فقط SUPER_ADMIN_ID): دریافت آیدی عددی کاربر و مبلغ افزودن/کسر کوین
    # ==========================================================================
    if chat_id == SUPER_ADMIN_ID and chat_id in user_states and user_states[chat_id].get("mode") == "ADMIN_PANEL":
        state_data = user_states[chat_id]
        step = state_data.get("step")
        last_msg_id = state_data.get("last_bot_msg_id")

        if step == "WAITING_FOR_USER_ID":
            try:
                target_id = int(message.text.strip())
            except (ValueError, AttributeError):
                send_styled_message(chat_id, "لطفاً فقط آیدی عددی معتبر وارد کنید ❌")
                return
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            info_text, markup = _build_admin_user_panel(target_id)
            state_data["step"] = "VIEWING_USER"
            state_data["target_id"] = target_id
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, parse_custom_emojis_to_html(info_text), reply_markup=markup)
            else:
                sent = send_styled_message(chat_id, info_text, reply_markup=markup)
                if sent:
                    state_data["last_bot_msg_id"] = sent.message_id
            return

        elif step in ("WAITING_FOR_COIN_ADD_AMOUNT", "WAITING_FOR_COIN_SUB_AMOUNT"):
            try:
                amount = int(message.text.strip())
                if amount <= 0:
                    raise ValueError
            except (ValueError, AttributeError):
                send_styled_message(chat_id, "لطفاً یک عدد صحیح مثبت وارد کنید ❌")
                return
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            target_id = state_data.get("target_id")
            delta = amount if step == "WAITING_FOR_COIN_ADD_AMOUNT" else -amount
            _adjust_coin_balance(target_id, delta)
            info_text, markup = _build_admin_user_panel(target_id)
            state_data["step"] = "VIEWING_USER"
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, parse_custom_emojis_to_html(info_text), reply_markup=markup)
            else:
                sent = send_styled_message(chat_id, info_text, reply_markup=markup)
                if sent:
                    state_data["last_bot_msg_id"] = sent.message_id
            return

    # ==========================================================================
    # رزرو اموجی: مرحله ۱) دریافت اموجی معمولی، مرحله ۲) دریافت آی‌دی اموجی
    # پرمیوم و ذخیره‌ی این جفت به‌نام همین کاربر.
    # ==========================================================================
    if chat_id in user_states and user_states[chat_id].get("mode") == "RESERVE_EMOJI":
        state_data = user_states[chat_id]
        step = state_data.get("step")
        last_msg_id = state_data.get("last_bot_msg_id")

        if step == "WAITING_FOR_NORMAL_EMOJI":
            capacity = get_user_emoji_capacity(chat_id)
            used = len(_get_user_emoji_data(chat_id).get("emojis", {}))
            if used >= capacity:
                send_styled_message(chat_id, "ظرفیت شما پر شده؛ برای افزودن بیشتر ابتدا ظرفیت را ارتقا دهید ⛔")
                user_states[chat_id] = {}
                return
            emoji_char = (message.text or "").strip()
            if not emoji_char or emoji_char.isascii() or len(emoji_char) > 8:
                send_styled_message(chat_id, "لطفاً فقط یک اموجی معمولی (نه متن یا عدد) ارسال کنید ❌")
                return
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            state_data["pending_emoji"] = emoji_char
            set_step(chat_id, "WAITING_FOR_EMOJI_ID", last_msg_id)
            msg = f"اموجی انتخابی: {emoji_char}\nحالا آی‌دی اموجی پرمیوم مورد نظر را ارسال کنید 🆔:"
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, msg, reply_markup=navigation_keyboard())
            else:
                sent = send_styled_message(chat_id, msg, reply_markup=navigation_keyboard())
                if sent:
                    state_data["last_bot_msg_id"] = sent.message_id
            return

        elif step == "WAITING_FOR_EMOJI_ID":
            emoji_id = (message.text or "").strip()
            if not re.fullmatch(r"\d{5,25}", emoji_id):
                send_styled_message(chat_id, "لطفاً فقط آی‌دی عددی معتبر اموجی پرمیوم را ارسال کنید ❌")
                return
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            emoji_char = state_data.get("pending_emoji")
            add_user_emoji_reservation(chat_id, emoji_char, emoji_id)
            user_states[chat_id] = {}
            success_msg = f"✅ رزرو با موفقیت ثبت شد!\nاز این پس در حالت اینلاین ربات (با نوشتن @{BOT_USERNAME} و متن دلخواه در هر چتی)، هرجا از {emoji_char} استفاده کنید، خودکار به اموجی پرمیوم انتخابی‌تان تبدیل می‌شود.\n\n"
            panel_text, panel_markup = build_emoji_reservation_panel(chat_id)
            formatted_success = parse_custom_emojis_to_html(success_msg, user_id=chat_id) + panel_text
            try:
                if last_msg_id:
                    bot.edit_message_text(chat_id=chat_id, message_id=last_msg_id, text=formatted_success, parse_mode="HTML", reply_markup=panel_markup)
                else:
                    bot.send_message(chat_id, formatted_success, parse_mode="HTML", reply_markup=panel_markup)
            except Exception:
                bot.send_message(chat_id, formatted_success, parse_mode="HTML", reply_markup=panel_markup)
            return

        elif step == "WAITING_FOR_EDIT_EMOJI":
            emoji_char = (message.text or "").strip()
            if not emoji_char or emoji_char.isascii() or len(emoji_char) > 8:
                send_styled_message(chat_id, "لطفاً فقط یک اموجی معمولی (نه متن یا عدد) ارسال کنید ❌")
                return
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            slot_id = state_data.get("edit_slot_id")
            update_user_emoji_reservation(chat_id, slot_id, emoji_char=emoji_char)
            user_states[chat_id] = {}
            panel_text, panel_markup = build_emoji_manage_panel(chat_id, slot_id)
            formatted_text = "✅ اموجی با موفقیت به‌روزرسانی شد!\n\n" + panel_text
            try:
                if last_msg_id:
                    bot.edit_message_text(chat_id=chat_id, message_id=last_msg_id, text=formatted_text, parse_mode="HTML", reply_markup=panel_markup)
                else:
                    bot.send_message(chat_id, formatted_text, parse_mode="HTML", reply_markup=panel_markup)
            except Exception:
                bot.send_message(chat_id, formatted_text, parse_mode="HTML", reply_markup=panel_markup)
            return

        elif step == "WAITING_FOR_EDIT_EMOJI_ID":
            emoji_id = (message.text or "").strip()
            if not re.fullmatch(r"\d{5,25}", emoji_id):
                send_styled_message(chat_id, "لطفاً فقط آی‌دی عددی معتبر اموجی پرمیوم را ارسال کنید ❌")
                return
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            slot_id = state_data.get("edit_slot_id")
            update_user_emoji_reservation(chat_id, slot_id, emoji_id=emoji_id)
            user_states[chat_id] = {}
            panel_text, panel_markup = build_emoji_manage_panel(chat_id, slot_id)
            formatted_text = "✅ آی‌دی اموجی پرمیوم با موفقیت به‌روزرسانی شد!\n\n" + panel_text
            try:
                if last_msg_id:
                    bot.edit_message_text(chat_id=chat_id, message_id=last_msg_id, text=formatted_text, parse_mode="HTML", reply_markup=panel_markup)
                else:
                    bot.send_message(chat_id, formatted_text, parse_mode="HTML", reply_markup=panel_markup)
            except Exception:
                bot.send_message(chat_id, formatted_text, parse_mode="HTML", reply_markup=panel_markup)
            return

    # ==========================================================================
    # رزرو پست آماده: دریافت متن/رسانه، انتخاب افزودن جدول، ساخت دکمه‌ها
    # (متن → استایل → آیکون → لینک) و در پایان تولید کد ۱۰ کاراکتری.
    # ==========================================================================
    # ==========================================================================
    # لاگین یوزربات (فقط مالک ربات): شماره → کد تایید → (در صورت لزوم) رمز
    # تایید دومرحله‌ای. نتیجه یه فایل سشن تو data/self (به اسمِ آیدیِ عددیِ
    # واقعیِ اکانت) ـه که بعداً برای ارسال نتیجه‌ی اینلاین «به‌جای خودِ مالک»
    # استفاده می‌شه.
    # ==========================================================================
    if chat_id in user_states and user_states[chat_id].get("mode") == "USERBOT_LOGIN":
        state_data = user_states[chat_id]
        step = state_data.get("step")
        last_msg_id = state_data.get("last_bot_msg_id")

        if step == "WAITING_FOR_PHONE":
            phone = (message.text or "").strip()
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            if not re.fullmatch(r"\+\d{8,15}", phone):
                send_styled_message(chat_id, "فرمت شماره معتبر نیست؛ باید با + و کد کشور باشه، مثل +989123456789 ❌")
                return
            try:
                client, phone_code_hash = run_userbot_coro(_userbot_request_code(chat_id, phone))
            except Exception as e:
                send_styled_message(chat_id, f"خطا در درخواست کد تایید ❌:\n<code>{e}</code>")
                return
            _userbot_login_state[chat_id] = {"client": client, "phone": phone, "phone_code_hash": phone_code_hash}
            state_data["entered_code"] = ""
            set_step(chat_id, "WAITING_FOR_CODE", last_msg_id)
            text, markup = build_numeric_keypad("", "کدی که تلگرام الان برات فرستاد رو با کیبورد زیر وارد کن 🔢:")
            edit_or_send_message(chat_id, last_msg_id, text, reply_markup=markup)
            return

        elif step == "WAITING_FOR_CODE":
            # ورود کد از این به بعد فقط با کیبورد عددیِ همون پیام انجام می‌شه؛
            # اگه کاربر به‌جاش چیزی تایپ کنه، فقط پیامش حذف می‌شه.
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            return

        elif step == "WAITING_FOR_PASSWORD":
            password = (message.text or "").strip()
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            login_data = _userbot_login_state.get(chat_id)
            if not login_data:
                send_styled_message(chat_id, "جلسه‌ی لاگین منقضی شده؛ از اول شروع کن ❌")
                user_states[chat_id] = {}
                return
            try:
                run_userbot_coro(_userbot_sign_in_password(login_data["client"], password))
            except Exception as e:
                send_styled_message(chat_id, f"رمز اشتباهه ❌:\n<code>{e}</code>")
                return
            user_states[chat_id] = {}
            logged_in_client = login_data["client"]
            _userbot_login_state.pop(chat_id, None)
            finalize_login_session(logged_in_client, chat_id)
            send_styled_message(chat_id, "✅ اکانتت با موفقیت وصل شد و شنودگر خودکار فعال شد!", reply_markup=main_keyboard(chat_id))
            return

    # ==========================================================================
    # ارسال یه پستِ ذخیره‌شده از طریق یوزربات (از طرف خودِ مالک): کد پست →
    # آیدی عددی چت/گروه مقصد → ارسال واقعی با کلیک‌کردنِ نتیجه‌ی اینلاین.
    # ==========================================================================


    if chat_id in user_states and user_states[chat_id].get("mode") == "RESERVE_POST":
        state_data = user_states[chat_id]
        step = state_data.get("step")
        last_msg_id = state_data.get("last_bot_msg_id")

        if step == "WAITING_FOR_DRAFT_TEXT":
            state_data["draft_text"] = sanitize_html_for_telegram(get_html_text_from_message(message))
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            state_data.pop("step", None)
            body, markup = build_post_text_panel(chat_id)
            edit_or_send_raw_html(chat_id, last_msg_id, body, reply_markup=markup)
            return

        elif step == "WAITING_FOR_DRAFT_MEDIA":
            content_type = message.content_type
            media = None
            if content_type == "photo":
                media = {"type": "photo", "file_id": message.photo[-1].file_id}
            elif content_type == "video":
                media = {"type": "video", "file_id": message.video.file_id}
            elif content_type == "document":
                media = {"type": "document", "file_id": message.document.file_id}
            elif content_type == "animation":
                media = {"type": "animation", "file_id": message.animation.file_id}
            else:
                send_styled_message(chat_id, "لطفاً فقط عکس/ویدیو/فایل/گیف بفرست ❌")
                return
            state_data["draft_media"] = media
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            state_data.pop("step", None)
            body, markup = build_post_media_panel(chat_id)
            edit_or_send_message(chat_id, last_msg_id, body, reply_markup=markup)
            return

        elif step == "WAITING_FOR_BTN_TEXT":
            btn_text = (message.text or "").strip()
            if not btn_text:
                send_styled_message(chat_id, "لطفاً یه متن معتبر برای دکمه بفرست ❌")
                return
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            state_data["pending_btn_text"] = btn_text
            set_step(chat_id, "WAITING_FOR_BTN_TYPE", last_msg_id)
            type_markup = _btn_type_markup()
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, "نوعِ دکمه رو انتخاب کن 🔘:", reply_markup=type_markup)
            else:
                sent = send_styled_message(chat_id, "نوعِ دکمه رو انتخاب کن 🔘:", reply_markup=type_markup)
                if sent:
                    state_data["last_bot_msg_id"] = sent.message_id
            return

        elif step == "WAITING_FOR_BTN_ICON":
            icon_input = (message.text or "").strip()
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            if icon_input == "0":
                state_data["pending_btn_icon"] = None
            elif re.fullmatch(r"\d{5,25}", icon_input):
                state_data["pending_btn_icon"] = icon_input
            else:
                send_styled_message(chat_id, "لطفاً فقط آی‌دی عددی معتبر یا عدد 0 بفرست ❌")
                return
            set_step(chat_id, "WAITING_FOR_BTN_VALUE", last_msg_id)
            msg = _BTN_VALUE_PROMPTS.get(state_data.get("pending_btn_type") or "url", _BTN_VALUE_PROMPTS["url"])
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, msg, reply_markup=navigation_keyboard())
            else:
                sent = send_styled_message(chat_id, msg, reply_markup=navigation_keyboard())
                if sent:
                    state_data["last_bot_msg_id"] = sent.message_id
            return

        elif step == "WAITING_FOR_BTN_VALUE":
            btype = state_data.get("pending_btn_type") or "url"
            value_fields, err = _parse_btn_value(btype, message.text)
            if err:
                send_styled_message(chat_id, err)
                return
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            new_btn = {
                "type": btype,
                "text": state_data.get("pending_btn_text"),
                "style": state_data.get("pending_btn_style"),
                "icon_custom_emoji_id": state_data.get("pending_btn_icon"),
            }
            new_btn.update(value_fields)
            rows = state_data.get("draft_button_rows", [])
            if rows:
                # اگه از قبل حداقل یه دکمه هست، بپرس همین ردیف یا ردیف جدید
                state_data["pending_new_btn"] = new_btn
                state_data.pop("step", None)
                row_markup = InlineKeyboardMarkup()
                row_markup.row(
                    InlineKeyboardButton("➡️ همین ردیف", callback_data="rpost_row_same", style="primary"),
                    InlineKeyboardButton("⬇️ ردیف جدید", callback_data="rpost_row_new", style="primary"),
                )
                row_markup.row(
                    InlineKeyboardButton("بازگشت", callback_data="nav_back", style="danger", icon_custom_emoji_id="5253997076169115797"),
                    InlineKeyboardButton("منوی اصلی", callback_data="nav_all_back", style="danger", icon_custom_emoji_id="5210952531676504517")
                )
                edit_or_send_message(chat_id, last_msg_id, "این دکمه هم‌ردیف با دکمه‌ی قبلی باشه یا ردیف جدید؟ 🔘", reply_markup=row_markup)
            else:
                state_data.setdefault("draft_button_rows", []).append([new_btn])
                state_data.pop("step", None)
                body, markup = build_post_buttons_panel(chat_id)
                edit_or_send_message(chat_id, last_msg_id, body, reply_markup=markup)
            return

    # ==========================================================================
    # ساخت فاکتور خرید اموجی کوین مستقیماً داخل ربات (بدون نیاز به مینی‌اپ)
    # ==========================================================================
    if chat_id in user_states and user_states[chat_id].get("mode") == "BUY_COIN":
        state_data = user_states[chat_id]
        step = state_data.get("step")
        last_msg_id = state_data.get("last_bot_msg_id")

        if step == "WAITING_FOR_COIN_AMOUNT":
            try:
                coin_amount = float(_norm_digits(message.text.strip()))
            except (ValueError, AttributeError):
                send_styled_message(chat_id, tr(chat_id, "bad_number"))
                return

            if coin_amount < MIN_PURCHASE_COINS:
                send_styled_message(chat_id, tr(chat_id, "buy_min", min=MIN_PURCHASE_COINS))
                return

            _buy_offer(chat_id, coin_amount)      # قیمت + کد تخفیف (قبل از پرداخت)؛ فاکتور با «ادامه» ساخته می‌شه
            return

        elif step == "WAITING_FOR_RECEIPT":
            if message.content_type != 'photo':
                send_styled_message(chat_id, "لطفاً تصویر رسید پرداخت را به‌صورت عکس ارسال کنید 📸")
                return

            invoice_id = state_data.get("invoice_id")
            invoice = strong.get_invoice(invoice_id)
            if not invoice:
                send_styled_message(chat_id, "این فاکتور دیگر معتبر نیست ⛔")
                user_states[chat_id] = {}
                return

            invoice["status"] = "submitted"
            strong.save_invoice(invoice)

            buyer_name = html.escape(message.from_user.first_name or "نامشخص")
            buyer_username = message.from_user.username
            caption = (
                f"🧾 فاکتور خرید جدید\n\n"
                f"👤 خریدار: {buyer_name}\n"
                f"🆔 آیدی عددی: {chat_id}\n"
                + (f"📛 یوزرنیم: @{buyer_username}\n" if buyer_username else "")
                + f"\n🪙 مقدار درخواستی: {invoice.get('coin_amount')} اموجی کوین\n"
                f"💵 مبلغ قابل پرداخت: {invoice.get('toman_amount'):,} تومان\n"
                + (f"🎟 کد تخفیف: {invoice['discount_code']} (-{int(invoice.get('discount_toman') or 0):,} تومان)\n" if invoice.get("discount_code") else "")
                + f"🔖 شماره فاکتور: {invoice_id}\n\n"
                "رسید پرداخت پیوست شده است. لطفاً بررسی و تایید/رد کنید."
            )
            admin_markup = InlineKeyboardMarkup()
            admin_markup.add(
                InlineKeyboardButton(text="✅ تایید فاکتور", callback_data=f"inv_approve_{invoice_id}"),
                InlineKeyboardButton(text="❌ حذف فاکتور", callback_data=f"inv_reject_{invoice_id}"),
            )
            admin_markup.add(InlineKeyboardButton(text="💬 ارتباط با خریدار", url=f"tg://user?id={chat_id}"))

            try:
                bot.send_photo(
                    INVOICE_APPROVER_ID,
                    message.photo[-1].file_id,
                    caption=parse_custom_emojis_to_html(caption),
                    parse_mode="HTML",
                    reply_markup=admin_markup,
                )
                send_styled_message(chat_id, "رسید شما ارسال شد و در انتظار بررسی است ✅")
            except Exception as e:
                send_styled_message(chat_id, f"خطا در ارسال رسید ❌:\n<code>{e}</code>")

            user_states[chat_id] = {}
            return

    # ==========================================================================
    # ارسال پست جدید به کانال (فقط ادمین‌های همان کانال به این مرحله می‌رسند،
    # چون کنترل دسترسی موقع زدن دکمه‌ی «ارسال پست به کانال» انجام شده)
    # ==========================================================================
    if chat_id in user_states and user_states[chat_id].get("mode") == "CHANNEL_POST":
        state_data = user_states[chat_id]
        target_channel_id = state_data.get("target_channel_id")

        if not _is_channel_admin(chat_id, target_channel_id):
            send_styled_message(chat_id, "دسترسی شما به این کانال لغو شده است ⛔")
            user_states[chat_id] = {}
            return

        def deliver_channel_post(msgs, _target=int(target_channel_id)):
            try:
                if len(msgs) > 1:
                    media_infos = [extract_media_info(m) for m in msgs]
                    media_infos = [m for m in media_infos if m]
                    media_list = build_input_media_from_info(media_infos)
                    if media_list:
                        bot.send_media_group(_target, media_list)
                    send_styled_message(chat_id, "پست (آلبوم) با موفقیت در کانال منتشر شد ✅")
                    return

                single = msgs[0]
                if single.content_type == 'text':
                    formatted = parse_custom_emojis_to_html(single.text or "")
                    bot.send_message(_target, formatted, parse_mode="HTML")
                else:
                    caption = single.caption
                    if caption:
                        formatted_caption = parse_custom_emojis_to_html(caption)
                        bot.copy_message(chat_id=_target, from_chat_id=chat_id, message_id=single.message_id, caption=formatted_caption, parse_mode="HTML")
                    else:
                        bot.copy_message(chat_id=_target, from_chat_id=chat_id, message_id=single.message_id)
                send_styled_message(chat_id, "پست با موفقیت در کانال منتشر شد ✅")
            except Exception as e:
                send_styled_message(chat_id, f"خطا در ارسال پست به کانال ❌:\n<code>{e}</code>")
            finally:
                user_states[chat_id] = {}

        handle_incoming_media(message, deliver_channel_post)
        return

    # ==========================================================================
    # ویرایش پست موجود در کانال — تشخیص پست از طریق فوروارد یا لینک، سپس دریافت
    # متن جدید و ویرایش با پشتیبانی از اموجی پرمیوم (سینتکس [آیدی_اموجی])
    # ==========================================================================
    if chat_id in user_states and user_states[chat_id].get("mode") == "CHANNEL_EDIT":
        state_data = user_states[chat_id]
        step = state_data.get("step")
        target_channel_id = state_data.get("target_channel_id")

        if not _is_channel_admin(chat_id, target_channel_id):
            send_styled_message(chat_id, "دسترسی شما به این کانال لغو شده است ⛔")
            user_states[chat_id] = {}
            return

        if step == "WAITING_FOR_CHANNEL_POST_REF":
            found_message_id = None

            fwd_chat = getattr(message, "forward_from_chat", None)
            if fwd_chat and str(fwd_chat.id) == str(target_channel_id):
                found_message_id = message.forward_from_message_id
            elif message.text:
                m = re.search(r"t\.me/(?:c/)?([\w\d]+)/(\d+)", message.text.strip())
                if m:
                    ref, msg_id_str = m.group(1), m.group(2)
                    try:
                        if ref.isdigit():
                            ref_chat_id = int(f"-100{ref}")
                        else:
                            ref_chat = bot.get_chat(f"@{ref}")
                            ref_chat_id = ref_chat.id
                        if str(ref_chat_id) == str(target_channel_id):
                            found_message_id = int(msg_id_str)
                    except Exception:
                        found_message_id = None

            if not found_message_id:
                send_styled_message(chat_id, "این پست متعلق به کانال انتخاب‌شده نیست، یا لینک/فوروارد معتبر نبود. دوباره امتحان کنید ⛔")
                return

            state_data["step"] = "WAITING_FOR_CHANNEL_EDIT_TEXT"
            state_data["edit_message_id"] = found_message_id
            send_styled_message(chat_id, "متن/کپشن جدید پست را ارسال کنید (برای اموجی پرمیوم از [آیدی_اموجی] استفاده کنید) ✏️:")
            return

        elif step == "WAITING_FOR_CHANNEL_EDIT_TEXT":
            if not message.text:
                send_styled_message(chat_id, "لطفاً متن جدید را به‌صورت پیام متنی ارسال کنید ❌")
                return

            new_text = parse_custom_emojis_to_html(message.text)
            edit_msg_id = state_data.get("edit_message_id")
            target_int = int(target_channel_id)

            success = False
            try:
                bot.edit_message_text(chat_id=target_int, message_id=edit_msg_id, text=new_text, parse_mode="HTML")
                success = True
            except Exception:
                try:
                    bot.edit_message_caption(chat_id=target_int, message_id=edit_msg_id, caption=new_text, parse_mode="HTML")
                    success = True
                except Exception as e:
                    send_styled_message(chat_id, f"خطا در ویرایش پست کانال ❌:\n<code>{e}</code>")

            if success:
                send_styled_message(chat_id, "پست کانال با موفقیت ویرایش شد ✅")

            user_states[chat_id] = {}
            return

    state_data = user_states.get(chat_id)
    if not state_data or not state_data.get("mode"):
        return

    mode = state_data.get("mode")
    step = state_data.get("step")
    last_msg_id = state_data.get("last_bot_msg_id")

    if mode in ["BULK_SEND", "GIF"]:
        if mode == "BULK_SEND" and step == "WAITING_FOR_CONTENT":
            # اگه کاربر به‌جای محتوای دستی، یه کدِ پستِ ذخیره‌شده (۱۰ کاراکتری)
            # بفرسته، همون پست رو مستقیم برای انتخاب گروه آماده می‌کنیم؛ دیگه
            # نیازی به کپشن/نام‌فرستنده/ریپلای نیست چون پست از قبل کامله.
            if message.content_type == "text" and is_valid_post_code((message.text or "").strip()):
                code = (message.text or "").strip()
                post = get_saved_post(code)
                if post:
                    try:
                        bot.delete_message(chat_id, message.message_id)
                    except Exception:
                        pass
                    state_data["saved_post"] = post
                    state_data["saved_post_code"] = code
                    set_step(chat_id, "WAITING_FOR_TARGET_ID", last_msg_id)
                    msg = "پست پیدا شد ✅\nحالا آی‌دی عددی گروه مقصد رو بفرست 🆔:"
                    if last_msg_id:
                        edit_or_send_message(chat_id, last_msg_id, msg, reply_markup=navigation_keyboard())
                    else:
                        sent = send_styled_message(chat_id, msg, reply_markup=navigation_keyboard())
                        if sent:
                            state_data["last_bot_msg_id"] = sent.message_id
                    return

            # پشتیبانی از ارسال چند رسانه (آلبوم) هم‌زمان: اگر کاربر چند عکس/ویدیو/فایل
            # را با هم بفرستد، همه را جمع‌آوری کرده و سپس یک‌جا ادامه‌ی مسیر (کپشن،
            # نام فرستنده، ریپلای و ...) طی می‌شود.
            def handle_bulk_content(msgs, _chat_id=chat_id):
                sdata = user_states.get(_chat_id)
                if not sdata or sdata.get("step") != "WAITING_FOR_CONTENT":
                    return
                _last_msg_id = sdata.get("last_bot_msg_id")
                first = msgs[0]
                sdata["media_message"] = first

                if len(msgs) > 1:
                    media_infos = [extract_media_info(m) for m in msgs]
                    sdata["media_group_info"] = [m for m in media_infos if m]
                else:
                    sdata["media_group_info"] = None

                # توجه: پیام(های) اصلی کاربر اینجا دیگر حذف نمی‌شوند.
                # قبلاً بلافاصله بعد از ذخیره حذف می‌شدند، اما ارسال نهایی (چه فوری چه
                # بعد از تایید ادمین) با copy_message از روی همین پیام انجام می‌گیرد؛
                # اگر پیام حذف شده باشد، تلگرام خطای «message to copy not found» می‌دهد
                # (مخصوصاً برای عکس/ویدیو/فایل با کپشن اختصاصی).
                if len(msgs) > 1 or first.content_type in ['photo', 'video', 'document', 'audio', 'voice']:
                    set_step(_chat_id, "WAITING_FOR_CAPTION_CHOICE", _last_msg_id)
                    if _last_msg_id:
                        edit_or_send_message(_chat_id, _last_msg_id, "آیا تمایل دارید کپشن اختصاصی ثبت کنید؟ 📝", reply_markup=yes_no_keyboard_with_nav())
                else:
                    sdata["custom_caption"] = None
                    set_step(_chat_id, "WAITING_FOR_SENDER_NAME_CHOICE", _last_msg_id)
                    if _last_msg_id:
                        edit_or_send_message(_chat_id, _last_msg_id, "آیا نام شما به عنوان فرستنده نمایش داده شود؟ 👑", reply_markup=yes_no_keyboard_with_nav())

            handle_incoming_media(message, handle_bulk_content)
            return

        elif mode == "GIF" and step == "WAITING_FOR_GIF":
            if message.animation:
                state_data["media_message"] = message
                state_data["gif_id"] = message.animation.file_id
                state_data["custom_caption"] = get_html_text_from_message(message)
                try:
                    bot.delete_message(chat_id, message.message_id)
                except Exception:
                    pass
                set_step(chat_id, "WAITING_FOR_CAPTION_CHOICE", last_msg_id)
                if last_msg_id:
                    edit_or_send_message(chat_id, last_msg_id, "آیا تمایل به تغییر کپشن گیف دارید؟ 🎬", reply_markup=yes_no_keyboard_with_nav())
            return

        elif step == "WAITING_FOR_CAPTION":
            state_data["custom_caption"] = get_html_text_from_message(message)
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass
            set_step(chat_id, "WAITING_FOR_SENDER_NAME_CHOICE", last_msg_id)
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, "آیا نام شما زیر پیام نمایش داده شود؟ 👑", reply_markup=yes_no_keyboard_with_nav())
            return

        elif step == "WAITING_FOR_SENDER_EMOJI_CHOICE":
            text_val = message.text.strip() if message.text else ""
            if text_val != "0" and text_val.lower() not in ["خیر", "no"]:
                # توجه: فقط یه‌بار پردازش می‌شه (get_html_text_from_message)؛
                # پاس دوباره از parse_custom_emojis_to_html حذف شد چون
                # final_html بعداً یه‌بار دیگه (موقع ارسال واقعی) پردازش
                # می‌شه و پردازشِ دوباره باعث خراب‌شدن/ناپدیدشدنِ اموجی و
                # فرمت‌بندی می‌شد.
                state_data["sender_emoji"] = get_html_text_from_message(message)
            else:
                state_data["sender_emoji"] = ""
            
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass

            set_step(chat_id, "WAITING_FOR_REPLY_CHOICE", last_msg_id)
            if last_msg_id:
                edit_or_send_message(chat_id, last_msg_id, "آیا می‌خواهید روی پیام خاصی ریپلای شود؟ ↩️", reply_markup=yes_no_keyboard_with_nav())
            return

        elif step == "WAITING_FOR_REPLY_LINK":
            link = message.text.strip() if message.text else ""
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass

            private_match = re.search(r't\.me/c/(\d+)/(\d+)', link)
            public_match = re.search(r't\.me/([^/]+)/(\d+)', link)

            if private_match:
                extracted_target_id = int(f"-100{private_match.group(1)}")
                reply_to_msg_id = int(private_match.group(2))
                process_final_message_sending(chat_id, state_data, extracted_target_id, reply_to_msg_id)
            elif public_match and not public_match.group(1).startswith('c/'):
                group_username = public_match.group(1)
                reply_to_msg_id = int(public_match.group(2))
                try:
                    chat_info = bot.get_chat(f"@{group_username}")
                    extracted_target_id = chat_info.id
                    process_final_message_sending(chat_id, state_data, extracted_target_id, reply_to_msg_id)
                except Exception as e:
                    if last_msg_id:
                        edit_or_send_message(chat_id, last_msg_id, f"خطا در شناسایی گروه از روی لینک ❌:\n<code>{e}</code>", reply_markup=navigation_keyboard())
            else:
                if last_msg_id:
                    edit_or_send_message(chat_id, last_msg_id, "لینک نامعتبر است. لطفاً لینک پیام را به درستی ارسال کنید ❌", reply_markup=navigation_keyboard())
            return

        elif step == "WAITING_FOR_TARGET_ID":
            text_input = message.text.strip() if message.text else ""
            try:
                bot.delete_message(chat_id, message.message_id)
            except Exception:
                pass

            # مسیر جدا برای فرستادن یه پست ذخیره‌شده (با کد) به گروه: فقط
            # آی‌دی عددی گروه لازمه، نه لینک/ریپلای.
            if state_data.get("saved_post"):
                try:
                    target_id = int(text_input)
                except ValueError:
                    if last_msg_id:
                        edit_or_send_message(chat_id, last_msg_id, "شناسه عددی وارد شده معتبر نیست. لطفاً فقط عدد وارد کنید ❌", reply_markup=navigation_keyboard())
                    return
                if target_id >= 0:
                    if last_msg_id:
                        edit_or_send_message(chat_id, last_msg_id, "شناسه گروه‌ها باید با علامت منفی (-) شروع شود ⛔", reply_markup=navigation_keyboard())
                    return
                send_saved_post_to_group(chat_id, state_data, target_id)
                return

            target_id = None
            reply_to_msg_id = state_data.get("reply_to_msg_id")

            link_match = re.search(r'^<(https?://[^\s>]+)>', text_input)
            
            if link_match:
                full_link = link_match.group(1)
                
                private_match = re.search(r't\.me/c/(\d+)/(\d+)', full_link)
                public_match = re.search(r't\.me/([^/]+)/(\d+)', full_link)

                if private_match:
                    target_id = int(f"-100{private_match.group(1)}")
                    reply_to_msg_id = int(private_match.group(2))
                elif public_match and not public_match.group(1).startswith('c/'):
                    group_username = public_match.group(1)
                    reply_to_msg_id = int(public_match.group(2))
                    try:
                        chat_info = bot.get_chat(f"@{group_username}")
                        target_id = chat_info.id
                    except Exception as e:
                        if last_msg_id:
                            edit_or_send_message(chat_id, last_msg_id, f"خطا در شناسایی گروه از روی لینک ❌:\n<code>{e}</code>", reply_markup=navigation_keyboard())
                        return

                remaining_text = text_input.replace(link_match.group(0), "").strip()
                if remaining_text:
                    if state_data.get("custom_caption") is not None or state_data.get("media_message"):
                        state_data["custom_caption"] = remaining_text
                    else:
                        if state_data.get("media_message") and state_data["media_message"].content_type == 'text':
                            state_data["custom_caption"] = remaining_text
            else:
                try:
                    target_id = int(text_input)
                except ValueError:
                    if last_msg_id:
                        edit_or_send_message(chat_id, last_msg_id, "شناسه عددی وارد شده معتبر نیست. لطفاً فقط عدد وارد کنید ❌", reply_markup=navigation_keyboard())
                    return

            if not target_id:
                if last_msg_id:
                    edit_or_send_message(chat_id, last_msg_id, "شناسه گروه نامعتبر است ⛔", reply_markup=navigation_keyboard())
                return

            if target_id >= 0:
                if last_msg_id:
                    edit_or_send_message(chat_id, last_msg_id, "شناسه گروه‌ها باید با علامت منفی (-) شروع شود یا از طریق لینک معتبر استخراج گردد ⛔", reply_markup=navigation_keyboard())
                return

            process_final_message_sending(chat_id, state_data, target_id, reply_to_msg_id)

def sync_loop():
    """
    هر ۱۰ ثانیه یک‌بار:
    ۱) اگر group_settings.json یا profiles.json از بیرون (مثلاً یک ادمین دیگر
       یا اسکریپت جانبی) عوض شده باشند، دوباره در حافظه‌ی ربات لود می‌شوند.
       قبلاً این فایل‌ها فقط یک‌بار در استارت ربات خوانده می‌شدند.
    ۲) لیست ادمین‌های واقعیِ هر گروه از تلگرام گرفته می‌شود تا اگر کسی ادمین شد یا از
       ادمینی درآمد، group_admins.json خودکار به‌روز شود — فقط حساب‌های کاربری واقعی
       شمرده می‌شوند، نه ربات‌ها (از جمله خود این ربات).
    """
    global user_profiles_status, group_settings, group_admins, blocked_users

    while True:
        try:
            fresh_settings = load_json(GROUP_SETTINGS_FILE, {})
            group_settings.clear()
            group_settings.update(fresh_settings)

            fresh_profiles = load_json(PROFILE_DATA_FILE, {})
            user_profiles_status.clear()
            user_profiles_status.update(fresh_profiles)

            fresh_blocked = set(load_json(BLOCKED_USERS_FILE, []))
            blocked_users.clear()
            blocked_users.update(fresh_blocked)
        except Exception as e:
            print(f"sync_loop: error reloading status files: {e}")

        try:
            admins_changed = False
            for gid in list(group_admins.keys()):
                try:
                    chat_admins = bot.get_chat_administrators(int(gid))
                    real_admin_ids = [m.user.id for m in chat_admins if not m.user.is_bot]
                except Exception:
                    # مثلاً ربات دیگر عضو گروه نیست یا گروه حذف شده؛ نادیده گرفته می‌شود
                    continue

                if set(real_admin_ids) != set(group_admins.get(gid, [])):
                    group_admins[gid] = real_admin_ids
                    admins_changed = True

            if admins_changed:
                save_json(group_admins, GROUP_ADMINS_FILE)
        except Exception as e:
            print(f"sync_loop: error refreshing group admins: {e}")

        time_module.sleep(10)
