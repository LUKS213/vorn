document.addEventListener("DOMContentLoaded", () => {
    const tg = window.Telegram.WebApp;

    // ===================== حالت سبک (اموجی‌های پرمیوم بدون انیمیشن) =====================
    // این تنظیم را کاربر از داخل «تنظیمات مینی‌اپ» در صفحه پروفایل روشن/خاموش می‌کند.
    // وقتی روشن باشد، اموجی‌های پرمیوم همچنان از سرور گرفته و جایگزین fallback
    // یونیکد می‌شوند (یعنی از بین نمی‌روند)، فقط دیگر متحرک نیستند: ویدیوها روی
    // اولین فریم متوقف می‌مانند و انیمیشن‌های لاتی هم روی فریم اول فریز می‌شوند؛
    // یعنی دقیقاً مثل یک آیکون/عکس ساکن دیده می‌شوند، بدون پخش خودکار مداوم.
    const LITE_MODE_KEY = "miniapp_lite_mode";
    let liteMode = false;
    try {
        liteMode = localStorage.getItem(LITE_MODE_KEY) === "1";
    } catch (e) { /* localStorage در دسترس نبود؛ حالت پیش‌فرض (غیرسبک) باقی می‌ماند */ }

    // ===================== آیکون‌های پرمیوم =====================
    // این بخش اول از همه تعریف می‌شود چون صفحه‌ی خطای «فقط از تلگرام باز کنید»
    // هم به آیکون نیاز دارد و ممکن است زودتر از بقیه‌ی کد اجرا شود.
    // به‌جای اموجی یونیکد ساده، خود اموجی پرمیوم واقعی (ویدیویی/لاتی/استاتیک) پک
    // ربات را از سرور می‌گیریم و جایگزین اموجی fallback داخل هر data-icon-key می‌کنیم.
    // اگر آیکون بارگذاری نشد، همان اموجی ساده‌ی fallback که در HTML بود باقی می‌ماند.
    let premiumIcons = {};
    let iconsFetchedOnce = false;

    // animated=false یعنی همان اموجی پرمیوم نشان داده شود ولی به‌جای پخش
    // مداوم، فقط روی فریم اول ساکن بماند (حالت سبک).
    function renderIcon(container, asset, animated = true) {
        if (!asset) return; // چیزی از سرور نیامد → fallback همون‌جا می‌مونه
        if (!container.dataset.fallback) {
            container.dataset.fallback = container.innerHTML;
        }
        const restoreFallback = () => { container.innerHTML = container.dataset.fallback; };

        try {
            if (asset.type === "video") {
                const v = document.createElement("video");
                v.muted = true; v.playsInline = true; v.preload = "auto";
                v.onerror = restoreFallback;
                if (animated) {
                    v.autoplay = true; v.loop = true;
                } else {
                    // برای گرفتن فریم اول به‌صورت ساکن، ویدیو را یک لحظه پخش
                    // و بلافاصله متوقف می‌کنیم (بدون loop/autoplay واقعی).
                    v.addEventListener("loadeddata", () => {
                        const playPromise = v.play();
                        if (playPromise && playPromise.then) {
                            playPromise.then(() => v.pause()).catch(() => {});
                        } else {
                            v.pause();
                        }
                    }, { once: true });
                }
                v.src = asset.url;
                container.innerHTML = "";
                container.appendChild(v);
            } else if (asset.type === "lottie" && window.lottie) {
                container.innerHTML = "";
                const anim = window.lottie.loadAnimation({
                    container: container,
                    renderer: "svg",
                    loop: animated,
                    autoplay: animated,
                    animationData: asset.data
                });
                if (!animated) {
                    anim.goToAndStop(1, true); // فریم اول، به‌صورت ساکن/آیکون
                }
            } else if (asset.type === "static") {
                const img = document.createElement("img");
                img.src = asset.url;
                img.onerror = restoreFallback;
                container.innerHTML = "";
                container.appendChild(img);
            }
        } catch (e) {
            restoreFallback();
        }
    }

    function applyIconsIn(root) {
        (root || document).querySelectorAll("[data-icon-key]").forEach(el => {
            renderIcon(el, premiumIcons[el.getAttribute("data-icon-key")], !liteMode);
        });
    }

    // ===================== اموجی وضعیت (استیتوس دلخواه کنار اسم) =====================
    // برخلاف آیکون‌های ثابت بالا، اموجی وضعیت هرکسی از یه پک دلخواه انتخاب
    // می‌شه (شناسه‌ش از قبل توی کد نیست)، پس با آی‌دی جداگانه از سرور گرفته
    // می‌شه. یه کش ساده‌ی حافظه‌ای هم داریم تا برای یه اموجیِ تکراری (مثلاً
    // چندجا همزمان) چندبار fetch نزنیم.
    const emojiAssetCache = {};

    function renderStatusEmoji(container, emojiId) {
        if (!container) return;
        if (!emojiId) { container.innerHTML = ""; container.classList.add("hidden"); return; }
        container.classList.remove("hidden");

        if (emojiAssetCache[emojiId]) {
            renderIcon(container, emojiAssetCache[emojiId], !liteMode);
            return;
        }
        fetch(`/api/emoji_asset?emoji_id=${encodeURIComponent(emojiId)}`)
            .then(res => res.json())
            .then(data => {
                if (data.status !== "success") { container.classList.add("hidden"); return; }
                emojiAssetCache[emojiId] = data.asset;
                renderIcon(container, data.asset, !liteMode);
            })
            .catch(() => { container.classList.add("hidden"); });
    }

    // کش محلی (روی خود گوشی کاربر) برای آیکون‌های پرمیوم: هر بار مینی‌اپ باز
    // می‌شود، اول همین نسخه‌ی ذخیره‌شده (اگر باشد) فوراً و بدون هیچ تاخیر شبکه‌ای
    // نمایش داده می‌شود، و همزمان یک درخواست تازه هم به سرور زده می‌شود تا اگر
    // چیزی عوض شده بود، در پس‌زمینه به‌روزش کند. یعنی از بار دوم به بعد، لود
    // اموجی‌های پرمیوم عملاً آنی است. این کش/دریافت مستقل از حالت سبک است؛
    // حالت سبک فقط روی «متحرک بودن یا نبودن» تاثیر می‌گذارد، نه روی دریافت آیکون‌ها.
    const ICONS_STORAGE_KEY = "premium_icons_cache_v1";

    function fetchPremiumIcons() {
        fetch("/api/premium_icons")
            .then(res => res.json())
            .then(icons => {
                premiumIcons = icons || {};
                iconsFetchedOnce = true;
                applyIconsIn(document);
                try {
                    localStorage.setItem(ICONS_STORAGE_KEY, JSON.stringify(premiumIcons));
                } catch (e) { /* پر بودن فضای localStorage یا نبودنش، مشکلی برای کارکرد اصلی ایجاد نمی‌کند */ }
            })
            .catch(() => { /* در صورت خطا همان نسخه‌ی کش‌شده یا طرح ساده با اموجی معمولی باقی می‌ماند */ });
    }

    try {
        const cached = localStorage.getItem(ICONS_STORAGE_KEY);
        if (cached) {
            premiumIcons = JSON.parse(cached) || {};
            applyIconsIn(document);
        }
    } catch (e) { /* localStorage در دسترس نبود یا داده خراب بود؛ مشکلی نیست */ }

    fetchPremiumIcons();

    // ===================== بررسی محیط تلگرام =====================
    const warning = document.getElementById("non-telegram-warning");
    const appContent = document.getElementById("app-content");

    if (!tg.initDataUnsafe || !tg.initDataUnsafe.user) {
        warning.classList.remove("hidden");
        return;
    }

    appContent.classList.remove("hidden");
    tg.expand();
    if (tg.setHeaderColor) {
        try { tg.setHeaderColor("secondary_bg_color"); } catch (e) { /* نسخه‌های قدیمی ساپورت نمی‌کنند */ }
    }

    const user = tg.initDataUnsafe.user;

    document.getElementById("user-name").innerText = user.first_name || "کاربر";
    document.getElementById("user-username").innerText = user.username ? `@${user.username}` : "بدون نام کاربری";
    document.getElementById("user-id").innerText = user.id;

    document.getElementById("profile-name-val").innerText = user.first_name;
    document.getElementById("profile-id-val").innerText = `شناسه: ${user.id}`;

    const profileBadge = document.getElementById("profile-status-badge");
    const toggleProfileBtn = document.getElementById("toggle-profile-btn");

    document.getElementById("user-avatar").src = user.photo_url || `https://ui-avatars.com/api/?name=${user.first_name}&background=0284c7&color=fff`;

    // ===================== صفحه پروفایل با آواتار بزرگِ کوچک‌شونده =====================
    // با کلیک روی هدر باز می‌شود. آواتار بالای صفحه با سایز ۳ تا ۳.۵ برابر
    // آواتار معمولی شروع می‌شود و همان‌طور که کاربر پایین می‌رود، به‌تدریج
    // کوچک می‌شود تا به سایز معمولی برسد و به‌صورت چسبان (sticky) وسط بالای
    // صفحه باقی بماند.
    const profilePage = document.getElementById("profile-page");
    const profilePageScroll = document.getElementById("profile-page-scroll");
    const profilePageBack = document.getElementById("profile-page-back");
    const profileHeroAvatarWrap = document.getElementById("profile-hero-avatar-wrap");
    const profileHeroAvatar = document.getElementById("profile-hero-avatar");
    const profilePageName = document.getElementById("profile-page-name");
    const profilePageUsername = document.getElementById("profile-page-username");
    const profilePageUserId = document.getElementById("profile-page-user-id");
    const openProfilePageBtn = document.getElementById("open-profile-page");

    const AVATAR_MIN_SIZE = 52; // اندازه‌ی معمولی آواتار (مثل هدر)
    const AVATAR_MAX_SIZE = Math.round(AVATAR_MIN_SIZE * 3.4); // ۳ تا ۳.۵ برابر
    const AVATAR_SHRINK_DISTANCE = 150; // چند پیکسل اسکرول تا کوچک‌شدن کامل

    function updateHeroAvatarOnScroll() {
        const scrollY = profilePageScroll.scrollTop;
        const progress = Math.min(Math.max(scrollY / AVATAR_SHRINK_DISTANCE, 0), 1);
        const size = AVATAR_MAX_SIZE - (AVATAR_MAX_SIZE - AVATAR_MIN_SIZE) * progress;
        profileHeroAvatarWrap.style.width = `${size}px`;
        profileHeroAvatarWrap.style.height = `${size}px`;
        const fade = String(1 - progress);
        profilePageName.style.opacity = fade;
        profilePageUsername.style.opacity = fade;
    }

    function openProfilePage() {
        profileHeroAvatar.src = document.getElementById("user-avatar").src;
        profilePageName.innerText = user.first_name || "کاربر";
        profilePageUsername.innerText = user.username ? `@${user.username}` : "بدون نام کاربری";
        profilePageUserId.innerText = user.id;

        profilePageScroll.scrollTop = 0;
        profileHeroAvatarWrap.style.width = `${AVATAR_MAX_SIZE}px`;
        profileHeroAvatarWrap.style.height = `${AVATAR_MAX_SIZE}px`;
        profilePageName.style.opacity = "1";
        profilePageUsername.style.opacity = "1";

        profilePage.classList.remove("hidden");
        document.body.classList.add("profile-page-open");
        if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred("light");
    }

    function closeProfilePage() {
        profilePage.classList.add("hidden");
        document.body.classList.remove("profile-page-open");
    }

    openProfilePageBtn.addEventListener("click", openProfilePage);
    profilePageBack.addEventListener("click", closeProfilePage);
    profilePageScroll.addEventListener("scroll", updateHeroAvatarOnScroll, { passive: true });

    // ===================== سوییچ حالت سبک داخل تنظیمات مینی‌اپ =====================
    const liteModeToggle = document.getElementById("lite-mode-toggle");

    function setLiteModeSwitchUI(enabled) {
        liteModeToggle.classList.toggle("is-on", enabled);
    }
    setLiteModeSwitchUI(liteMode);

    liteModeToggle.addEventListener("click", () => {
        liteMode = !liteMode;
        try { localStorage.setItem(LITE_MODE_KEY, liteMode ? "1" : "0"); } catch (e) { /* بی‌اهمیت */ }
        setLiteModeSwitchUI(liteMode);

        // ذخیره‌ی سمت سرور تا دکمه‌ی «تنظیمات مینی اپ» داخل ربات هم همین وضعیت
        // تازه را نشان دهد (و برعکس: تغییر از داخل ربات هم اینجا دیده شود).
        fetch('/api/save_mini_app_pref', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id, key: 'lite_mode', value: liteMode })
        }).catch(() => { /* بی‌اهمیت؛ تغییر محلی همچنان اعمال شده */ });

        // اموجی‌های پرمیوم همیشه سرجایشان می‌مانند؛ فقط با تغییر liteMode دوباره
        // رندر می‌شوند تا متحرک/ساکن بودن‌شان به‌روز شود.
        if (iconsFetchedOnce) {
            applyIconsIn(document);
        } else {
            fetchPremiumIcons();
        }

        showToast(liteMode ? "حالت سبک فعال شد 🪶" : "حالت سبک غیرفعال شد");
        if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred("medium");
    });

    // ===================== مودال نمایش ادمین‌های یک گروه =====================
    // با کلیک روی کارت گروه باز می‌شود و فقط نام، آیدی عددی و عکس پروفایل بقیه
    // ادمین‌های آن گروه را نشان می‌دهد؛ عمداً هیچ سوییچ/وضعیتی برای آن‌ها نشان
    // داده نمی‌شود.
    const adminsModalBackdrop = document.getElementById("admins-modal-backdrop");
    const adminsModalClose = document.getElementById("admins-modal-close");
    const adminsModalList = document.getElementById("admins-modal-list");
    const adminsModalTitle = document.getElementById("admins-modal-title");

    function openAdminsModal(groupId, groupTitle) {
        adminsModalTitle.innerText = `ادمین‌های ${groupTitle || "گروه"}`;
        adminsModalList.innerHTML = `<div class="sub-text" style="text-align: center; padding: 14px;">در حال بارگذاری...</div>`;
        adminsModalBackdrop.classList.remove("hidden");

        fetch(`/api/get_group_admins?user_id=${user.id}&group_id=${groupId}`)
            .then(res => res.json())
            .then(resData => {
                if (resData.status !== 'success') {
                    adminsModalList.innerHTML = `<div class="sub-text" style="text-align: center; color: var(--danger-color); padding: 14px;">${resData.message || "خطا در دریافت لیست ادمین‌ها"}</div>`;
                    return;
                }

                const admins = resData.admins || [];
                if (admins.length === 0) {
                    adminsModalList.innerHTML = `<div class="sub-text" style="text-align: center; padding: 14px;">ادمینی یافت نشد.</div>`;
                    return;
                }

                adminsModalList.innerHTML = "";
                admins.forEach(admin => {
                    const item = document.createElement("div");
                    item.className = "admin-item";
                    const avatarSrc = admin.photo || `https://ui-avatars.com/api/?name=${encodeURIComponent(admin.name)}&background=0284c7&color=fff`;
                    item.innerHTML = `
                        <img src="${avatarSrc}" class="admin-avatar" alt="Admin">
                        <div class="admin-text-box">
                            <span class="group-title-row">
                                <span class="admin-name">${admin.name}</span>
                                <span class="admin-status-emoji status-emoji-chip hidden"></span>
                            </span>
                            <span class="admin-meta">آیدی عددی: ${admin.id}${admin.username ? ` • @${admin.username}` : ""}</span>
                        </div>
                    `;
                    adminsModalList.appendChild(item);
                    renderStatusEmoji(item.querySelector(".admin-status-emoji"), admin.status_emoji_id);
                });
            })
            .catch(() => {
                adminsModalList.innerHTML = `<div class="sub-text" style="text-align: center; color: var(--danger-color); padding: 14px;">خطا در ارتباط با سرور</div>`;
            });
    }

    function closeAdminsModal() {
        adminsModalBackdrop.classList.add("hidden");
    }

    adminsModalClose.addEventListener("click", closeAdminsModal);
    adminsModalBackdrop.addEventListener("click", (e) => {
        if (e.target === adminsModalBackdrop) closeAdminsModal();
    });

    // ===================== toast کوچک برای تایید تغییرات =====================
    const toastEl = document.getElementById("toast");
    let toastTimer = null;
    function showToast(text) {
        document.getElementById("toast-text").innerText = text;
        toastEl.classList.add("show");
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => toastEl.classList.remove("show"), 1800);
    }

    function setBadgeIcon(badgeEl, isOpen) {
        const iconEl = badgeEl.querySelector(".icon-chip");
        if (!iconEl) return;
        const key = isOpen ? "unlock" : "lock";
        if (iconEl.getAttribute("data-icon-key") !== key) {
            iconEl.setAttribute("data-icon-key", key);
            delete iconEl.dataset.fallback; // اجازه بده fallback و رندر از نو انجام شود
            iconEl.innerHTML = isOpen ? "🔓" : "🚫";
            renderIcon(iconEl, premiumIcons[key], !liteMode);
        }
    }

    // ===================== دریافت اطلاعات پروفایل و گروه‌ها =====================
    function setSwitchState(switchEl, badgeEl, isOpen) {
        switchEl.classList.toggle("is-on", isOpen);
        badgeEl.querySelector(".badge-text").innerText = isOpen ? "باز" : "قفل";
        badgeEl.className = `badge-lock ${isOpen ? 'open' : 'locked'}`;
        setBadgeIcon(badgeEl, isOpen);
    }

    function refreshMainData() {
        fetch(`/api/get_all_data?user_id=${user.id}`)
        .then(res => res.json())
        .then(data => {
            setSwitchState(toggleProfileBtn, profileBadge, data.user_profile_status === 'open');

            // تم و حالت سبک ذخیره‌شده روی سرور (اگر قبلاً از داخل ربات یا خودِ
            // مینی‌اپ روی دستگاه دیگری تنظیم شده باشد) را با نسخه‌ی محلی هماهنگ
            // می‌کنیم. نسخه‌ی محلی/پیش‌فرض همان لحظه‌ی اول (بدون تاخیر شبکه)
            // اعمال شده؛ این‌جا فقط اگر سرور مقدار متفاوتی داشته باشد، اصلاح می‌شود.
            if (data.theme && data.theme !== getSavedTheme()) {
                applyTheme(data.theme);
                saveTheme(data.theme, false); // false: فقط محلی؛ نیازی به POST دوباره‌ی همان مقدار به سرور نیست
            }
            if (typeof data.lite_mode === 'boolean' && data.lite_mode !== liteMode) {
                liteMode = data.lite_mode;
                try { localStorage.setItem(LITE_MODE_KEY, liteMode ? "1" : "0"); } catch (e) { /* بی‌اهمیت */ }
                setLiteModeSwitchUI(liteMode);
                if (iconsFetchedOnce) {
                    applyIconsIn(document);
                } else {
                    fetchPremiumIcons();
                }
            }

            const groupsContainer = document.getElementById("groups-container");
            groupsContainer.innerHTML = "";

            if (!data.groups || data.groups.length === 0) {
                groupsContainer.innerHTML = `<div class="sub-text" style="text-align: center; padding: 10px;">هیچ گروهی برای مدیریت یافت نشد.</div>`;
                return;
            }

            data.groups.forEach((group, index) => {
                const isOpen = group.status === 'open';
                const groupEl = document.createElement("div");
                groupEl.className = "group-card-item is-clickable";
                groupEl.innerHTML = `
                    <div class="group-info-left">
                        <img src="${group.photo || 'https://ui-avatars.com/api/?name=Group&background=38bdf8&color=fff'}" class="group-avatar" alt="Group">
                        <div class="group-text-box">
                            <span class="group-title">${group.title}</span>
                            <span class="sub-text">آیدی: ${group.id}</span>
                        </div>
                    </div>
                    <div class="status-action-wrapper">
                        <span id="group-badge-${index}" class="badge-lock ${isOpen ? 'open' : 'locked'}">
                            <span class="icon-chip icon-chip-xs" data-icon-key="${isOpen ? 'unlock' : 'lock'}">${isOpen ? '🔓' : '🚫'}</span>
                            <span class="badge-text">${isOpen ? 'باز' : 'قفل'}</span>
                        </span>
                        <button id="group-switch-${index}" class="status-switch ${isOpen ? 'is-on' : ''}" data-group-id="${group.id}" aria-label="تغییر وضعیت گروه"></button>
                    </div>
                `;
                groupEl.addEventListener("click", (e) => {
                    // کلیک روی سوییچ/بج وضعیت نباید مودال ادمین‌ها را باز کند
                    if (e.target.closest(".status-action-wrapper")) return;
                    openAdminsModal(group.id, group.title);
                });

                groupsContainer.appendChild(groupEl);
            });

            applyIconsIn(groupsContainer);

            // مدیریت سوییچ تغییر وضعیت هر گروه (خوش‌بینانه، مثل سوییچ پروفایل)
            document.querySelectorAll(".status-switch[data-group-id]").forEach(switchEl => {
                switchEl.addEventListener("click", () => {
                    const groupId = switchEl.getAttribute("data-group-id");
                    const idx = switchEl.id.replace("group-switch-", "");
                    const badge = document.getElementById(`group-badge-${idx}`);

                    const wasOpen = switchEl.classList.contains("is-on");
                    const nextIsOpen = !wasOpen;

                    setSwitchState(switchEl, badge, nextIsOpen);
                    showToast(nextIsOpen ? "گروه باز شد" : "گروه قفل شد");
                    if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');

                    fetch('/api/toggle_group', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ user_id: user.id, group_id: groupId })
                    })
                    .then(res => res.json())
                    .then(resData => {
                        if (resData.status !== 'success' || (resData.new_status === 'open') !== nextIsOpen) {
                            if (resData.status === 'success') {
                                setSwitchState(switchEl, badge, resData.new_status === 'open');
                            } else {
                                setSwitchState(switchEl, badge, wasOpen);
                                showToast(resData.message || "خطا در تغییر وضعیت");
                                if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('error');
                            }
                        }
                    })
                    .catch(() => {
                        setSwitchState(switchEl, badge, wasOpen);
                        showToast("خطا در ارتباط با سرور، وضعیت قبلی برگشت داده شد");
                        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('error');
                    });
                });
            });
        })
        .catch(() => {
            document.getElementById("groups-container").innerHTML = `<div class="sub-text" style="text-align: center; color: var(--danger-color);">خطا در دریافت اطلاعات از سرور</div>`;
        });
    }

    function anyModalOpen() {
        return Array.from(document.querySelectorAll(".theme-modal-backdrop"))
            .some(el => !el.classList.contains("hidden"));
    }

    refreshMainData();

    // رفرش خودکار و لحظه‌ای: هر چند ثانیه یک‌بار داده‌های اصلی و موجودی
    // کیف‌پول را دوباره می‌گیرد (بدون این‌که وسط باز بودن یک مودال، چیزی زیر
    // دست کاربر عوض شود)، و هر وقت کاربر به مینی‌اپ برگردد (مثلاً از پس‌زمینه)
    // بلافاصله یک رفرش فوری انجام می‌دهد.
    setInterval(() => {
        if (!anyModalOpen()) refreshMainData();
    }, 10000);
    setInterval(() => { loadWalletInfo(); }, 4000);
    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "visible") {
            refreshMainData();
            loadWalletInfo();
        }
    });

    // سوییچ تغییر وضعیت پروفایل — به‌صورت خوش‌بینانه (optimistic): وضعیت
    // بلافاصله (بدون منتظر ماندن برای پاسخ سرور) روی UI اعمال می‌شود تا
    // کاربر تاخیر شبکه را حس نکند؛ درخواست هم‌زمان در پس‌زمینه ارسال می‌شود
    // و فقط اگر شکست بخورد، حالت قبلی برمی‌گردد.
    toggleProfileBtn.addEventListener("click", () => {
        const wasOpen = toggleProfileBtn.classList.contains("is-on");
        const nextIsOpen = !wasOpen;

        setSwitchState(toggleProfileBtn, profileBadge, nextIsOpen);
        showToast(nextIsOpen ? "پروفایل باز شد" : "پروفایل قفل شد");
        if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('medium');

        fetch('/api/toggle_profile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success' || (data.new_status === 'open') !== nextIsOpen) {
                // اگر سرور با چیزی که روی صفحه گذاشتیم فرق داشت (یا خطا داد)، هماهنگ می‌کنیم
                const serverIsOpen = data.status === 'success' ? data.new_status === 'open' : wasOpen;
                setSwitchState(toggleProfileBtn, profileBadge, serverIsOpen);
            }
        })
        .catch(() => {
            setSwitchState(toggleProfileBtn, profileBadge, wasOpen);
            showToast("خطا در ارتباط با سرور، وضعیت قبلی برگشت داده شد");
            if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('error');
        });
    });

    // ===================== انتخابگر تم (۸ روشن + ۸ تیره) =====================
    const THEME_STORAGE_KEY = "miniapp_theme";
    const DEFAULT_THEME = "dark-space";

    const themeBtn = document.getElementById("theme-toggle");
    const body = document.getElementById("body-theme");
    const themeModalBackdrop = document.getElementById("theme-modal-backdrop");
    const themeModalClose = document.getElementById("theme-modal-close");
    const themeOptions = document.querySelectorAll(".theme-option");

    function getSavedTheme() {
        try {
            return localStorage.getItem(THEME_STORAGE_KEY) || DEFAULT_THEME;
        } catch (e) {
            return DEFAULT_THEME;
        }
    }

    function saveTheme(themeValue, syncToServer = true) {
        try {
            localStorage.setItem(THEME_STORAGE_KEY, themeValue);
        } catch (e) {
            // اگر localStorage در دسترس نبود، تم فقط برای همین سشن اعمال می‌شود
        }
        // هم‌زمان روی سرور هم ذخیره می‌شود تا دفعه‌ی بعد (حتی از دستگاه/مرورگر
        // دیگر، یا از طریق دکمه‌ی «تنظیمات مینی اپ» داخل ربات) همین تم لود شود.
        if (syncToServer) {
            fetch('/api/save_mini_app_pref', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_id: user.id, key: 'theme', value: themeValue })
            }).catch(() => { /* اگر ارتباط برقرار نشد، تم همچنان محلی اعمال شده و مشکلی برای کاربر ایجاد نمی‌شود */ });
        }
    }

    function applyTheme(themeValue) {
        body.setAttribute("data-theme", themeValue);
        themeOptions.forEach(opt => {
            const isActive = opt.getAttribute("data-theme-value") === themeValue;
            opt.classList.toggle("active", isActive);
            opt.querySelector(".theme-check").innerText = isActive ? "✓" : "";
        });
    }

    function openThemeModal() {
        themeModalBackdrop.classList.remove("hidden");
    }

    function closeThemeModal() {
        themeModalBackdrop.classList.add("hidden");
    }

    applyTheme(getSavedTheme());

    themeBtn.addEventListener("click", openThemeModal);
    themeModalClose.addEventListener("click", closeThemeModal);
    themeModalBackdrop.addEventListener("click", (e) => {
        if (e.target === themeModalBackdrop) closeThemeModal();
    });

    themeOptions.forEach(opt => {
        opt.addEventListener("click", () => {
            const chosenTheme = opt.getAttribute("data-theme-value");
            applyTheme(chosenTheme);
            saveTheme(chosenTheme);
            if (tg.HapticFeedback) tg.HapticFeedback.selectionChanged();
            closeThemeModal();
        });
    });

    // ===================== نوار پایین: خانه / کیف‌پول =====================
    const bottomNav = document.getElementById("bottom-nav");
    bottomNav.classList.remove("hidden");

    const navButtons = document.querySelectorAll(".bottom-nav-btn");
    const appPages = document.querySelectorAll(".app-page");

    function switchPage(pageId) {
        // اگر وسط انتظار برای دوست (بازی دوستانه) هستیم و کاربر به بخش دیگه‌ای
        // از مینی‌اپ بره، یعنی عملاً از اون صفحه خارج شده — کد رو باطل کن
        if (typeof currentFriendlyCode !== "undefined" && currentFriendlyCode && pageId !== "page-games") {
            sendFriendlyLeaveBeacon();
            stopFriendlyPoll();
            closeModal(document.getElementById("friendly-waiting-modal-backdrop"));
            currentFriendlyCode = null;
        }
        appPages.forEach(p => p.classList.toggle("hidden", p.id !== pageId));
        navButtons.forEach(b => b.classList.toggle("is-active", b.getAttribute("data-page") === pageId));
        if (pageId === "page-wallet") loadWalletInfo();
    }

    navButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            switchPage(btn.getAttribute("data-page"));
            if (tg.HapticFeedback) tg.HapticFeedback.selectionChanged();
        });
    });

    // ===================== کیف‌پول: موجودی و آدرس =====================
    let walletLoadedOnce = false;

    function formatNumber(n) {
        try { return Number(n).toLocaleString("fa-IR"); } catch (e) { return String(n); }
    }

    function loadWalletInfo() {
        fetch(`/api/wallet_info?user_id=${user.id}`)
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'success') return;
                document.getElementById("wallet-balance-val").innerText = formatNumber(data.balance);
                document.getElementById("home-coin-balance-val").innerText = formatNumber(data.balance);
                document.getElementById("wallet-address-val").innerText = data.address;
                walletLoadedOnce = true;
            })
            .catch(() => {
                if (!walletLoadedOnce) {
                    document.getElementById("wallet-address-val").innerText = "خطا در دریافت اطلاعات";
                }
            });
    }

    // موجودی اموجی کوین در صفحه اصلی از همان لحظه‌ی اول لود می‌شود (نه فقط
    // وقتی کاربر وارد تب کیف‌پول می‌شود)
    loadWalletInfo();

    document.getElementById("wallet-address-copy").addEventListener("click", () => {
        const address = document.getElementById("wallet-address-val").innerText;
        if (!address || address === "در حال بارگذاری...") return;
        const copyFallback = () => {
            const tmp = document.createElement("textarea");
            tmp.value = address;
            document.body.appendChild(tmp);
            tmp.select();
            try { document.execCommand("copy"); } catch (e) { /* بی‌اهمیت */ }
            document.body.removeChild(tmp);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(address).catch(copyFallback);
        } else {
            copyFallback();
        }
        showToast("آدرس کپی شد");
        if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred("light");
    });

    // ===================== مودال خرید =====================
    const buyModalBackdrop = document.getElementById("buy-modal-backdrop");
    const buyAmountInput = document.getElementById("buy-amount-input");
    const buyAmountPreview = document.getElementById("buy-amount-preview");
    const buyAmountToman = document.getElementById("buy-amount-toman");
    const buyCreateInvoiceBtn = document.getElementById("buy-create-invoice-btn");
    const COIN_PRICE_TOMAN = 150;
    const MIN_PURCHASE_COINS = 350;

    function openModal(el) { el.classList.remove("hidden"); }
    function closeModal(el) { el.classList.add("hidden"); }

    document.getElementById("wallet-buy-btn").addEventListener("click", () => {
        buyAmountInput.value = "";
        buyAmountPreview.classList.add("hidden");
        openModal(buyModalBackdrop);
    });
    document.getElementById("buy-modal-close").addEventListener("click", () => closeModal(buyModalBackdrop));
    buyModalBackdrop.addEventListener("click", (e) => { if (e.target === buyModalBackdrop) closeModal(buyModalBackdrop); });

    buyAmountInput.addEventListener("input", () => {
        const amount = parseFloat(buyAmountInput.value);
        if (!amount || amount < MIN_PURCHASE_COINS) {
            buyAmountPreview.classList.add("hidden");
            return;
        }
        buyAmountToman.innerText = `${formatNumber(amount * COIN_PRICE_TOMAN)} تومان`;
        buyAmountPreview.classList.remove("hidden");
    });

    let lastCreatedInvoiceId = null;

    buyCreateInvoiceBtn.addEventListener("click", () => {
        const amount = parseFloat(buyAmountInput.value);
        if (!amount || amount < MIN_PURCHASE_COINS) {
            showToast(`حداقل مقدار قابل خرید ${MIN_PURCHASE_COINS} عدد است`);
            return;
        }
        buyCreateInvoiceBtn.disabled = true;
        fetch('/api/create_invoice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id, coin_amount: amount })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') {
                showToast(data.message || "خطا در ساخت فاکتور");
                return;
            }
            lastCreatedInvoiceId = data.invoice.id;
            document.getElementById("invoice-created-amount").innerText = `${formatNumber(data.invoice.toman_amount)} تومان`;
            document.getElementById("invoice-created-card").innerText = data.card_number;
            document.getElementById("invoice-created-holder").innerText = data.card_holder;
            closeModal(buyModalBackdrop);
            openModal(document.getElementById("invoice-created-modal-backdrop"));
        })
        .catch(() => showToast("خطا در ارتباط با سرور"))
        .finally(() => { buyCreateInvoiceBtn.disabled = false; });
    });

    document.getElementById("invoice-created-modal-close").addEventListener("click", () => {
        closeModal(document.getElementById("invoice-created-modal-backdrop"));
    });
    document.getElementById("invoice-created-goto-btn").addEventListener("click", () => {
        closeModal(document.getElementById("invoice-created-modal-backdrop"));
        openInvoicesModal();
    });

    // ===================== مودال فاکتورهای من =====================
    const invoicesModalBackdrop = document.getElementById("invoices-modal-backdrop");
    const invoicesModalList = document.getElementById("invoices-modal-list");
    const STATUS_LABELS = {
        awaiting_receipt: "در انتظار رسید",
        submitted: "در حال بررسی",
        approved: "تایید شده",
        rejected: "رد شده",
        cancelled: "لغو شده"
    };
    let lastInvoicesCardInfo = { card_number: "", card_holder: "" };

    function openInvoicesModal() {
        invoicesModalList.innerHTML = `<div class="sub-text" style="text-align: center; padding: 14px;">در حال بارگذاری...</div>`;
        openModal(invoicesModalBackdrop);

        fetch(`/api/my_invoices?user_id=${user.id}`)
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'success') {
                    invoicesModalList.innerHTML = `<div class="sub-text" style="text-align: center; color: var(--danger-color);">خطا در دریافت فاکتورها</div>`;
                    return;
                }
                lastInvoicesCardInfo = { card_number: data.card_number, card_holder: data.card_holder };
                const invoices = data.invoices || [];
                if (invoices.length === 0) {
                    invoicesModalList.innerHTML = `<div class="sub-text" style="text-align: center; padding: 14px;">هنوز فاکتوری ثبت نکرده‌اید.</div>`;
                    return;
                }
                invoicesModalList.innerHTML = "";
                invoices.forEach(inv => {
                    const item = document.createElement("div");
                    item.className = "invoice-item";
                    item.innerHTML = `
                        <div class="invoice-item-info">
                            <span class="group-title">
                                <span class="icon-chip icon-chip-xs" data-icon-key="coin-amount">🪙</span>
                                ${formatNumber(inv.coin_amount)} اموجی کوین
                            </span>
                            <span class="sub-text">${formatNumber(inv.toman_amount)} تومان</span>
                        </div>
                        <span class="invoice-status-badge ${inv.status}">${STATUS_LABELS[inv.status] || inv.status}</span>
                    `;
                    item.addEventListener("click", () => openInvoiceDetail(inv));
                    invoicesModalList.appendChild(item);
                });
                applyIconsIn(invoicesModalList);
            })
            .catch(() => {
                invoicesModalList.innerHTML = `<div class="sub-text" style="text-align: center; color: var(--danger-color);">خطا در ارتباط با سرور</div>`;
            });
    }

    document.getElementById("wallet-my-invoices-btn").addEventListener("click", openInvoicesModal);
    document.getElementById("invoices-modal-close").addEventListener("click", () => closeModal(invoicesModalBackdrop));
    invoicesModalBackdrop.addEventListener("click", (e) => { if (e.target === invoicesModalBackdrop) closeModal(invoicesModalBackdrop); });

    // ===================== مودال گزارش تراکنش‌ها (خرید/دریافت/ارسال) =====================
    const transactionsModalBackdrop = document.getElementById("transactions-modal-backdrop");
    const transactionsModalList = document.getElementById("transactions-modal-list");
    const TX_TYPE_LABELS = { buy: "خرید", send: "ارسال", receive: "دریافت" };
    const TX_TYPE_ICONS = { buy: "shop", send: "send", receive: "history" };
    const TX_TYPE_EMOJI_FALLBACK = { buy: "🛒", send: "↗️", receive: "📥" };

    function formatTxDate(ts) {
        try {
            return new Date(ts * 1000).toLocaleString("fa-IR", { dateStyle: "short", timeStyle: "short" });
        } catch (e) { return ""; }
    }

    function openTransactionsModal() {
        transactionsModalList.innerHTML = `<div class="sub-text" style="text-align: center; padding: 14px;">در حال بارگذاری...</div>`;
        openModal(transactionsModalBackdrop);

        fetch(`/api/my_transactions?user_id=${user.id}`)
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'success') {
                    transactionsModalList.innerHTML = `<div class="sub-text" style="text-align: center; color: var(--danger-color);">خطا در دریافت تراکنش‌ها</div>`;
                    return;
                }
                const transactions = data.transactions || [];
                if (transactions.length === 0) {
                    transactionsModalList.innerHTML = `<div class="sub-text" style="text-align: center; padding: 14px;">هنوز تراکنشی ثبت نشده است.</div>`;
                    return;
                }
                transactionsModalList.innerHTML = "";
                transactions.forEach(tx => {
                    const item = document.createElement("div");
                    item.className = "transaction-item";
                    const sign = tx.type === "send" ? "−" : "+";
                    const dateLine = formatTxDate(tx.created_at);
                    let counterpartyPrefix = "", counterpartyName = "", counterpartySuffix = "";
                    if (tx.type === "receive" && tx.counterparty_name) {
                        counterpartyPrefix = "از ";
                        counterpartyName = tx.counterparty_name;
                        counterpartySuffix = (tx.counterparty_username ? ` (@${tx.counterparty_username})` : "")
                            + (tx.counterparty_id ? ` · آیدی عددی: ${tx.counterparty_id}` : "");
                    } else if (tx.type === "send" && tx.counterparty_name) {
                        counterpartyPrefix = "به ";
                        counterpartyName = tx.counterparty_name;
                        counterpartySuffix = (tx.counterparty_username ? ` (@${tx.counterparty_username})` : "");
                    }
                    item.innerHTML = `
                        <div class="transaction-item-info">
                            <span class="transaction-type-badge ${tx.type}">
                                <span class="icon-chip icon-chip-xs" data-icon-key="${TX_TYPE_ICONS[tx.type] || 'coin'}">${TX_TYPE_EMOJI_FALLBACK[tx.type] || '🪙'}</span>
                                ${TX_TYPE_LABELS[tx.type] || tx.type}
                            </span>
                            ${counterpartyName ? `<span class="sub-text">${counterpartyPrefix}<span class="tx-counterparty-name">${counterpartyName}</span><span class="tx-counterparty-status-emoji status-emoji-chip hidden"></span>${counterpartySuffix}</span>` : ""}
                            <span class="sub-text">${dateLine}</span>
                        </div>
                        <span class="transaction-amount ${tx.type}">${sign}${formatNumber(tx.amount)}</span>
                    `;
                    transactionsModalList.appendChild(item);
                    if (tx.counterparty_profile_style) {
                        renderStatusEmoji(item.querySelector(".tx-counterparty-status-emoji"), tx.counterparty_profile_style.status_emoji_id);
                    }
                });
                applyIconsIn(transactionsModalList);
            })
            .catch(() => {
                transactionsModalList.innerHTML = `<div class="sub-text" style="text-align: center; color: var(--danger-color);">خطا در ارتباط با سرور</div>`;
            });
    }

    document.getElementById("wallet-my-transactions-btn").addEventListener("click", openTransactionsModal);
    document.getElementById("transactions-modal-close").addEventListener("click", () => closeModal(transactionsModalBackdrop));
    transactionsModalBackdrop.addEventListener("click", (e) => { if (e.target === transactionsModalBackdrop) closeModal(transactionsModalBackdrop); });

    // ===================== مودال جزییات فاکتور + آپلود رسید =====================
    const invoiceDetailModalBackdrop = document.getElementById("invoice-detail-modal-backdrop");
    const invoiceReceiptInput = document.getElementById("invoice-receipt-input");
    const invoiceReceiptSendBtn = document.getElementById("invoice-receipt-send-btn");
    const invoiceDetailUploadBox = document.getElementById("invoice-detail-upload-box");
    const invoiceCancelBtn = document.getElementById("invoice-cancel-btn");
    let currentInvoiceForUpload = null;

    function openInvoiceDetail(inv) {
        currentInvoiceForUpload = inv;
        document.getElementById("invoice-detail-coin").innerText = `${formatNumber(inv.coin_amount)} اموجی کوین`;
        document.getElementById("invoice-detail-amount").innerText = `${formatNumber(inv.toman_amount)} تومان`;
        document.getElementById("invoice-detail-card").innerText = lastInvoicesCardInfo.card_number || "---";
        document.getElementById("invoice-detail-status").innerText = STATUS_LABELS[inv.status] || inv.status;
        invoiceReceiptInput.value = "";
        invoiceDetailUploadBox.classList.toggle("hidden", inv.status !== "awaiting_receipt");
        const isCancellable = inv.status === "awaiting_receipt" || inv.status === "submitted";
        invoiceCancelBtn.classList.toggle("hidden", !isCancellable);
        openModal(invoiceDetailModalBackdrop);
    }

    document.getElementById("invoice-detail-modal-close").addEventListener("click", () => closeModal(invoiceDetailModalBackdrop));
    invoiceDetailModalBackdrop.addEventListener("click", (e) => { if (e.target === invoiceDetailModalBackdrop) closeModal(invoiceDetailModalBackdrop); });

    invoiceCancelBtn.addEventListener("click", () => {
        if (!currentInvoiceForUpload) return;
        invoiceCancelBtn.disabled = true;
        fetch('/api/cancel_invoice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id, invoice_id: currentInvoiceForUpload.id })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') {
                showToast(data.message || "خطا در لغو فاکتور");
                return;
            }
            showToast("فاکتور لغو شد");
            if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
            closeModal(invoiceDetailModalBackdrop);
            openInvoicesModal();
        })
        .catch(() => showToast("خطا در ارتباط با سرور"))
        .finally(() => { invoiceCancelBtn.disabled = false; });
    });

    invoiceReceiptSendBtn.addEventListener("click", () => {
        if (!currentInvoiceForUpload) return;
        const file = invoiceReceiptInput.files[0];
        if (!file) {
            showToast("لطفاً ابتدا تصویر رسید را انتخاب کنید");
            return;
        }
        const formData = new FormData();
        formData.append("user_id", user.id);
        formData.append("invoice_id", currentInvoiceForUpload.id);
        formData.append("buyer_name", user.first_name || "کاربر");
        if (user.username) formData.append("buyer_username", user.username);
        formData.append("receipt", file);

        invoiceReceiptSendBtn.disabled = true;
        fetch('/api/upload_receipt', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'success') {
                    showToast(data.message || "خطا در ارسال رسید");
                    return;
                }
                showToast("رسید ارسال شد و در انتظار بررسی است ✅");
                if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
                closeModal(invoiceDetailModalBackdrop);
                openInvoicesModal();
            })
            .catch(() => showToast("خطا در ارتباط با سرور"))
            .finally(() => { invoiceReceiptSendBtn.disabled = false; });
    });

    // ===================== مودال انتقال کوین =====================
    const transferModalBackdrop = document.getElementById("transfer-modal-backdrop");
    const transferAddressInput = document.getElementById("transfer-address-input");
    const transferAmountInput = document.getElementById("transfer-amount-input");
    const transferSubmitBtn = document.getElementById("transfer-submit-btn");
    const transferRecipientBox = document.getElementById("transfer-recipient-box");
    const transferRecipientAvatar = document.getElementById("transfer-recipient-avatar");
    const transferRecipientName = document.getElementById("transfer-recipient-name");
    const transferRecipientUsername = document.getElementById("transfer-recipient-username");
    const transferRecipientId = document.getElementById("transfer-recipient-id");
    const transferRecipientStatusEmoji = document.getElementById("transfer-recipient-status-emoji");
    const transferLookupStatus = document.getElementById("transfer-lookup-status");
    const transferTaxBox = document.getElementById("transfer-tax-box");
    const transferTaxSent = document.getElementById("transfer-tax-sent");
    const transferTaxAmount = document.getElementById("transfer-tax-amount");
    const transferTaxNet = document.getElementById("transfer-tax-net");
    const TRANSFER_TAX_RATE = 0.05;

    function updateTransferTaxPreview() {
        const amount = parseFloat(transferAmountInput.value);
        if (!amount || amount <= 0) {
            transferTaxBox.classList.add("hidden");
            return;
        }
        const tax = Math.round(amount * TRANSFER_TAX_RATE * 100) / 100;
        const net = Math.round((amount - tax) * 100) / 100;
        transferTaxSent.innerText = `${formatNumber(amount)} اموجی کوین`;
        transferTaxAmount.innerText = `${formatNumber(tax)} اموجی کوین`;
        transferTaxNet.innerText = `${formatNumber(net)} اموجی کوین`;
        transferTaxBox.classList.remove("hidden");
    }


    const TRANSFER_CONFIRM_WAIT_SECONDS = 5;
    let transferLookupTimer = null;
    let transferCountdownInterval = null;
    let transferConfirmedRecipientAddress = null;

    function setTransferButtonWaiting() {
        clearInterval(transferCountdownInterval);
        transferSubmitBtn.className = "wallet-submit-btn is-waiting";
        transferSubmitBtn.disabled = true;
        transferSubmitBtn.innerText = "ارسال انتقال";
        transferConfirmedRecipientAddress = null;
    }

    function startTransferCountdown() {
        clearInterval(transferCountdownInterval);
        let remaining = TRANSFER_CONFIRM_WAIT_SECONDS;
        transferSubmitBtn.className = "wallet-submit-btn is-counting";
        transferSubmitBtn.disabled = true;
        transferSubmitBtn.innerText = String(remaining);

        transferCountdownInterval = setInterval(() => {
            remaining -= 1;
            if (remaining <= 0) {
                clearInterval(transferCountdownInterval);
                transferSubmitBtn.className = "wallet-submit-btn is-ready";
                transferSubmitBtn.disabled = false;
                transferSubmitBtn.innerHTML = `<span class="icon-chip icon-chip-xs" data-icon-key="check">✅</span> تایید`;
                applyIconsIn(transferSubmitBtn);
                transferConfirmedRecipientAddress = transferAddressInput.value.trim();
            } else {
                transferSubmitBtn.innerText = String(remaining);
            }
        }, 1000);
    }

    function hideTransferRecipient() {
        transferRecipientBox.classList.add("hidden");
        transferLookupStatus.classList.add("hidden");
        transferLookupStatus.innerText = "";
        setTransferButtonWaiting();
    }

    function tryLookupRecipient() {
        const address = transferAddressInput.value.trim();
        const amount = parseFloat(transferAmountInput.value);

        clearTimeout(transferLookupTimer);

        if (address.length !== 32 || !amount || amount <= 0) {
            hideTransferRecipient();
            return;
        }

        transferLookupTimer = setTimeout(() => {
            transferLookupStatus.classList.remove("hidden");
            transferLookupStatus.innerText = "در حال جستجوی گیرنده...";
            transferRecipientBox.classList.add("hidden");
            setTransferButtonWaiting();

            fetch(`/api/lookup_wallet?address=${encodeURIComponent(address)}&user_id=${user.id}`)
                .then(res => res.json())
                .then(data => {
                    // اگر کاربر در همین فاصله مقدار فیلدها را عوض کرده، نتیجه‌ی قدیمی را نادیده بگیر
                    if (transferAddressInput.value.trim() !== address) return;

                    if (data.status !== 'success') {
                        transferLookupStatus.classList.remove("hidden");
                        transferLookupStatus.innerText = data.message || "گیرنده یافت نشد";
                        transferRecipientBox.classList.add("hidden");
                        setTransferButtonWaiting();
                        return;
                    }

                    transferLookupStatus.classList.add("hidden");
                    transferRecipientAvatar.src = data.photo_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(data.name || '?')}&background=0284c7&color=fff`;
                    transferRecipientName.innerText = data.name || "کاربر";
                    transferRecipientUsername.innerText = data.username ? `@${data.username}` : "";
                    transferRecipientId.innerText = data.user_id;
                    renderStatusEmoji(transferRecipientStatusEmoji, data.profile_style && data.profile_style.status_emoji_id);
                    transferRecipientBox.classList.remove("hidden");

                    startTransferCountdown();
                })
                .catch(() => {
                    transferLookupStatus.classList.remove("hidden");
                    transferLookupStatus.innerText = "خطا در ارتباط با سرور";
                    transferRecipientBox.classList.add("hidden");
                    setTransferButtonWaiting();
                });
        }, 450);
    }

    transferAddressInput.addEventListener("input", tryLookupRecipient);
    transferAmountInput.addEventListener("input", () => {
        tryLookupRecipient();
        updateTransferTaxPreview();
    });

    document.getElementById("wallet-transfer-btn").addEventListener("click", () => {
        transferAddressInput.value = "";
        transferAmountInput.value = "";
        hideTransferRecipient();
        transferTaxBox.classList.add("hidden");
        openModal(transferModalBackdrop);
    });
    document.getElementById("transfer-modal-close").addEventListener("click", () => closeModal(transferModalBackdrop));
    transferModalBackdrop.addEventListener("click", (e) => { if (e.target === transferModalBackdrop) closeModal(transferModalBackdrop); });

    transferSubmitBtn.addEventListener("click", () => {
        const toAddress = transferAddressInput.value.trim();
        const amount = parseFloat(transferAmountInput.value);

        // دکمه فقط وقتی واقعاً «تایید»ه (بعد از ۵ ثانیه و برای همین آدرس) کار می‌کند
        if (transferSubmitBtn.disabled || transferConfirmedRecipientAddress !== toAddress) {
            return;
        }
        if (!toAddress || toAddress.length !== 32) {
            showToast("آدرس کیف‌پول مقصد باید ۳۲ کاراکتری باشد");
            return;
        }
        if (!amount || amount <= 0) {
            showToast("مقدار وارد شده نامعتبر است");
            return;
        }

        transferSubmitBtn.disabled = true;
        fetch('/api/transfer', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                user_id: user.id,
                to_address: toAddress,
                amount: amount,
                sender_name: user.first_name || "کاربر",
                sender_username: user.username || null
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') {
                showToast(data.message || "خطا در انتقال");
                transferSubmitBtn.disabled = false;
                return;
            }
            showToast(`انتقال با موفقیت انجام شد ✅ (${formatNumber(data.net_amount)} اموجی کوین به حریف رسید، ${formatNumber(data.tax_amount)} مالیات کسر شد)`);
            if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
            closeModal(transferModalBackdrop);
            loadWalletInfo();
        })
        .catch(() => {
            showToast("خطا در ارتباط با سرور");
            transferSubmitBtn.disabled = false;
        });
    });

    // ===================== بازی‌ها: کارت انتخاب بازی + شرط‌بندی/صف انتظار =====================
    // خودِ صفحه‌ی بازی (تخته، حرکت‌ها، برد/باخت) داخل static/game/tictactoe/tictactoe.js
    // است؛ اینجا فقط مسئول انتخاب بازی/شرط و پیدا کردن حریف (matchmaking) هستیم.
    const stakeModalBackdrop = document.getElementById("stake-modal-backdrop");
    const waitingModalBackdrop = document.getElementById("waiting-modal-backdrop");

    let currentGame = "tictactoe";
    let currentStake = null;
    let waitingPollInterval = null;

    function stopWaitingPoll() { clearInterval(waitingPollInterval); waitingPollInterval = null; }

    document.getElementById("game-card-tictactoe").addEventListener("click", () => {
        currentGame = "tictactoe";
        openModal(stakeModalBackdrop);
    });
    document.getElementById("stake-modal-close").addEventListener("click", () => closeModal(stakeModalBackdrop));
    stakeModalBackdrop.addEventListener("click", (e) => { if (e.target === stakeModalBackdrop) closeModal(stakeModalBackdrop); });

    document.querySelectorAll(".stake-option-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            currentStake = parseInt(btn.getAttribute("data-stake"), 10);
            closeModal(stakeModalBackdrop);
            joinGameQueue();
        });
    });

    function launchGame(sessionId, session) {
        if (currentGame === "tictactoe" && window.TicTacToeGame) {
            window.TicTacToeGame.open(sessionId, user.id, session, () => {
                // وقتی بازی تمام شد یا کاربر ترکش کرد، موجودی کیف‌پول رو رفرش کن
                loadWalletInfo();
            });
        }
    }

    function joinGameQueue() {
        fetch('/api/game/join', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id, game: currentGame, stake: currentStake })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'matched') {
                launchGame(data.session_id, data.session);
            } else if (data.status === 'waiting') {
                openModal(waitingModalBackdrop);
                startWaitingPoll();
            } else {
                showToast(data.message || "خطا در ورود به بازی");
            }
        })
        .catch(() => showToast("خطا در ارتباط با سرور"));
    }

    function startWaitingPoll() {
        stopWaitingPoll();
        waitingPollInterval = setInterval(() => {
            fetch(`/api/game/my_session?user_id=${user.id}&game=${currentGame}&stake=${currentStake}`)
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'matched') {
                        stopWaitingPoll();
                        closeModal(waitingModalBackdrop);
                        launchGame(data.session_id, data.session);
                    } else if (data.status === 'none') {
                        stopWaitingPoll();
                        closeModal(waitingModalBackdrop);
                    }
                })
                .catch(() => {});
        }, 2000);
    }

    document.getElementById("waiting-cancel-btn").addEventListener("click", () => {
        stopWaitingPoll();
        closeModal(waitingModalBackdrop);
        fetch('/api/game/cancel_queue', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id, game: currentGame, stake: currentStake })
        }).catch(() => {});
    });

    // ===================== اموجی وضعیت من (مودال انتخاب) =====================
    const emojiStatusModalBackdrop = document.getElementById("emoji-status-modal-backdrop");
    const emojiPackLinkInput = document.getElementById("emoji-pack-link-input");
    const emojiPickerGrid = document.getElementById("emoji-picker-grid");
    const ownStatusEmojiEl = document.getElementById("own-status-emoji");
    const ownStatusEmojiPreviewEl = document.getElementById("own-status-emoji-preview");
    const headerStatusEmojiEl = document.getElementById("header-status-emoji");
    const profilePageStatusEmojiEl = document.getElementById("profile-page-status-emoji");
    let selectedStatusEmojiId = null;

    function renderOwnStatusEmojiEverywhere(emojiId) {
        renderStatusEmoji(ownStatusEmojiEl, emojiId);
        renderStatusEmoji(ownStatusEmojiPreviewEl, emojiId);
        renderStatusEmoji(headerStatusEmojiEl, emojiId);
        renderStatusEmoji(profilePageStatusEmojiEl, emojiId);
    }

    function loadOwnStatusEmoji() {
        fetch(`/api/profile_style/mine?user_id=${user.id}`)
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'success') return;
                selectedStatusEmojiId = data.style.status_emoji_id || null;
                renderOwnStatusEmojiEverywhere(selectedStatusEmojiId);
            })
            .catch(() => {});
    }
    loadOwnStatusEmoji();

    function renderEmojiPickerGrid(emojiIds) {
        emojiPickerGrid.innerHTML = "";

        const clearItem = document.createElement("div");
        clearItem.className = "emoji-picker-item clear-option";
        clearItem.innerText = "بدون اموجی";
        clearItem.addEventListener("click", () => {
            selectedStatusEmojiId = null;
            emojiPickerGrid.querySelectorAll(".emoji-picker-item").forEach(el => el.classList.remove("is-selected"));
            clearItem.classList.add("is-selected");
        });
        emojiPickerGrid.appendChild(clearItem);

        if (!emojiIds || emojiIds.length === 0) return;

        emojiIds.forEach(emojiId => {
            const item = document.createElement("div");
            item.className = "emoji-picker-item";
            if (emojiId === selectedStatusEmojiId) item.classList.add("is-selected");
            item.addEventListener("click", () => {
                selectedStatusEmojiId = emojiId;
                emojiPickerGrid.querySelectorAll(".emoji-picker-item").forEach(el => el.classList.remove("is-selected"));
                item.classList.add("is-selected");
            });
            emojiPickerGrid.appendChild(item);
            renderStatusEmoji(item, emojiId);
            item.classList.remove("hidden"); // renderStatusEmoji ممکنه hidden اضافه کنه، اینجا لازممون نیست
        });
    }

    function loadEmojiOptions() {
        fetch('/api/profile_style/options')
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'success') return;
                renderEmojiPickerGrid(data.emoji_ids);
            })
            .catch(() => {});
    }

    document.getElementById("open-status-emoji-picker-btn").addEventListener("click", () => {
        loadEmojiOptions();
        openModal(emojiStatusModalBackdrop);
    });
    document.getElementById("emoji-status-modal-close").addEventListener("click", () => closeModal(emojiStatusModalBackdrop));
    emojiStatusModalBackdrop.addEventListener("click", (e) => { if (e.target === emojiStatusModalBackdrop) closeModal(emojiStatusModalBackdrop); });

    document.getElementById("emoji-pack-import-btn").addEventListener("click", () => {
        const link = emojiPackLinkInput.value.trim();
        if (!link) { showToast("لینک پک رو وارد کن"); return; }
        fetch('/api/profile_style/import_pack', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pack_link: link })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') { showToast(data.message || "خطا در بارگذاری پک"); return; }
            showToast(`${data.added} اموجی از «${data.set_title}» اضافه شد ✅`);
            loadEmojiOptions();
        })
        .catch(() => showToast("خطا در ارتباط با سرور"));
    });

    document.getElementById("emoji-status-save-btn").addEventListener("click", () => {
        fetch('/api/profile_style/set', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id, status_emoji_id: selectedStatusEmojiId })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') { showToast("خطا در ذخیره"); return; }
            renderOwnStatusEmojiEverywhere(selectedStatusEmojiId);
            showToast("اموجی وضعیت ذخیره شد ✅");
            closeModal(emojiStatusModalBackdrop);
        })
        .catch(() => showToast("خطا در ارتباط با سرور"));
    });

    // ===================== بازی‌های دوستانه =====================
    const friendlyChoiceModalBackdrop = document.getElementById("friendly-choice-modal-backdrop");
    const friendlyCreateModalBackdrop = document.getElementById("friendly-create-modal-backdrop");
    const friendlyWaitingModalBackdrop = document.getElementById("friendly-waiting-modal-backdrop");
    const friendlyJoinModalBackdrop = document.getElementById("friendly-join-modal-backdrop");
    const friendlyCodeDisplay = document.getElementById("friendly-code-display");
    const friendlyCustomStakeInput = document.getElementById("friendly-custom-stake-input");
    const friendlyJoinCodeInput = document.getElementById("friendly-join-code-input");

    let friendlyPollInterval = null;
    let currentFriendlyCode = null;

    function stopFriendlyPoll() { clearInterval(friendlyPollInterval); friendlyPollInterval = null; }

    // اگر سازنده مینی‌اپ رو ببنده/ازش خارج بشه (سوایپ، بستن تلگرام، عوض کردن
    // چت) درحالی‌که هنوز منتظر دوستشه، این event حتی وقتی صفحه در حال بسته
    // شدنه هم قابل‌اطمینان fire می‌شه (برخلاف fetch معمولی که ممکنه نصفه‌کاره
    // قطع بشه) — یه درخواست لغو برای همون کد می‌فرسته تا دیگه کار نکنه.
    function sendFriendlyLeaveBeacon() {
        if (!currentFriendlyCode) return;
        const payload = JSON.stringify({ user_id: user.id, code: currentFriendlyCode });
        if (navigator.sendBeacon) {
            const blob = new Blob([payload], { type: 'application/json' });
            navigator.sendBeacon('/api/game/cancel_friendly', blob);
        } else {
            fetch('/api/game/cancel_friendly', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: payload, keepalive: true }).catch(() => {});
        }
    }
    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "hidden") sendFriendlyLeaveBeacon();
    });
    window.addEventListener("pagehide", sendFriendlyLeaveBeacon);

    document.getElementById("game-friendly-btn").addEventListener("click", () => openModal(friendlyChoiceModalBackdrop));
    document.getElementById("friendly-choice-modal-close").addEventListener("click", () => closeModal(friendlyChoiceModalBackdrop));
    friendlyChoiceModalBackdrop.addEventListener("click", (e) => { if (e.target === friendlyChoiceModalBackdrop) closeModal(friendlyChoiceModalBackdrop); });

    document.getElementById("friendly-create-btn").addEventListener("click", () => {
        closeModal(friendlyChoiceModalBackdrop);
        friendlyCustomStakeInput.value = "";
        openModal(friendlyCreateModalBackdrop);
    });
    document.getElementById("friendly-create-modal-close").addEventListener("click", () => closeModal(friendlyCreateModalBackdrop));
    friendlyCreateModalBackdrop.addEventListener("click", (e) => { if (e.target === friendlyCreateModalBackdrop) closeModal(friendlyCreateModalBackdrop); });

    function createFriendlyGame(stake) {
        fetch('/api/game/create_friendly', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id, game: 'tictactoe', stake: stake })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') { showToast(data.message || "خطا در ساخت بازی"); return; }
            closeModal(friendlyCreateModalBackdrop);
            currentFriendlyCode = data.code;
            friendlyCodeDisplay.innerText = data.code;
            openModal(friendlyWaitingModalBackdrop);
            stopFriendlyPoll();
            friendlyPollInterval = setInterval(() => {
                fetch(`/api/game/friendly_status?code=${currentFriendlyCode}`)
                    .then(r => r.json())
                    .then(d => {
                        if (d.status === 'matched') {
                            stopFriendlyPoll();
                            closeModal(friendlyWaitingModalBackdrop);
                            fetch(`/api/game/session?session_id=${d.session_id}&user_id=${user.id}`)
                                .then(r2 => r2.json())
                                .then(d2 => { if (d2.status === 'success') launchGame(d.session_id, d2.session); });
                        }
                    })
                    .catch(() => {});
            }, 2000);
        })
        .catch(() => showToast("خطا در ارتباط با سرور"));
    }

    document.querySelectorAll(".friendly-stake-option-btn").forEach(btn => {
        btn.addEventListener("click", () => createFriendlyGame(parseInt(btn.getAttribute("data-stake"), 10)));
    });
    document.getElementById("friendly-custom-stake-submit-btn").addEventListener("click", () => {
        const stake = parseInt(friendlyCustomStakeInput.value, 10);
        if (!stake || stake < 1 || stake > 5000) { showToast("مقدار شرط شخصی باید بین ۱ تا ۵۰۰۰ باشد"); return; }
        createFriendlyGame(stake);
    });

    document.getElementById("friendly-copy-code-btn").addEventListener("click", () => {
        if (!currentFriendlyCode) return;
        const copyFallback = () => {
            const tmp = document.createElement("textarea");
            tmp.value = currentFriendlyCode;
            document.body.appendChild(tmp);
            tmp.select();
            try { document.execCommand("copy"); } catch (e) {}
            document.body.removeChild(tmp);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(currentFriendlyCode).catch(copyFallback);
        } else {
            copyFallback();
        }
        showToast("کد کپی شد");
    });

    document.getElementById("friendly-cancel-btn").addEventListener("click", () => {
        stopFriendlyPoll();
        closeModal(friendlyWaitingModalBackdrop);
        if (currentFriendlyCode) {
            fetch('/api/game/cancel_friendly', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_id: user.id, code: currentFriendlyCode })
            }).catch(() => {});
        }
        currentFriendlyCode = null;
    });

    document.getElementById("friendly-join-btn").addEventListener("click", () => {
        closeModal(friendlyChoiceModalBackdrop);
        friendlyJoinCodeInput.value = "";
        openModal(friendlyJoinModalBackdrop);
    });
    document.getElementById("friendly-join-modal-close").addEventListener("click", () => closeModal(friendlyJoinModalBackdrop));
    friendlyJoinModalBackdrop.addEventListener("click", (e) => { if (e.target === friendlyJoinModalBackdrop) closeModal(friendlyJoinModalBackdrop); });

    document.getElementById("friendly-join-submit-btn").addEventListener("click", () => {
        const code = friendlyJoinCodeInput.value.trim();
        if (!code) { showToast("کد بازی رو وارد کن"); return; }
        fetch('/api/game/join_friendly', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: user.id, code: code })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'matched') { showToast(data.message || "خطا در ورود به بازی"); return; }
            closeModal(friendlyJoinModalBackdrop);
            launchGame(data.session_id, data.session);
        })
        .catch(() => showToast("خطا در ارتباط با سرور"));
    });
});
